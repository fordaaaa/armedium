#include "src/core/console.h"
#include "src/core/ntapi.h"
#include "src/inject/injector.h"
#include "src/target/disk.h"
#include "src/target/process.h"

#include <vector>

static constexpr const char* console_title = "bladee";
static constexpr const char* target_name = "RobloxPlayerBeta.exe";
static constexpr const char* payload_name = "module.dll";

auto main( ) -> int
{
    console::init( console_title );

    if ( !nt::init( ) )
    {
        console::error( "ntdll resolve failed" );
        console::wait_close( );
        return 1;
    }

    target::handle tgt;
    if ( !target::find( target_name, tgt ) )
    {
        console::error( "target %s not running", target_name );
        console::wait_close( );
        return 1;
    }

    console::log( "target pid %lu", tgt.pid );

    if ( !disk::exists_sibling( payload_name ) )
    {
        console::error( "%s not found next to executable", payload_name );
        console::wait_close( );
        return 1;
    }

    std::vector< uint8_t > payload;
    if ( !disk::read_sibling( payload_name, payload ) )
    {
        console::error( "%s read failed", payload_name );
        console::wait_close( );
        return 1;
    }

    console::log( "%s loaded -> %zu bytes", payload_name, payload.size( ) );

    if ( !injector::inject( tgt.process, tgt.pid, payload ) )
    {
        console::wait_close( );
        return 1;
    }

    console::log( "injected" );
    console::wait_close( );
    return 0;
}
