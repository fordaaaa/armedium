#pragma once

#include <Windows.h>
#include <cstdint>
#include <vector>

namespace mapper
{
    uintptr_t map_image( HANDLE process, const std::vector< uint8_t >& bytes );
}
