#include "mapper.h"

#include "../core/ntapi.h"

#include <cstring>

static const IMAGE_NT_HEADERS64* nt_headers( const uint8_t* file )
{
    auto dos = ( const IMAGE_DOS_HEADER* )file;
    if ( dos->e_magic != IMAGE_DOS_SIGNATURE )
        return nullptr;

    auto nt = ( const IMAGE_NT_HEADERS64* )( file + dos->e_lfanew );
    if ( nt->Signature != IMAGE_NT_SIGNATURE )
        return nullptr;

    if ( nt->FileHeader.Machine != IMAGE_FILE_MACHINE_AMD64 )
        return nullptr;

    return nt;
}

namespace mapper
{
    uintptr_t map_image( HANDLE process, const std::vector< uint8_t >& bytes )
    {
        if ( bytes.size( ) < sizeof( IMAGE_DOS_HEADER ) )
            return 0;

        const uint8_t* file = bytes.data( );
        const IMAGE_NT_HEADERS64* nt = nt_headers( file );

        if ( !nt )
            return 0;

        const SIZE_T image_size = nt->OptionalHeader.SizeOfImage;
        const SIZE_T aligned_size = ( image_size + 0xFFFF ) & ~SIZE_T( 0xFFFF );

        auto& api = nt::api( );

        HANDLE section = nullptr;
        LARGE_INTEGER sect_size = {};
        sect_size.QuadPart = aligned_size;

        LONG s = api.create_section(
            &section,
            nt::section_all_access,
            nullptr,
            &sect_size,
            PAGE_EXECUTE_READWRITE,
            nt::sec_commit,
            nullptr
        );

        if ( s < 0 )
            return 0;

        PVOID remote = nullptr;
        SIZE_T view_size = aligned_size;

        s = api.map_view(
            section,
            process,
            &remote,
            0,
            0,
            nullptr,
            &view_size,
            nt::view_unmap,
            0,
            PAGE_EXECUTE_READWRITE
        );

        if ( s < 0 )
        {
            CloseHandle( section );
            return 0;
        }

        std::vector< uint8_t > image( image_size, 0 );
        std::memcpy( image.data( ), file, nt->OptionalHeader.SizeOfHeaders );

        auto sec = IMAGE_FIRST_SECTION( nt );
        for ( WORD i = 0; i < nt->FileHeader.NumberOfSections; ++i, ++sec )
        {
            if ( sec->SizeOfRawData )
            {
                std::memcpy(
                    image.data( ) + sec->VirtualAddress,
                    file + sec->PointerToRawData,
                    sec->SizeOfRawData
                );
            }
        }

        SIZE_T written = 0;
        BOOL ok = WriteProcessMemory( process, remote, image.data( ), image_size, &written );

        CloseHandle( section );

        if ( !ok || written != image_size )
            return 0;

        return ( uintptr_t )remote;
    }
}
