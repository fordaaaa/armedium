#pragma once

#include <Windows.h>
#include <cstdint>

namespace nt
{
    using nt_create_section_t = LONG ( NTAPI* )(
        PHANDLE section,
        ACCESS_MASK access,
        void* attributes,
        PLARGE_INTEGER size,
        ULONG page_protect,
        ULONG alloc_attrs,
        HANDLE file
    );

    using nt_map_view_of_section_t = LONG ( NTAPI* )(
        HANDLE section,
        HANDLE process,
        PVOID* base,
        ULONG_PTR zero_bits,
        SIZE_T commit,
        PLARGE_INTEGER offset,
        PSIZE_T view_size,
        ULONG inherit,
        ULONG alloc,
        ULONG protect
    );

    using nt_unmap_view_of_section_t = LONG ( NTAPI* )( HANDLE process, PVOID base );

    using nt_query_system_information_t = LONG ( NTAPI* )(
        ULONG info_class,
        PVOID info,
        ULONG length,
        PULONG returned
    );

    using nt_query_object_t = LONG ( NTAPI* )(
        HANDLE handle,
        ULONG info_class,
        PVOID info,
        ULONG length,
        PULONG returned
    );

    using nt_set_iocompletion_t = LONG ( NTAPI* )(
        HANDLE port,
        PVOID key,
        PVOID status_block,
        LONG status,
        ULONG_PTR information
    );

    using nt_protect_virtual_memory_t = LONG ( NTAPI* )(
        HANDLE process,
        PVOID* base,
        PSIZE_T size,
        ULONG new_protect,
        PULONG old_protect
    );

    using nt_write_virtual_memory_t = LONG ( NTAPI* )(
        HANDLE process,
        PVOID base,
        PVOID buffer,
        SIZE_T size,
        PSIZE_T written
    );

    struct table
    {
        nt_create_section_t create_section;
        nt_map_view_of_section_t map_view;
        nt_unmap_view_of_section_t unmap_view;
        nt_query_system_information_t query_system;
        nt_query_object_t query_object;
        nt_set_iocompletion_t set_iocompletion;
        nt_protect_virtual_memory_t protect_memory;
        nt_write_virtual_memory_t write_memory;
    };

    bool init( );

    const table& api( );

    constexpr ULONG class_extended_handles = 64;
    constexpr ULONG class_object_type = 2;
    constexpr ULONG section_all_access = 14;
    constexpr ULONG sec_commit = 0x8000000;
    constexpr ULONG view_unmap = 2;
}
