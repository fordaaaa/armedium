#include "console.h"

#include <Windows.h>
#include <cstdarg>
#include <cstdio>

static HANDLE g_out = INVALID_HANDLE_VALUE;

static void emit( const char* prefix, const char* fmt, va_list ap )
{
    char body[ 1024 ];
    int n = vsnprintf( body, sizeof( body ), fmt, ap );

    if ( n < 0 )
        return;

    char line[ 1152 ];
    int m = snprintf( line, sizeof( line ), "%s%s\n", prefix, body );

    if ( m < 0 )
        return;

    DWORD written = 0;
    WriteConsoleA( g_out, line, ( DWORD )m, &written, nullptr );
}

namespace console
{
    void init( const char* title )
    {
        AllocConsole( );
        SetConsoleTitleA( title );

        g_out = GetStdHandle( STD_OUTPUT_HANDLE );

        DWORD mode = 0;
        if ( g_out != INVALID_HANDLE_VALUE && GetConsoleMode( g_out, &mode ) )
            SetConsoleMode( g_out, mode | ENABLE_VIRTUAL_TERMINAL_PROCESSING );
    }

    void log( const char* fmt, ... )
    {
        va_list ap;
        va_start( ap, fmt );
        emit( "\x1b[36m[+]\x1b[0m ", fmt, ap );
        va_end( ap );
    }

    void error( const char* fmt, ... )
    {
        va_list ap;
        va_start( ap, fmt );
        emit( "\x1b[31m[!]\x1b[0m ", fmt, ap );
        va_end( ap );
    }

    void wait_close( )
    {
        HANDLE in = GetStdHandle( STD_INPUT_HANDLE );
        FlushConsoleInputBuffer( in );
        WaitForSingleObject( in, INFINITE );
    }
}
