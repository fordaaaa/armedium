#include "ntapi.h"

static nt::table g_api = {};
static bool g_loaded = false;

template< typename T >
static bool resolve( HMODULE m, const char* name, T& out )
{
    out = ( T )GetProcAddress( m, name );
    return out != nullptr;
}

namespace nt
{
    bool init( )
    {
        if ( g_loaded )
            return true;

        HMODULE m = GetModuleHandleA( "ntdll.dll" );
        if ( !m )
            return false;

        if ( !resolve( m, "NtCreateSection", g_api.create_section ) )
            return false;

        if ( !resolve( m, "NtMapViewOfSection", g_api.map_view ) )
            return false;

        if ( !resolve( m, "NtUnmapViewOfSection", g_api.unmap_view ) )
            return false;

        if ( !resolve( m, "NtQuerySystemInformation", g_api.query_system ) )
            return false;

        if ( !resolve( m, "NtQueryObject", g_api.query_object ) )
            return false;

        if ( !resolve( m, "NtSetIoCompletion", g_api.set_iocompletion ) )
            return false;

        if ( !resolve( m, "NtProtectVirtualMemory", g_api.protect_memory ) )
            return false;

        if ( !resolve( m, "NtWriteVirtualMemory", g_api.write_memory ) )
            return false;

        g_loaded = true;
        return true;
    }

    const table& api( )
    {
        return g_api;
    }
}
