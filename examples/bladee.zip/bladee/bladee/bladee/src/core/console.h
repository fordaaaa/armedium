#pragma once

namespace console
{
    void init( const char* title );

    void log( const char* fmt, ... );

    void error( const char* fmt, ... );

    void wait_close( );
}
