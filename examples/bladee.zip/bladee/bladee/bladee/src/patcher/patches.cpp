#include "patches.h"

static const uint8_t bytes_a[] = { 0xEB };
static const uint8_t bytes_b[] = { 0xFF, 0xE0 };
static const uint8_t bytes_c[] = { 0x31, 0xC0 };
static const uint8_t bytes_d[] = { 0x4D, 0x31, 0xC9, 0x90, 0x90, 0x90, 0x90 };
static const uint8_t bytes_e[] = { 0x90, 0x90, 0x90, 0x90, 0x90, 0x90 };

static const uint32_t rvas_a[] =
{
    0x84E0AB, 0x7D823E, 0x8DD8F2, 0x8FC163,
    0xF2C648, 0xF2DB70, 0xF2F50B, 0xF3686E,
    0xF37D7C, 0xF389BC, 0xF53D14, 0xF60A50,
    0xF6AC21,
};

static const uint32_t rvas_b[] = { 0x2C820 };
static const uint32_t rvas_c[] = { 0x946BCB, 0xD44768 };
static const uint32_t rvas_d[] = { 0xF89B8D };
static const uint32_t rvas_e[] = { 0x9D2D6E };

namespace patches
{
    const entry table[] =
    {
        { bytes_a, sizeof( bytes_a ), rvas_a, sizeof( rvas_a ) / sizeof( rvas_a[ 0 ] ) },
        { bytes_b, sizeof( bytes_b ), rvas_b, sizeof( rvas_b ) / sizeof( rvas_b[ 0 ] ) },
        { bytes_c, sizeof( bytes_c ), rvas_c, sizeof( rvas_c ) / sizeof( rvas_c[ 0 ] ) },
        { bytes_d, sizeof( bytes_d ), rvas_d, sizeof( rvas_d ) / sizeof( rvas_d[ 0 ] ) },
        { bytes_e, sizeof( bytes_e ), rvas_e, sizeof( rvas_e ) / sizeof( rvas_e[ 0 ] ) },
    };

    const size_t table_count = sizeof( table ) / sizeof( table[ 0 ] );
}
