#pragma once

#include <cstdint>
#include <cstddef>

namespace patches
{
    struct entry
    {
        const uint8_t* tmpl;
        size_t tmpl_len;
        const uint32_t* rvas;
        size_t rva_count;
    };

    extern const entry table[];
    extern const size_t table_count;
}
