#pragma once

#include <Windows.h>
#include <cstdint>

namespace patcher
{
    bool apply_in_memory( HANDLE process, uintptr_t module_base );

    bool ensure_patched( HANDLE process, uintptr_t module_base );
}
