#include "verifier.h"

#include "patches.h"

#include <cstring>

namespace patcher
{
    bool all_present_in_memory( HANDLE process, uintptr_t module_base, uint32_t* failed_rva )
    {
        uint8_t scratch[ 32 ];

        for ( size_t e = 0; e < patches::table_count; ++e )
        {
            const auto& ent = patches::table[ e ];

            for ( size_t i = 0; i < ent.rva_count; ++i )
            {
                uint32_t rva = ent.rvas[ i ];
                LPCVOID addr = reinterpret_cast< LPCVOID >( module_base + rva );

                SIZE_T got = 0;
                if ( !ReadProcessMemory( process, addr, scratch, ent.tmpl_len, &got ) || got != ent.tmpl_len )
                {
                    if ( failed_rva )
                        *failed_rva = rva;
                    return false;
                }

                if ( std::memcmp( scratch, ent.tmpl, ent.tmpl_len ) != 0 )
                {
                    if ( failed_rva )
                        *failed_rva = rva;
                    return false;
                }
            }
        }

        return true;
    }
}
