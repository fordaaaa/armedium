#pragma once

#include <Windows.h>
#include <cstdint>

namespace patcher
{
    bool all_present_in_memory( HANDLE process, uintptr_t module_base, uint32_t* failed_rva = nullptr );
}
