#include "patcher.h"

#include "patches.h"
#include "verifier.h"
#include "../core/console.h"
#include "../core/ntapi.h"

static bool nt_write( HANDLE process, LPVOID addr, const void* src, SIZE_T size )
{
    SIZE_T put = 0;
    LONG s = nt::api( ).write_memory( process, addr, const_cast< PVOID >( src ), size, &put );
    return s >= 0 && put == size;
}

static bool try_write( HANDLE process, LPVOID addr, const void* src, SIZE_T len, DWORD original_protect, uint32_t rva )
{
    ULONG attempts[] = { PAGE_EXECUTE_READWRITE, PAGE_READWRITE, PAGE_EXECUTE_WRITECOPY, PAGE_WRITECOPY };

    LONG last_status = 0;

    for ( ULONG protect : attempts )
    {
        LPVOID base = addr;
        SIZE_T size = len;
        ULONG old = 0;

        last_status = nt::api( ).protect_memory( process, &base, &size, protect, &old );
        if ( last_status < 0 )
            continue;

        bool ok = nt_write( process, addr, src, len );

        LPVOID rb = addr;
        SIZE_T rs = len;
        ULONG ru = 0;
        nt::api( ).protect_memory( process, &rb, &rs, original_protect, &ru );

        FlushInstructionCache( process, addr, len );

        if ( ok )
            return true;

        console::error( "patcher: rva 0x%X protect ok but write failed", rva );
        return false;
    }

    console::error( "patcher: rva 0x%X all protect rejected ( cur 0x%X, last 0x%08X )", rva, original_protect, ( unsigned )last_status );
    return false;
}

namespace patcher
{
    bool apply_in_memory( HANDLE process, uintptr_t module_base )
    {
        size_t writes = 0;

        for ( size_t e = 0; e < patches::table_count; ++e )
        {
            const auto& ent = patches::table[ e ];

            for ( size_t i = 0; i < ent.rva_count; ++i )
            {
                LPVOID addr = reinterpret_cast< LPVOID >( module_base + ent.rvas[ i ] );

                MEMORY_BASIC_INFORMATION mbi = {};
                if ( VirtualQueryEx( process, addr, &mbi, sizeof( mbi ) ) != sizeof( mbi ) )
                {
                    console::error( "patcher: VirtualQueryEx rva 0x%X failed", ent.rvas[ i ] );
                    return false;
                }

                if ( !try_write( process, addr, ent.tmpl, ent.tmpl_len, mbi.Protect, ent.rvas[ i ] ) )
                    return false;

                ++writes;
            }
        }

        console::log( "patcher: wrote %zu patches in memory", writes );
        return true;
    }

    bool ensure_patched( HANDLE process, uintptr_t module_base )
    {
        uint32_t failed_rva = 0;

        if ( all_present_in_memory( process, module_base, &failed_rva ) )
        {
            console::log( "patcher: all hyperion patches present" );
            return true;
        }

        console::log( "patcher: missing at rva 0x%X, patching live memory", failed_rva );

        if ( !apply_in_memory( process, module_base ) )
            return false;

        if ( !all_present_in_memory( process, module_base, &failed_rva ) )
        {
            console::error( "patcher: post-write verify still missing rva 0x%X", failed_rva );
            return false;
        }

        return true;
    }
}
