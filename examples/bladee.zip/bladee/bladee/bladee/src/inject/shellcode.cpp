#include "shellcode.h"

#include <Windows.h>
#include <intrin.h>

#pragma runtime_checks( "", off )
#pragma strict_gs_check( push, off )
#pragma optimize( "gst", on )

struct list_entry
{
    list_entry* flink;
    list_entry* blink;
};

struct peb_ldr_min
{
    uint8_t pad0[ 0x10 ];
    list_entry in_load_order_module_list;
};

struct peb_min
{
    uint8_t pad0[ 0x18 ];
    peb_ldr_min* ldr;
};

static constexpr uint32_t fnv_seed = 0xB3F5F1FCu;
static constexpr uint32_t fnv_prime = 0x01000193u;
static constexpr uint32_t hash_rtl_add_function_table = 0xEE1D06D7u;

__forceinline static uint32_t fnv1a( const uint8_t* s )
{
    uint32_t h = fnv_seed;
    while ( *s )
    {
        h = ( h ^ ( uint32_t )( int8_t )*s ) * fnv_prime;
        ++s;
    }
    return h;
}

__forceinline static void* find_export_by_hash( uint8_t* dll, uint32_t target )
{
    auto dos = ( IMAGE_DOS_HEADER* )dll;
    auto nt = ( IMAGE_NT_HEADERS64* )( dll + dos->e_lfanew );

    auto& exp_dir = nt->OptionalHeader.DataDirectory[ IMAGE_DIRECTORY_ENTRY_EXPORT ];
    if ( !exp_dir.VirtualAddress )
        return nullptr;

    auto exp = ( IMAGE_EXPORT_DIRECTORY* )( dll + exp_dir.VirtualAddress );
    auto names = ( uint32_t* )( dll + exp->AddressOfNames );
    auto ords = ( uint16_t* )( dll + exp->AddressOfNameOrdinals );
    auto funcs = ( uint32_t* )( dll + exp->AddressOfFunctions );

    for ( uint32_t i = 0; i < exp->NumberOfNames; ++i )
    {
        if ( fnv1a( dll + names[ i ] ) == target )
            return dll + funcs[ ords[ i ] ];
    }

    return nullptr;
}

extern "C" __declspec( safebuffers ) void __fastcall shellcode_entry( shellcode::params* p )
{
    if ( !p )
        return;

    auto base = ( uint8_t* )p->mapped_base;
    auto dos = ( IMAGE_DOS_HEADER* )base;
    auto nt = ( IMAGE_NT_HEADERS64* )( base + dos->e_lfanew );
    auto load_lib = ( HMODULE ( WINAPI* )( LPCSTR ) )p->loadlibrarya;
    auto get_proc = ( FARPROC ( WINAPI* )( HMODULE, LPCSTR ) )p->getprocaddress;

    void* rtl_add = nullptr;

    {
        auto pp = ( peb_min* )__readgsqword( 0x60 );
        list_entry* head = &pp->ldr->in_load_order_module_list;

        for ( list_entry* it = head->flink; it && it != head; it = it->flink )
        {
            uint8_t* dll = *( uint8_t** )( ( uint8_t* )it + 0x30 );
            if ( !dll )
                break;

            void* found = find_export_by_hash( dll, hash_rtl_add_function_table );
            if ( found )
            {
                rtl_add = found;
                break;
            }
        }
    }

    uintptr_t delta = ( uintptr_t )base - ( uintptr_t )nt->OptionalHeader.ImageBase;

    if ( delta )
    {
        auto& reloc = nt->OptionalHeader.DataDirectory[ IMAGE_DIRECTORY_ENTRY_BASERELOC ];

        if ( reloc.Size )
        {
            auto cur = ( IMAGE_BASE_RELOCATION* )( base + reloc.VirtualAddress );
            auto end = ( IMAGE_BASE_RELOCATION* )( ( uint8_t* )cur + reloc.Size );

            while ( cur < end && cur->SizeOfBlock >= sizeof( IMAGE_BASE_RELOCATION ) )
            {
                uint32_t n = ( cur->SizeOfBlock - ( uint32_t )sizeof( IMAGE_BASE_RELOCATION ) ) / 2u;
                auto entries = ( uint16_t* )( cur + 1 );

                for ( uint32_t i = 0; i < n; ++i )
                {
                    if ( ( entries[ i ] >> 12 ) == IMAGE_REL_BASED_DIR64 )
                    {
                        auto patch = ( uintptr_t* )( base + cur->VirtualAddress + ( entries[ i ] & 0xFFFu ) );
                        *patch += delta;
                    }
                }

                cur = ( IMAGE_BASE_RELOCATION* )( ( uint8_t* )cur + cur->SizeOfBlock );
            }
        }
    }

    auto& imp_dir = nt->OptionalHeader.DataDirectory[ IMAGE_DIRECTORY_ENTRY_IMPORT ];

    if ( imp_dir.VirtualAddress )
    {
        auto desc = ( IMAGE_IMPORT_DESCRIPTOR* )( base + imp_dir.VirtualAddress );

        for ( ; desc->Name; ++desc )
        {
            HMODULE mod = load_lib( ( LPCSTR )( base + desc->Name ) );
            if ( !mod )
                continue;

            uint32_t oft = desc->OriginalFirstThunk;
            uint32_t ft = desc->FirstThunk;

            auto src = ( uintptr_t* )( base + ( oft ? oft : ft ) );
            auto dst = ( uintptr_t* )( base + ft );

            while ( *src )
            {
                LPCSTR n = ( *src & IMAGE_ORDINAL_FLAG64 )
                    ? ( LPCSTR )( *src & 0xFFFFu )
                    : ( LPCSTR )( base + *src + 2 );

                *dst = ( uintptr_t )get_proc( mod, n );
                ++src;
                ++dst;
            }
        }
    }

    auto& exc_dir = nt->OptionalHeader.DataDirectory[ IMAGE_DIRECTORY_ENTRY_EXCEPTION ];

    if ( exc_dir.Size && rtl_add )
    {
        auto add = ( BOOLEAN ( WINAPI* )( PRUNTIME_FUNCTION, DWORD, DWORD64 ) )rtl_add;

        add(
            ( PRUNTIME_FUNCTION )( base + exc_dir.VirtualAddress ),
            exc_dir.Size / ( DWORD )sizeof( RUNTIME_FUNCTION ),
            ( DWORD64 )base
        );
    }

    auto entry = ( BOOL ( WINAPI* )( HMODULE, DWORD, LPVOID ) )( base + nt->OptionalHeader.AddressOfEntryPoint );
    entry( ( HMODULE )base, DLL_PROCESS_ATTACH, nullptr );

    uint32_t headers_size = nt->OptionalHeader.SizeOfHeaders;
    auto headers = ( volatile uint8_t* )base;
    for ( uint32_t i = 0; i < headers_size; ++i )
        headers[ i ] = 0;

    p->result = ( uint64_t )base;
    p->completion = 1;
}

extern "C" void shellcode_end( )
{
}

#pragma strict_gs_check( pop )

namespace shellcode
{
    const void* code_ptr( )
    {
        return reinterpret_cast< const void* >( &shellcode_entry );
    }

    size_t code_size( )
    {
        uintptr_t a = reinterpret_cast< uintptr_t >( &shellcode_entry );
        uintptr_t b = reinterpret_cast< uintptr_t >( &shellcode_end );
        return static_cast< size_t >( b - a );
    }
}
