#pragma once

#include <cstdint>
#include <cstddef>

namespace trampoline
{
    constexpr size_t size = 22;

    void build( uint8_t* dst, uintptr_t shellcode_addr, uintptr_t params_addr );
}
