#include "injector.h"

#include "dispatcher.h"
#include "shellcode.h"
#include "trampoline.h"
#include "../core/console.h"
#include "../core/ntapi.h"
#include "../pe/mapper.h"

#include <chrono>
#include <thread>
#include <vector>

static constexpr SIZE_T section_size = 0x4000;
static constexpr SIZE_T shellcode_off = 0x0000;
static constexpr SIZE_T params_off = 0x2000;

static HANDLE create_shared_section( )
{
    auto& api = nt::api( );

    HANDLE section = nullptr;
    LARGE_INTEGER size = {};
    size.QuadPart = section_size;

    LONG s = api.create_section(
        &section,
        nt::section_all_access,
        nullptr,
        &size,
        PAGE_EXECUTE_READWRITE,
        nt::sec_commit,
        nullptr
    );

    if ( s < 0 )
        return nullptr;

    return section;
}

static PVOID map_section_into_target( HANDLE section, HANDLE process )
{
    auto& api = nt::api( );

    PVOID base = nullptr;
    SIZE_T view_size = section_size;

    LONG s = api.map_view(
        section,
        process,
        &base,
        0,
        0,
        nullptr,
        &view_size,
        nt::view_unmap,
        0,
        PAGE_EXECUTE_READWRITE
    );

    if ( s < 0 )
        return nullptr;

    return base;
}

static bool write_shellcode( HANDLE process, uint8_t* view )
{
    SIZE_T written = 0;
    return WriteProcessMemory(
        process,
        view + shellcode_off,
        shellcode::code_ptr( ),
        shellcode::code_size( ),
        &written
    ) != FALSE;
}

static bool write_params( HANDLE process, uint8_t* view, uintptr_t mapped_dll, size_t image_size )
{
    shellcode::params p = {};
    p.mapped_base = mapped_dll;
    p.image_size = image_size;
    p.loadlibrarya = ( uint64_t )&LoadLibraryA;
    p.getprocaddress = ( uint64_t )&GetProcAddress;
    p.completion = 0;
    p.result = 0;

    SIZE_T written = 0;
    return WriteProcessMemory( process, view + params_off, &p, sizeof( p ), &written ) != FALSE;
}

static uintptr_t allocate_trampoline( HANDLE process, uint8_t* view )
{
    uint8_t bytes[ trampoline::size ] = {};

    uintptr_t shellcode_addr = ( uintptr_t )( view + shellcode_off );
    uintptr_t params_addr = ( uintptr_t )( view + params_off );

    trampoline::build( bytes, shellcode_addr, params_addr );

    LPVOID remote = VirtualAllocEx(
        process,
        nullptr,
        sizeof( bytes ),
        MEM_COMMIT | MEM_RESERVE,
        PAGE_EXECUTE_READWRITE
    );

    if ( !remote )
        return 0;

    SIZE_T written = 0;
    BOOL ok = WriteProcessMemory( process, remote, bytes, sizeof( bytes ), &written );

    if ( !ok || written != sizeof( bytes ) )
    {
        VirtualFreeEx( process, remote, 0, MEM_RELEASE );
        return 0;
    }

    return ( uintptr_t )remote;
}

static bool wait_for_completion( HANDLE process, uint8_t* view, uint64_t& result_out )
{
    using namespace std::chrono_literals;

    for ( int tries = 0; tries < 200; ++tries )
    {
        shellcode::params snapshot = {};
        SIZE_T got = 0;

        if ( !ReadProcessMemory( process, view + params_off, &snapshot, sizeof( snapshot ), &got ) )
            return false;

        if ( snapshot.completion != 0 )
        {
            result_out = snapshot.result;
            return true;
        }

        std::this_thread::sleep_for( 50ms );
    }

    return false;
}

static size_t get_image_size( const std::vector< uint8_t >& bytes )
{
    if ( bytes.size( ) < sizeof( IMAGE_DOS_HEADER ) )
        return 0;

    auto dos = ( const IMAGE_DOS_HEADER* )bytes.data( );
    auto nt = ( const IMAGE_NT_HEADERS64* )( bytes.data( ) + dos->e_lfanew );
    return nt->OptionalHeader.SizeOfImage;
}

namespace injector
{
    bool inject( HANDLE process, DWORD pid, const std::vector< uint8_t >& dll_bytes )
    {
        size_t image_size = get_image_size( dll_bytes );
        if ( !image_size )
        {
            console::error( "invalid PE" );
            return false;
        }

        uintptr_t mapped = mapper::map_image( process, dll_bytes );
        if ( !mapped )
        {
            console::error( "manual map failed" );
            return false;
        }

        console::log( "manual mapped at %p", ( void* )mapped );

        HANDLE section = create_shared_section( );
        if ( !section )
        {
            console::error( "section create failed" );
            return false;
        }

        auto view = ( uint8_t* )map_section_into_target( section, process );
        if ( !view )
        {
            console::error( "section map failed" );
            CloseHandle( section );
            return false;
        }

        if ( !write_shellcode( process, view ) )
        {
            console::error( "shellcode write failed" );
            CloseHandle( section );
            return false;
        }

        if ( !write_params( process, view, mapped, image_size ) )
        {
            console::error( "params write failed" );
            CloseHandle( section );
            return false;
        }

        uintptr_t trampoline_remote = allocate_trampoline( process, view );
        if ( !trampoline_remote )
        {
            console::error( "trampoline alloc failed" );
            CloseHandle( section );
            return false;
        }

        if ( !dispatcher::dispatch( process, pid, trampoline_remote ) )
        {
            console::error( "dispatch failed" );
            CloseHandle( section );
            return false;
        }

        uint64_t loaded_base = 0;
        bool ack = wait_for_completion( process, view, loaded_base );

        CloseHandle( section );

        if ( !ack )
        {
            console::error( "shellcode never signaled completion" );
            return false;
        }

        if ( loaded_base == 0 )
        {
            console::error( "loader returned NULL base" );
            return false;
        }

        console::log( "module loaded at %p", ( void* )loaded_base );
        return true;
    }
}
