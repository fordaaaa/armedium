#pragma once

#include <Windows.h>
#include <cstdint>

namespace dispatcher
{
    bool dispatch( HANDLE process, DWORD pid, uintptr_t trampoline_remote );
}
