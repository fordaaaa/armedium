#pragma once

#include <Windows.h>
#include <cstdint>
#include <vector>

namespace injector
{
    bool inject( HANDLE process, DWORD pid, const std::vector< uint8_t >& dll_bytes );
}
