#pragma once

#include <cstdint>
#include <cstddef>

namespace shellcode
{
    struct params
    {
        uint64_t mapped_base;
        uint64_t image_size;
        uint64_t loadlibrarya;
        uint64_t getprocaddress;
        uint64_t completion;
        uint64_t result;
    };

    const void* code_ptr( );

    size_t code_size( );
}

extern "C" void __fastcall shellcode_entry( shellcode::params* p );

extern "C" void shellcode_end( );
