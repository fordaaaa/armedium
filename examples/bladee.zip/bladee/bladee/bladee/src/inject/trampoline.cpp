#include "trampoline.h"

#include <cstring>

namespace trampoline
{
    void build( uint8_t* dst, uintptr_t shellcode_addr, uintptr_t params_addr )
    {
        dst[ 0 ] = 0x48;
        dst[ 1 ] = 0xB8;
        std::memcpy( dst + 2, &shellcode_addr, 8 );

        dst[ 10 ] = 0x48;
        dst[ 11 ] = 0xB9;
        std::memcpy( dst + 12, &params_addr, 8 );

        dst[ 20 ] = 0xFF;
        dst[ 21 ] = 0xE0;
    }
}
