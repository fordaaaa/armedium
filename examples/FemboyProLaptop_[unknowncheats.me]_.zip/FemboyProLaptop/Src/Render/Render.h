﻿#pragma once
#define WIN32_LEAN_AND_MEAN
#include <Windows.h>
#include <d3d11.h>
#include <dwmapi.h>
#include <chrono>
#include <string>
#include <cstring>
#include <vector>
#include <iostream>
#include <algorithm>
#include <cctype>
#include <cstdlib>
#include <sstream>
#include <iomanip>
#include "ImGui/imgui.h"
#include "ImGui/imgui_impl_win32.h"
#include "ImGui/imgui_impl_dx11.h"
#include "../Core/Vars/Vars.h"
#include "../Core/Features/Config/Config.h"
#include "../Core/Features/players/Players.h"
#include "../Core/Features/explorer/bytecode/bytecode.h"
#include "../Core/Features/explorer/decompiler/decompiler.h"
#include "../Game/SDK/SDK.h"
#include "../Core/Globals/Globals.h"
#include "../Core/Cache/Cache.h"

#pragma comment(lib, "d3d11.lib")
#pragma comment(lib, "dwmapi.lib")

extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

LRESULT CALLBACK OverlayWndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    if (ImGui_ImplWin32_WndProcHandler(hWnd, msg, wParam, lParam))
        return true;

    if (msg == WM_DESTROY) {
        PostQuitMessage(0);
        return 0;
    }

    return DefWindowProc(hWnd, msg, wParam, lParam);
}

class OverlayWindow {
private:
    HWND windowHandle;
    WNDCLASSEXW windowClass;

    ID3D11Device* d3dDevice;
    ID3D11DeviceContext* d3dContext;
    IDXGISwapChain* swapChain;
    ID3D11RenderTargetView* renderTarget;

    std::chrono::high_resolution_clock::time_point lastFpsTime;
    int frameCount;
    int currentFPS;
    int activeKeybindCaptureId;
    bool keybindCapturePrimed;
    bool keybindCaptureWaitingMouseRelease;
    uintptr_t selectedPlayerAddr;
    std::string selectedPlayerName;
    std::string playersActionStatus;
    char playersSearch[64];
    char localTeleportInput[256];
    std::string localTeleportStatus;
    char explorerBytecodeInput[32768];
    char explorerDecompilerOutput[65536];
    char explorerScriptAddress[64];
    int explorerResourceId;
    int explorerScriptType;
    std::string explorerBytecodeStatus;
    std::string explorerDecompilerStatus;
    std::string explorerLastBlob;
    uintptr_t explorerSelectedInstanceAddr;
    decompiler::decompiler_t explorerDecompiler;
    ImFont* menuFont;
    ImFont* espFont;
    ImFont* watermarkFont;

    std::string HexPreview(const std::string& bytes, size_t maxBytes = 128) {
        if (bytes.empty()) {
            return "";
        }

        std::ostringstream oss;
        oss << std::hex << std::uppercase << std::setfill('0');
        const size_t count = bytes.size() < maxBytes ? bytes.size() : maxBytes;
        for (size_t i = 0; i < count; ++i) {
            oss << std::setw(2) << static_cast<int>(static_cast<unsigned char>(bytes[i]));
            if (i + 1 < count) oss << ' ';
        }
        if (bytes.size() > maxBytes) {
            oss << " ...";
        }
        return oss.str();
    }

    void SetTextBuffer(char* buffer, size_t bufferSize, const std::string& text) {
        if (bufferSize == 0) return;
        memset(buffer, 0, bufferSize);
        strncpy_s(buffer, bufferSize, text.c_str(), _TRUNCATE);
    }

    bool TryParseAddress(const char* text, uintptr_t& outAddress) {
        outAddress = 0;
        if (!text) return false;

        while (*text && std::isspace(static_cast<unsigned char>(*text))) {
            ++text;
        }
        if (*text == '\0') return false;

        char* endPtr = nullptr;
        const unsigned long long parsed = _strtoui64(text, &endPtr, 0);
        if (endPtr == text) return false;

        while (*endPtr && std::isspace(static_cast<unsigned char>(*endPtr))) {
            ++endPtr;
        }
        if (*endPtr != '\0') return false;
        if (parsed == 0ull) return false;

        outAddress = static_cast<uintptr_t>(parsed);
        return true;
    }

    static bool IsDecompilerScriptClass(const std::string& className) {
        return className == "LocalScript" || className == "ModuleScript";
    }

    void SelectScriptForDecompiler(RBX::RbxInstance instance, const std::string& className) {
        sprintf_s(explorerScriptAddress, sizeof(explorerScriptAddress), "0x%llX", static_cast<unsigned long long>(instance.Addr));
        explorerScriptType = (className == "ModuleScript") ? 1 : 0;
        explorerSelectedInstanceAddr = instance.Addr;

        const std::string nodeName = instance.GetName().empty() ? "<unnamed>" : instance.GetName();
        explorerDecompilerStatus = "Selected " + className + ": " + nodeName;
    }

    void RenderExplorerInstanceNode(RBX::RbxInstance instance, int depth = 0) {
        if (instance.Addr == 0 || depth > 7) {
            return;
        }

        std::string className = instance.GetClass();
        if (className.empty()) className = "Unknown";

        std::string nodeName = instance.GetName();
        if (nodeName.empty()) nodeName = "<unnamed>";

        const bool isScriptNode = IsDecompilerScriptClass(className);

        auto children = instance.GetChildList();
        const bool hasChildren = !children.empty();

        ImGuiTreeNodeFlags flags = ImGuiTreeNodeFlags_SpanAvailWidth;
        if (!hasChildren) flags |= ImGuiTreeNodeFlags_Leaf;
        if (depth == 0) flags |= ImGuiTreeNodeFlags_DefaultOpen;
        if (explorerSelectedInstanceAddr == instance.Addr) flags |= ImGuiTreeNodeFlags_Selected;

        std::ostringstream label;
        label << nodeName << " [" << className << "]##ExplorerNode_" << std::hex << instance.Addr;

        const bool opened = ImGui::TreeNodeEx(label.str().c_str(), flags);

        if (ImGui::IsItemClicked()) {
            explorerSelectedInstanceAddr = instance.Addr;
            if (isScriptNode) {
                SelectScriptForDecompiler(instance, className);
            }
        }

        if (opened) {
            if (hasChildren) {
                constexpr size_t maxChildrenToRender = 256;
                size_t rendered = 0;
                for (const auto& child : children) {
                    if (rendered >= maxChildrenToRender) {
                        ImGui::TextDisabled("... more children hidden for performance");
                        break;
                    }
                    RenderExplorerInstanceNode(child, depth + 1);
                    ++rendered;
                }
            }
            ImGui::TreePop();
        }
    }

    bool CopyTextToClipboard(const std::string& text) {
        if (!OpenClipboard(windowHandle)) {
            return false;
        }

        EmptyClipboard();

        HGLOBAL hMem = GlobalAlloc(GMEM_MOVEABLE, text.size() + 1);
        if (!hMem) {
            CloseClipboard();
            return false;
        }

        void* memPtr = GlobalLock(hMem);
        if (!memPtr) {
            GlobalFree(hMem);
            CloseClipboard();
            return false;
        }

        memcpy(memPtr, text.c_str(), text.size() + 1);
        GlobalUnlock(hMem);

        if (!SetClipboardData(CF_TEXT, hMem)) {
            GlobalFree(hMem);
            CloseClipboard();
            return false;
        }

        CloseClipboard();
        return true;
    }

    std::string GetKeyName(int vk) {
        if (vk <= 0) return "None";

        switch (vk) {
            case VK_LBUTTON: return "Mouse Left";
            case VK_RBUTTON: return "Mouse Right";
            case VK_MBUTTON: return "Mouse Middle";
            case VK_XBUTTON1: return "Mouse X1";
            case VK_XBUTTON2: return "Mouse X2";
            case VK_SHIFT: return "Shift";
            case VK_LSHIFT: return "LShift";
            case VK_RSHIFT: return "RShift";
            case VK_CONTROL: return "Ctrl";
            case VK_LCONTROL: return "LCtrl";
            case VK_RCONTROL: return "RCtrl";
            case VK_MENU: return "Alt";
            case VK_LMENU: return "LAlt";
            case VK_RMENU: return "RAlt";
            case VK_SPACE: return "Space";
            case VK_INSERT: return "Insert";
            case VK_DELETE: return "Delete";
            case VK_HOME: return "Home";
            case VK_END: return "End";
            case VK_PRIOR: return "PageUp";
            case VK_NEXT: return "PageDown";
            case VK_UP: return "Up";
            case VK_DOWN: return "Down";
            case VK_LEFT: return "Left";
            case VK_RIGHT: return "Right";
            case VK_TAB: return "Tab";
            case VK_RETURN: return "Enter";
            case VK_ESCAPE: return "Escape";
            case VK_BACK: return "Backspace";
            default: break;
        }

        UINT scan = MapVirtualKeyA(static_cast<UINT>(vk), MAPVK_VK_TO_VSC);
        LONG lParam = static_cast<LONG>(scan << 16);
        char name[128] = {};
        if (GetKeyNameTextA(lParam, name, static_cast<int>(sizeof(name))) > 0) {
            return std::string(name);
        }

        return "Key " + std::to_string(vk);
    }

    int PollCapturedKey() {
        const int prioritized[] = { VK_LBUTTON, VK_RBUTTON, VK_MBUTTON, VK_XBUTTON1, VK_XBUTTON2 };
        for (int vk : prioritized) {
            if (GetAsyncKeyState(vk) & 0x1) return vk;
        }

        for (int vk = 8; vk < 256; vk++) {
            if (vk == VK_LBUTTON || vk == VK_RBUTTON || vk == VK_MBUTTON || vk == VK_XBUTTON1 || vk == VK_XBUTTON2) continue;
            if (GetAsyncKeyState(vk) & 0x1) return vk;
        }

        return 0;
    }

    bool IsAnyMouseButtonDown() {
        if (GetAsyncKeyState(VK_LBUTTON) & 0x8000) return true;
        if (GetAsyncKeyState(VK_RBUTTON) & 0x8000) return true;
        if (GetAsyncKeyState(VK_MBUTTON) & 0x8000) return true;
        if (GetAsyncKeyState(VK_XBUTTON1) & 0x8000) return true;
        if (GetAsyncKeyState(VK_XBUTTON2) & 0x8000) return true;
        return false;
    }

    void RenderKeybindControl(const char* label, int& keyValue, int controlId) {
        ImGui::TextUnformatted(label);

        const bool isCapturing = (activeKeybindCaptureId == controlId);
        std::string btnText = isCapturing ? "Press any key..." : GetKeyName(keyValue);
        btnText += "##keybind_btn_" + std::to_string(controlId);

        if (ImGui::Button(btnText.c_str(), ImVec2(170.0f, 0.0f))) {
            activeKeybindCaptureId = controlId;
            keybindCapturePrimed = true;
            keybindCaptureWaitingMouseRelease = true;
        }

        if (!isCapturing) return;

        ImGui::SameLine();
        ImGui::TextDisabled("Click then press keyboard/mouse key");

        if (keybindCapturePrimed) {
            keybindCapturePrimed = false;
            return;
        }

        if (keybindCaptureWaitingMouseRelease) {
            if (IsAnyMouseButtonDown()) {
                return;
            }
            keybindCaptureWaitingMouseRelease = false;
            return;
        }

        int captured = PollCapturedKey();
        if (captured != 0) {
            keyValue = captured;
            activeKeybindCaptureId = 0;
            return;
        }

        if (ImGui::IsKeyPressed(ImGuiKey_Escape, false)) {
            activeKeybindCaptureId = 0;
            keybindCaptureWaitingMouseRelease = false;
        }
    }

    void SetupD3D11(HWND hwnd) {
        DXGI_SWAP_CHAIN_DESC sd;
        ZeroMemory(&sd, sizeof(sd));
        sd.BufferCount = 2;
        sd.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
        sd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
        sd.OutputWindow = hwnd;
        sd.SampleDesc.Count = 1;
        sd.Windowed = TRUE;
        sd.SwapEffect = DXGI_SWAP_EFFECT_DISCARD;
        sd.Flags = DXGI_SWAP_CHAIN_FLAG_ALLOW_MODE_SWITCH;

        D3D_FEATURE_LEVEL levels[] = { D3D_FEATURE_LEVEL_11_0, D3D_FEATURE_LEVEL_10_0 };
        D3D_FEATURE_LEVEL obtainedLevel;

        HRESULT hr = D3D11CreateDeviceAndSwapChain(
            nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, 0,
            levels, 2, D3D11_SDK_VERSION, &sd,
            &swapChain, &d3dDevice, &obtainedLevel, &d3dContext
        );

        if (hr == DXGI_ERROR_UNSUPPORTED) {
            D3D11CreateDeviceAndSwapChain(
                nullptr, D3D_DRIVER_TYPE_WARP, nullptr, 0,
                levels, 2, D3D11_SDK_VERSION, &sd,
                &swapChain, &d3dDevice, &obtainedLevel, &d3dContext
            );
        }

        ID3D11Texture2D* backBuffer = nullptr;
        swapChain->GetBuffer(0, IID_PPV_ARGS(&backBuffer));
        if (backBuffer) {
            d3dDevice->CreateRenderTargetView(backBuffer, nullptr, &renderTarget);
            backBuffer->Release();
        }
    }

    void CleanupD3D11() {
        if (renderTarget) { renderTarget->Release(); renderTarget = nullptr; }
        if (swapChain) { swapChain->Release(); swapChain = nullptr; }
        if (d3dContext) { d3dContext->Release(); d3dContext = nullptr; }
        if (d3dDevice) { d3dDevice->Release(); d3dDevice = nullptr; }
    }

    void SetupImGuiStyle() {
        ImGui::StyleColorsDark();
        ImGuiStyle& style = ImGui::GetStyle();
        ImVec4* colors = style.Colors;

        style.WindowRounding = 0.0f;
        style.ChildRounding = 0.0f;
        style.FrameRounding = 0.0f;
        style.ScrollbarRounding = 0.0f;
        style.GrabRounding = 0.0f;
        style.PopupRounding = 0.0f;
        style.TabRounding = 0.0f;

        style.WindowBorderSize = 1.0f;
        style.FrameBorderSize = 1.0f;
        style.PopupBorderSize = 1.0f;
        style.TabBorderSize = 1.0f;

        style.WindowPadding = ImVec2(8.0f, 8.0f);
        style.FramePadding = ImVec2(2.0f, 2.0f);
        style.ItemSpacing = ImVec2(8.0f, 6.0f);
        style.ItemInnerSpacing = ImVec2(3.0f, 3.0f);
        style.CellPadding = ImVec2(2.0f, 1.0f);

        style.WindowMinSize = ImVec2(0.0f, 0.0f);
        style.GrabMinSize = 10.0f;
        style.ScrollbarSize = 4.0f;

        colors[ImGuiCol_WindowBg] = ImColor(14, 14, 18, 245);
        colors[ImGuiCol_ChildBg] = ImColor(20, 20, 24, 255);
        colors[ImGuiCol_PopupBg] = ImColor(16, 16, 20, 245);
        colors[ImGuiCol_MenuBarBg] = ImColor(24, 24, 30, 255);

        colors[ImGuiCol_Border] = ImColor(148, 214, 255, 180); // #94D6FF
        colors[ImGuiCol_BorderShadow] = ImColor(0, 0, 0, 0);
        colors[ImGuiCol_Separator] = ImColor(102, 178, 255, 160); // #66B2FF

        colors[ImGuiCol_Text] = ImColor(255, 255, 255, 255); // #FFFFFF
        colors[ImGuiCol_TextDisabled] = ImColor(180, 180, 190, 255);

        colors[ImGuiCol_FrameBg] = ImColor(25, 25, 30, 255);
        colors[ImGuiCol_FrameBgHovered] = ImColor(35, 35, 42, 255);
        colors[ImGuiCol_FrameBgActive] = ImColor(42, 42, 52, 255);

        colors[ImGuiCol_Button] = ImColor(255, 102, 153, 200);       // #FF6699
        colors[ImGuiCol_ButtonHovered] = ImColor(255, 148, 184, 230); // #FF94B8
        colors[ImGuiCol_ButtonActive] = ImColor(102, 178, 255, 230);  // #66B2FF

        colors[ImGuiCol_CheckMark] = ImColor(255, 255, 255, 255);    // #FFFFFF
        colors[ImGuiCol_SliderGrab] = ImColor(102, 178, 255, 255);   // #66B2FF
        colors[ImGuiCol_SliderGrabActive] = ImColor(148, 214, 255, 255); // #94D6FF
        colors[ImGuiCol_TextSelectedBg] = ImColor(255, 148, 184, 128); // #FF94B8

        colors[ImGuiCol_ScrollbarBg] = ImVec4(0.0f, 0.0f, 0.0f, 0.0f);
        colors[ImGuiCol_ScrollbarGrab] = ImColor(102, 178, 255, 128); // #66B2FF
        colors[ImGuiCol_ScrollbarGrabHovered] = ImColor(148, 214, 255, 170); // #94D6FF
        colors[ImGuiCol_ScrollbarGrabActive] = ImColor(255, 148, 184, 190); // #FF94B8

        colors[ImGuiCol_Header] = ImColor(102, 178, 255, 110); // #66B2FF
        colors[ImGuiCol_HeaderHovered] = ImColor(148, 214, 255, 150); // #94D6FF
        colors[ImGuiCol_HeaderActive] = ImColor(255, 148, 184, 170); // #FF94B8

        colors[ImGuiCol_Tab] = ImColor(28, 28, 34, 255);
        colors[ImGuiCol_TabHovered] = ImColor(255, 148, 184, 190); // #FF94B8
        colors[ImGuiCol_TabActive] = ImColor(255, 102, 153, 220); // #FF6699
        colors[ImGuiCol_TabUnfocused] = ImColor(24, 24, 30, 255);
        colors[ImGuiCol_TabUnfocusedActive] = ImColor(102, 178, 255, 180); // #66B2FF

        colors[ImGuiCol_TitleBg] = ImColor(14, 14, 18, 255);
        colors[ImGuiCol_TitleBgActive] = ImColor(255, 102, 153, 185); // #FF6699
        colors[ImGuiCol_TitleBgCollapsed] = ImColor(14, 14, 18, 190);
    }

    void UpdateFPS() {
        frameCount++;
        auto currentTime = std::chrono::high_resolution_clock::now();
        auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(currentTime - lastFpsTime).count();

        if (elapsed >= 1000) {
            currentFPS = frameCount;
            frameCount = 0;
            lastFpsTime = currentTime;
        }
    }

public:
    ImFont* GetMenuFont() const { return menuFont; }
    ImFont* GetEspFont() const { return espFont; }
    ImFont* GetWatermarkFont() const { return watermarkFont; }

    std::string GetLocalUsername() {
        if (Globals::localPlayer.Addr == 0) return "";
        return Globals::localPlayer.GetName();
    }

    std::string GetLocalDisplayName() {
        if (Globals::localPlayer.Addr == 0) {
            return GetLocalUsername();
        }

        try {
            const uintptr_t playerDisplayNameAddr = Coms->ReadMemory<uintptr_t>(
                Globals::localPlayer.Addr + Offsets::Player::DisplayName
            );

            if (playerDisplayNameAddr != 0 && playerDisplayNameAddr < 0x10000000000000) {
                std::string displayName = Coms->ReadGameString(playerDisplayNameAddr);
                if (!displayName.empty() && displayName.length() < 256) {
                    return displayName;
                }
            }
        }
        catch (...) {

        }

        try {
            auto character = Globals::localPlayer.GetModelRef();
            if (character.Addr != 0) {
                auto humanoid = character.FindChild("Humanoid");
                if (humanoid.Addr != 0) {
                    const uintptr_t displayNameAddr = Coms->ReadMemory<uintptr_t>(
                        humanoid.Addr + Offsets::Humanoid::DisplayName
                    );
                    if (displayNameAddr != 0 && displayNameAddr < 0x10000000000000) {
                        std::string displayName = Coms->ReadGameString(displayNameAddr);
                        if (!displayName.empty() && displayName.length() < 256) {
                            return displayName;
                        }
                    }
                }
            }
        }
        catch (...) {
            
        }

        return GetLocalUsername();
    }

    int GetPlayerCount() {
        if (Globals::players.Addr != 0) {
                auto list = Globals::players.GetChildList();
                if (!list.empty()) {
                return static_cast<int>(list.size());
            }
        }

        size_t cacheSize = PlayerCache::players.size();
        if (cacheSize > 0) return static_cast<int>(cacheSize) + 1;

        return 1;
    }

    bool IsInGame() {
        if (GetPlayerCount() > 1) return true;
        if (Globals::localPlayer.Addr != 0) {
            auto model = Globals::localPlayer.GetModelRef();
            if (model.Addr != 0) return true;
        }
        return false;
    }

    int GetGameFPS() {
        if (Globals::dataModel.Addr == 0) return 0;
        auto runService = Globals::dataModel.FindChildByClass("RunService");
        if (runService.Addr == 0) return 0;

        float fps = Coms->ReadMemory<float>(runService.Addr + Offsets::RunService::HeartbeatFPS);
        if (fps > 0.1f && fps < 10000.0f) return static_cast<int>(fps + 0.5f);

        int ifps = Coms->ReadMemory<int>(runService.Addr + Offsets::RunService::HeartbeatFPS);
        if (ifps > 0 && ifps < 10000) return ifps;
        return 0;
    }

    ImU32 GetWatermarkColor() {
        if (Vars::Watermark::colorMode == 0) {
            int r = static_cast<int>(Vars::Watermark::colorR * 255.0f);
            int g = static_cast<int>(Vars::Watermark::colorG * 255.0f);
            int b = static_cast<int>(Vars::Watermark::colorB * 255.0f);
            int a = static_cast<int>(Vars::Watermark::colorA * 255.0f);
            return IM_COL32(r, g, b, a);
        }

        double t = GetTickCount64() / 1000.0;
        float hue = static_cast<float>(fmod(t * Vars::Watermark::rainbowSpeed, 1.0));
        float r, g, b;
        ImGui::ColorConvertHSVtoRGB(hue, 1.0f, 1.0f, r, g, b);
        return IM_COL32(static_cast<int>(r * 255.0f), static_cast<int>(g * 255.0f), static_cast<int>(b * 255.0f), static_cast<int>(Vars::Watermark::colorA * 255.0f));
    }

    std::string BuildWatermarkText() {
        if (!Vars::UI::watermarkEnabled && !Vars::Watermark::enabled)
            return "";

        std::vector<std::string> parts;

        parts.push_back("FemboyProLaptop");

        if (Vars::Watermark::showPlayerCount) {
            parts.push_back("Player: " + std::to_string(GetPlayerCount()));
        }

        if (Vars::Watermark::showUsername || Vars::Watermark::showDisplayName) {
            const std::string username = GetLocalUsername();
            const std::string displayName = GetLocalDisplayName();
            parts.push_back("User: " + PlayerCache::FormatPlayerLabel(username, displayName));
        }

        std::string result;
        for (size_t i = 0; i < parts.size(); i++) {
            if (i != 0)
                result += " | ";
            result += parts[i];
        }

        return result;
    }

    OverlayWindow() : windowHandle(nullptr), d3dDevice(nullptr), d3dContext(nullptr),
        swapChain(nullptr), renderTarget(nullptr), frameCount(0), currentFPS(0),
        activeKeybindCaptureId(0), keybindCapturePrimed(false), keybindCaptureWaitingMouseRelease(false),
        selectedPlayerAddr(0),
        explorerResourceId(1), explorerScriptType(0),
        explorerSelectedInstanceAddr(0),
        menuFont(nullptr), espFont(nullptr), watermarkFont(nullptr) {
        ZeroMemory(&windowClass, sizeof(windowClass));
        ZeroMemory(playersSearch, sizeof(playersSearch));
        ZeroMemory(localTeleportInput, sizeof(localTeleportInput));
        ZeroMemory(explorerBytecodeInput, sizeof(explorerBytecodeInput));
        ZeroMemory(explorerDecompilerOutput, sizeof(explorerDecompilerOutput));
        ZeroMemory(explorerScriptAddress, sizeof(explorerScriptAddress));
        lastFpsTime = std::chrono::high_resolution_clock::now();
    }

    bool Initialize() {
        windowClass.cbSize = sizeof(WNDCLASSEXW);
        windowClass.style = CS_HREDRAW | CS_VREDRAW;
        windowClass.lpfnWndProc = OverlayWndProc;
        windowClass.hInstance = GetModuleHandleW(nullptr);
        windowClass.lpszClassName = L"Roblox External";

        if (!RegisterClassExW(&windowClass)) return false;

        int screenW = GetSystemMetrics(SM_CXSCREEN);
        int screenH = GetSystemMetrics(SM_CYSCREEN);

        windowHandle = CreateWindowExW(
            WS_EX_TOPMOST | WS_EX_TRANSPARENT | WS_EX_LAYERED | WS_EX_TOOLWINDOW,
            windowClass.lpszClassName, L"Roblox External",
            WS_POPUP, 0, 0, screenW, screenH,
            nullptr, nullptr, windowClass.hInstance, nullptr
        );

        if (!windowHandle) return false;

        SetWindowDisplayAffinity(windowHandle, 0x00000000);

        SetLayeredWindowAttributes(windowHandle, RGB(0, 0, 0), 255, LWA_ALPHA);
        MARGINS margins = { -1, -1, -1, -1 };
        DwmExtendFrameIntoClientArea(windowHandle, &margins);

        ShowWindow(windowHandle, SW_SHOW);
        UpdateWindow(windowHandle);
        SetupD3D11(windowHandle);

        IMGUI_CHECKVERSION();
        ImGui::CreateContext();
        ImGuiIO& io = ImGui::GetIO();
        io.IniFilename = nullptr;

        menuFont = io.Fonts->AddFontFromFileTTF("C:\\Windows\\Fonts\\arial.ttf", 15.0f);
        espFont = io.Fonts->AddFontFromFileTTF("C:\\Windows\\Fonts\\tahoma.ttf", 14.0f);
        watermarkFont = io.Fonts->AddFontFromFileTTF("C:\\Windows\\Fonts\\consola.ttf", 12.0f);

        SetupImGuiStyle();

        ImGui_ImplWin32_Init(windowHandle);
        ImGui_ImplDX11_Init(d3dDevice, d3dContext);

        io.Fonts->Build();

        ImFont* defaultFont = io.Fonts->Fonts[0];
        if (!defaultFont) {
            return false;
        }

        if (!menuFont) menuFont = defaultFont;
        if (!espFont) espFont = defaultFont;
        if (!watermarkFont) watermarkFont = defaultFont;

        return true;
    }

   void BeginFrame() {
       UpdateFPS();
       Vars::UI::currentFPS = currentFPS;

       MSG msg;
       while (PeekMessage(&msg, nullptr, 0, 0, PM_REMOVE)) {
           TranslateMessage(&msg);
           DispatchMessage(&msg);
       }

       if (Vars::menuOpen) {
           SetWindowLong(windowHandle, GWL_EXSTYLE, WS_EX_TOPMOST | WS_EX_LAYERED | WS_EX_TOOLWINDOW);
       }
       else {
           SetWindowLong(windowHandle, GWL_EXSTYLE, WS_EX_TOPMOST | WS_EX_TRANSPARENT | WS_EX_LAYERED | WS_EX_TOOLWINDOW);
       }

       if (Vars::UI::antiScreenShare) {
           SetWindowDisplayAffinity(windowHandle, 0x00000011); 
       }
       else {
           SetWindowDisplayAffinity(windowHandle, 0x00000000);
       }

       ImGui_ImplDX11_NewFrame();
       ImGui_ImplWin32_NewFrame();
       ImGui::NewFrame();
   }

    void EndFrame() {
        ImGui::Render();
        const float clear_color_with_alpha[4] = { 0.0f, 0.0f, 0.0f, 0.0f };
        d3dContext->OMSetRenderTargets(1, &renderTarget, nullptr);
        d3dContext->ClearRenderTargetView(renderTarget, clear_color_with_alpha);
        ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
        swapChain->Present(Vars::UI::vsyncEnabled ? 1 : 0, 0);
    }

    void Cleanup() {
        ImGui_ImplDX11_Shutdown();
        ImGui_ImplWin32_Shutdown();
        ImGui::DestroyContext();
        CleanupD3D11();
        if (windowHandle) {
            DestroyWindow(windowHandle);
            windowHandle = nullptr;
        }
        UnregisterClassW(windowClass.lpszClassName, windowClass.hInstance);
    }

    void RenderMenu() {
        if (!Vars::menuOpen) return;

        if (menuFont) {
            ImGui::PushFont(menuFont);
        }

        ImGui::SetNextWindowSize(ImVec2(760, 520), ImGuiCond_Once);

        if (ImGui::Begin("T4", &Vars::menuOpen, ImGuiWindowFlags_NoCollapse)) {

            static const char* gameProfiles[] = { "Universal (Default)" };
            static int activeGameProfile = 0;

            ImGui::TextDisabled("Game Profile:");
            ImGui::SameLine(0.0f, 6.0f);
            ImGui::SetNextItemWidth(200.0f);
            ImGui::Combo("##GameProfileCombo", &activeGameProfile, gameProfiles, IM_ARRAYSIZE(gameProfiles));
            ImGui::SameLine(ImGui::GetWindowWidth() - 140);
            ImGui::TextDisabled("FPS: %d", Vars::UI::currentFPS);

            ImGui::Spacing();
            ImGui::Separator();

            ImGui::Text("FemBoyProLaptop External");

            ImGui::Spacing();
            ImGui::Separator();
            ImGui::Spacing();

            if (ImGui::BeginTabBar("##TopTabBar", ImGuiTabBarFlags_NoCloseWithMiddleMouseButton)) {
                
                if (ImGui::BeginTabItem(" Aimbot ")) {
                    ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 5);
                    ImGui::BeginChild("##AimbotContent", ImVec2(0, -35), true);
                    RenderAimbotTab();
                    ImGui::EndChild();
                    ImGui::EndTabItem();
                }

                if (ImGui::BeginTabItem(" Silent Aim ")) {
                    ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 5);
                    ImGui::BeginChild("##SilentAimContent", ImVec2(0, -35), true);
                    RenderSilentAimTab();
                    ImGui::EndChild();
                    ImGui::EndTabItem();
                }
                
                if (ImGui::BeginTabItem(" Visuals ")) {
                    ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 5);
                    ImGui::BeginChild("##VisualsContent", ImVec2(0, -35), true);
                    RenderVisualsTab();
                    ImGui::EndChild();
                    ImGui::EndTabItem();
                }
                
                if (ImGui::BeginTabItem(" Local Player ")) {
                    ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 5);
                    ImGui::BeginChild("##LocalContent", ImVec2(0, -35), true);
                    RenderLocalTab();
                    ImGui::EndChild();
                    ImGui::EndTabItem();
                }

                if (ImGui::BeginTabItem(" Players ")) {
                    ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 5);
                    ImGui::BeginChild("##PlayersContent", ImVec2(0, -35), true);
                    RenderPlayersTab();
                    ImGui::EndChild();
                    ImGui::EndTabItem();
                }

                if (ImGui::BeginTabItem(" Explorer ")) {
                    ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 5);
                    ImGui::BeginChild("##ExplorerContent", ImVec2(0, -35), true);
                    RenderExplorerTab();
                    ImGui::EndChild();
                    ImGui::EndTabItem();
                }

                if (ImGui::BeginTabItem(" Lighting ")) {
                    ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 5);
                    ImGui::BeginChild("##LightingContent", ImVec2(0, -35), true);
                    RenderLightingTab();
                    ImGui::EndChild();
                    ImGui::EndTabItem();
                }
                
                if (ImGui::BeginTabItem(" Settings ")) {
                    ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 5);
                    ImGui::BeginChild("##SettingsContent", ImVec2(0, -35), true);
                    RenderSettingsTab();
                    ImGui::EndChild();
                    ImGui::EndTabItem();
                }
                
                ImGui::EndTabBar();
            }

            ImGui::SetCursorPosY(ImGui::GetWindowHeight() - 30);
            ImGui::Separator();
        }
        ImGui::End();

        if (menuFont) {
            ImGui::PopFont();
        }
    }

    void RenderAimbotTab() {
        ImGui::Text("Aimbot Customization");
        ImGui::Separator();
        ImGui::Spacing();

        ImGui::Checkbox("Enable Aimbot", &Vars::Aimbot::enabled);
        ImGui::Checkbox("Show FOV Circle", &Vars::aimbotDrawFov);
        ImGui::Checkbox("Use FOV for Selection", &Vars::Aimbot::aimbotUseFov);
        ImGui::Checkbox("Sticky Target", &Vars::Aimbot::stickyTarget);

        ImGui::Spacing();
        ImGui::Text("FOV Radius");
        ImGui::SliderFloat("FOV##Aimbot", &Vars::Aimbot::fovRadius, 10.0f, 500.0f, "%.0f px");

        ImGui::Text("Smoothing Speed");
        ImGui::SliderFloat("Smoothing##Aimbot", &Vars::Aimbot::smoothing, 1.0f, 20.0f, "%.1f");

        ImGui::Text("Prediction Factor");
        ImGui::SliderFloat("Prediction##Aimbot", &Vars::Aimbot::predictionFactor, 0.0f, 0.35f, "%.3f");

        ImGui::Text("Lerp Speed");
        ImGui::SliderFloat("Lerp##Aimbot", &Vars::Aimbot::lerpSpeed, 0.05f, 1.00f, "%.2f");

        ImGui::Text("Deadzone Pixels");
        ImGui::SliderFloat("Deadzone##Aimbot", &Vars::Aimbot::deadzonePixels, 0.5f, 12.0f, "%.1f px");

        ImGui::Text("Max Aim Distance (0 = unlimited)");
        ImGui::SliderFloat("Max Distance##Aimbot", &Vars::Aimbot::maxAimDistance, 0.0f, 3000.0f, "%.0f");

        ImGui::Spacing();
        ImGui::Text("Aim Target Location");
        const char* targets[] = { "Head", "HumanoidRootPart" };
        ImGui::Combo("##TargetAimbot", &Vars::Aimbot::aimTarget, targets, 2);

        ImGui::Checkbox("Ignore Whitelisted Players", &Vars::Aimbot::ignoreWhitelisted);
        ImGui::Checkbox("Skip Teammates##Aimbot", &Vars::Aimbot::aimbotTeamCheck);
        ImGui::Checkbox("Skip Knocked Players##Aimbot", &Vars::Aimbot::aimbotKnockCheck);
        ImGui::Checkbox("Skip Dead/Zero Health##Aimbot", &Vars::Aimbot::aimbotHealthCheck);
        ImGui::Checkbox("Trigger Bot##Aimbot", &Vars::Aimbot::aimbotTriggerBot);

        ImGui::Spacing();
        ImGui::Text("Aimbot Activation Key");
        RenderKeybindControl("AimbotKeybind", Vars::Aimbot::aimbotKey, 1001);
    }

    void RenderSilentAimTab() {
        ImGui::Text("Silent Aim Customization");
        ImGui::Separator();
        ImGui::Spacing();

        ImGui::Checkbox("Enable Silent Aim", &Vars::SilentAim::silentAimEnabled);
        ImGui::Checkbox("Draw Silent FOV", &Vars::silentDrawFov);
        ImGui::Checkbox("Sticky Silent Target", &Vars::SilentAim::silentStickyAim);
        ImGui::Checkbox("Use Aimbot Target Part", &Vars::SilentAim::silentUseAimbotTarget);
        ImGui::Checkbox("Use FOV for Silent Selection", &Vars::SilentAim::silentUseFov);
        ImGui::Checkbox("Skip Teammates##Silent", &Vars::SilentAim::silentTeamCheck);
        ImGui::Checkbox("Skip Knocked Players##Silent", &Vars::SilentAim::silentKnockCheck);
        ImGui::Checkbox("Skip Dead/Zero Health##Silent", &Vars::SilentAim::silentHealthCheck);
        ImGui::Checkbox("Trigger Bot##Silent", &Vars::SilentAim::silentTriggerBot);
        ImGui::SliderFloat("Silent FOV##Silent", &Vars::SilentAim::silentFovRadius, 10.0f, 500.0f, "%.0f px");
        static const char* silentTargetLabels[] = { "Head", "HumanoidRootPart" };
        ImGui::Combo("Silent Target Part##Silent", &Vars::SilentAim::silentTargetPart, silentTargetLabels, 2);
        ImGui::Text("Silent Aim Key");
        RenderKeybindControl("SilentAimKeybind", Vars::SilentAim::silentAimKey, 1004);
    }

    void RenderVisualsTab() {
        ImGui::Text("Player ESP Customization");
        ImGui::Separator();
        ImGui::Spacing();

        ImGui::Checkbox("Enable Master ESP", &Vars::ESP::enabled);
        ImGui::Spacing();

        if (ImGui::CollapsingHeader("Box ESP Settings", ImGuiTreeNodeFlags_DefaultOpen)) {
            ImGui::Checkbox("Draw Player Boxes", &Vars::ESP::boxes);
            
            const char* boxStyles[] = { "Outline", "Filled", "Corners" };
            ImGui::Combo("Box Style", &Vars::ESP::boxStyle, boxStyles, 3);
            
            static float localBoxColor[4] = { 1.0f, 1.0f, 1.0f, 1.0f };
            ImGui::ColorEdit4("Box Color", localBoxColor);
        }

        if (ImGui::CollapsingHeader("Text & Info ESP", ImGuiTreeNodeFlags_DefaultOpen)) {
            ImGui::Checkbox("Show Player Names", &Vars::ESP::names);
            ImGui::Checkbox("Show Distance Info", &Vars::ESP::distance);

            if (Vars::ESP::distance) {
                ImGui::SliderFloat("Max Render Distance", &Vars::ESP::maxDistance, 50.0f, 5000.0f, "%.0f studs");
            }
            ImGui::Checkbox("Draw Health Bar", &Vars::ESP::healthBar);
        }

        if (ImGui::CollapsingHeader("Advanced ESP Visuals")) {
            ImGui::Checkbox("Render Skeleton bones", &Vars::ESP::skeleton);
            if (Vars::ESP::skeleton) {
                float scol[4] = { Vars::ESP::skeletonColorR, Vars::ESP::skeletonColorG, Vars::ESP::skeletonColorB, Vars::ESP::skeletonColorA };
                if (ImGui::ColorEdit4("Skeleton Color", scol)) {
                    Vars::ESP::skeletonColorR = scol[0]; Vars::ESP::skeletonColorG = scol[1]; Vars::ESP::skeletonColorB = scol[2]; Vars::ESP::skeletonColorA = scol[3];
                }
                ImGui::SliderFloat("Bone Thickness", &Vars::ESP::skeletonThickness, 0.5f, 5.0f, "%.1f");
            }
            
            ImGui::Checkbox("Off-screen Indicators (Arrows)", &Vars::ESP::occludedArrows);
        }
    }

    void RenderLocalTab() {
        ImGui::Text("Local Player Character Modifications");
        ImGui::Separator();
        ImGui::Spacing();

        if (Globals::localPlayer.Addr == 0) {
            ImGui::TextColored(ImVec4(1.0f, 0.4f, 0.4f, 1.0f), "Local Player not found! Load into a game.");
            return;
        }

        auto localModel = Globals::localPlayer.GetModelRef();

        bool enableSpeed = Vars::Local::speedEnabled;
        float speedVal = Vars::Local::walkSpeed;

        if (ImGui::Checkbox("Enable WalkSpeed Modify", &enableSpeed)) {
            Vars::Local::speedEnabled = enableSpeed;
        }
        if (ImGui::SliderFloat("WalkSpeed Value", &speedVal, 16.0f, 5000.0f, "%.0f")) {
            Vars::Local::walkSpeed = speedVal;
        }
        ImGui::Text("WalkSpeed Toggle Key");
        RenderKeybindControl("WalkSpeedKeybind", Vars::Local::walkSpeedKey, 1005);

        ImGui::Spacing();

        bool enableJump = Vars::Local::jumpEnabled;
        float jumpVal = Vars::Local::jumpPower;

        if (ImGui::Checkbox("Enable JumpPower Modify", &enableJump)) {
            Vars::Local::jumpEnabled = enableJump;
        }
        if (ImGui::SliderFloat("JumpPower Value", &jumpVal, 50.0f, 5000.0f, "%.0f")) {
            Vars::Local::jumpPower = jumpVal;
        }
        ImGui::Text("JumpPower Toggle Key");
        RenderKeybindControl("JumpPowerKeybind", Vars::Local::jumpPowerKey, 1006);

        ImGui::Spacing();

        bool enableGravity = Vars::Local::gravityEnabled;
        float gravityVal = Vars::Local::gravityValue;
        if (ImGui::Checkbox("Enable Gravity Override", &enableGravity)) {
            Vars::Local::gravityEnabled = enableGravity;
        }
        if (ImGui::SliderFloat("Gravity Value", &gravityVal, 0.0f, 500.0f, "%.1f")) {
            Vars::Local::gravityValue = gravityVal;
        }
        ImGui::Text("Gravity Toggle Key");
        RenderKeybindControl("GravityKeybind", Vars::Local::gravityKey, 1007);

        ImGui::Spacing();

        bool enableFly = Vars::Local::flyEnabled;
        float flyVal = Vars::Local::flySpeed;
        if (ImGui::Checkbox("Enable Fly", &enableFly)) {
            Vars::Local::flyEnabled = enableFly;
        }
        if (ImGui::SliderFloat("Fly Speed", &flyVal, 20.0f, 5000.0f, "%.0f")) {
            Vars::Local::flySpeed = flyVal;
        }
        const char* flyModes[] = { "Velocity", "Position", "Position + Rotation Lock" };
        ImGui::Combo("Fly Mode", &Vars::Local::flyMode, flyModes, 3);

        const char* flyActivationModes[] = { "Hold Key", "Toggle Key" };
        ImGui::Combo("Fly Activation", &Vars::Local::flyActivationMode, flyActivationModes, 2);

        RenderKeybindControl("Fly Keybind", Vars::Local::flyKey, 1002);

        ImGui::Spacing();
        ImGui::Checkbox("Enable Noclip", &Vars::Local::noclipEnabled);
        RenderKeybindControl("Noclip Keybind", Vars::Local::noclipKey, 1003);

        ImGui::TextWrapped("Move with W/A/S/D");

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Spacing();

        ImGui::Text("Paste Position String");
        ImGui::InputTextWithHint("##LocalTeleportInput", "Vector3(x, y, z) or x,y,z", localTeleportInput, IM_ARRAYSIZE(localTeleportInput));
        if (ImGui::Button("Teleport to Position", ImVec2(180.0f, 0.0f))) {
            RBX::Vec3 parsedPos{};
            if (!PlayersFeature::ParsePositionString(localTeleportInput, parsedPos)) {
                localTeleportStatus = "Invalid position text (example: Vector3(27.3, 3.0, -70.5))";
            } else if (PlayersFeature::TeleportLocalToPosition(parsedPos)) {
                localTeleportStatus = "Teleported to X " + std::to_string(parsedPos.X) + " | Y " + std::to_string(parsedPos.Y) + " | Z " + std::to_string(parsedPos.Z);
            } else {
                localTeleportStatus = "Parsed OK, but local character/root part is not ready yet";
            }
        }
        if (!localTeleportStatus.empty()) {
            ImGui::TextDisabled("%s", localTeleportStatus.c_str());
        }

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Spacing();

        ImGui::TextWrapped("These movement values are applied directly to the local character state.");
    } 

    void RenderPlayersTab() {
        ImGui::Text("Players Manager");
        ImGui::Separator();
        ImGui::Spacing();

        ImGui::InputTextWithHint("##players_search", "Search player...", playersSearch, IM_ARRAYSIZE(playersSearch));

        if (PlayerCache::players.empty()) {
            ImGui::TextDisabled("No cached players right now. Join a server with other players.");
            return;
        }

        auto toLower = [](std::string value) {
            std::transform(value.begin(), value.end(), value.begin(), [](unsigned char c) {
                return static_cast<char>(std::tolower(c));
            });
            return value;
        };

        const std::string filter = toLower(playersSearch);
        std::vector<const PlayerCache::CachedPlayer*> filteredPlayers;
        filteredPlayers.reserve(PlayerCache::players.size());

        for (const auto& plr : PlayerCache::players) {
            if (!plr.isValid) continue;
            if (!filter.empty()) {
                const std::string loweredName = toLower(plr.name);
                if (loweredName.find(filter) == std::string::npos) {
                    continue;
                }
            }
            filteredPlayers.push_back(&plr);
        }

        constexpr float leftWidth = 250.0f;
        ImGui::BeginChild("##PlayersLeft", ImVec2(leftWidth, 0), true);
        ImGui::Text("Online Players");
        ImGui::Separator();

        if (filteredPlayers.empty()) {
            ImGui::TextDisabled("No players match your filter.");
        }

        for (const auto* plr : filteredPlayers) {
            if (!plr) continue;

            std::string label = plr->name;
            if (label.empty()) {
                label = "Unknown";
            }
            label += "##" + std::to_string(plr->playerAddr);

            const bool isSelected = (selectedPlayerAddr == plr->playerAddr);
            if (ImGui::Selectable(label.c_str(), isSelected)) {
                selectedPlayerAddr = plr->playerAddr;
                selectedPlayerName = plr->name;
                playersActionStatus.clear();
            }
        }
        ImGui::EndChild();

        ImGui::SameLine();

        ImGui::BeginChild("##PlayersRight", ImVec2(0, 0), true);
        ImGui::Text("Player Actions");
        ImGui::Separator();

        const PlayerCache::CachedPlayer* selected = nullptr;
        for (const auto& plr : PlayerCache::players) {
            if (plr.playerAddr == selectedPlayerAddr) {
                selected = &plr;
                break;
            }
        }

        if (!selected) {
            selectedPlayerAddr = 0;
            selectedPlayerName.clear();
            ImGui::TextDisabled("Select a player from the list.");
            ImGui::EndChild();
            return;
        }

        ImGui::Text("Selected: %s", selected->name.c_str());
        ImGui::Text("Distance: %.1f", selected->distance);
        ImGui::Text("Health: %.0f / %.0f", selected->health, selected->maxHealth);
        ImGui::Spacing();

        ImGui::BeginChild("##PlayerInfoCard", ImVec2(0, 110), true);
        ImGui::Text("Basic Player Info");
        ImGui::Separator();
        ImGui::Text("Player Addr: 0x%llX", static_cast<unsigned long long>(selected->playerAddr));
        ImGui::Text("Character: %s", selected->characterAddr != 0 ? "Valid" : "Missing");
        ImGui::Text("Humanoid: %s", selected->humanoidAddr != 0 ? "Valid" : "Missing");
        ImGui::Text("RootPart: %s", selected->rootPartAddr != 0 ? "Valid" : "Missing");
        ImGui::Text("Pos: X %.1f | Y %.1f | Z %.1f", selected->position.X, selected->position.Y, selected->position.Z);
        ImGui::Text("Vector3(%.3f, %.3f, %.3f)", selected->position.X, selected->position.Y, selected->position.Z);
        ImGui::EndChild();
        ImGui::Spacing();

        if (ImGui::Button("Spectate", ImVec2(140.0f, 0.0f))) {
            if (PlayersFeature::SpectatePlayer(selected->playerAddr)) {
                playersActionStatus = "Spectating " + selected->name;
            } else {
                playersActionStatus = "Failed to spectate selected player";
            }
        }
        ImGui::SameLine();
        if (ImGui::Button("Stop Spectate", ImVec2(140.0f, 0.0f))) {
            if (PlayersFeature::SpectateLocalPlayer()) {
                playersActionStatus = "Spectate reset to local player";
            } else {
                playersActionStatus = "Failed to restore local spectate";
            }
        }

        if (ImGui::Button("Teleport To Player", ImVec2(200.0f, 0.0f))) {
            if (PlayersFeature::TeleportToPlayer(selected->playerAddr)) {
                playersActionStatus = "Teleported to " + selected->name;
            } else {
                playersActionStatus = "Failed to teleport to selected player";
            }
        }

        if (ImGui::Button("Copy Player Position", ImVec2(200.0f, 0.0f))) {
            std::string posText;
            if (PlayersFeature::BuildPlayerPositionString(selected->playerAddr, posText) && CopyTextToClipboard(posText)) {
                playersActionStatus = "Copied position for " + selected->name;
            } else {
                playersActionStatus = "Failed to copy player position";
            }
        }

        const bool isWhitelisted = PlayersFeature::IsWhitelisted(selected->playerAddr);
        if (ImGui::Button(isWhitelisted ? "Remove from Whitelist" : "Add to Whitelist", ImVec2(200.0f, 0.0f))) {
            const bool nowWhitelisted = PlayersFeature::ToggleWhitelist(selected->playerAddr);
            playersActionStatus = nowWhitelisted ? (selected->name + " added to whitelist") : (selected->name + " removed from whitelist");
        }

        bool followSelected = PlayersFeature::IsFollowEnabled() && PlayersFeature::GetFollowTarget() == selected->playerAddr;
        if (ImGui::Checkbox("Follow Selected Player", &followSelected)) {
            if (followSelected) {
                PlayersFeature::SetFollowTarget(selected->playerAddr);
                playersActionStatus = "Following " + selected->name;
            } else {
                PlayersFeature::SetFollowEnabled(false);
                playersActionStatus = "Follow stopped";
            }
        }

        float followDistance = PlayersFeature::GetFollowDistance();
        if (ImGui::SliderFloat("Follow Distance", &followDistance, 2.0f, 30.0f, "%.1f")) {
            PlayersFeature::SetFollowDistance(followDistance);
        }

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Text("Whitelist ESP Color");
        ImGui::Checkbox("Use Custom Color for Whitelisted", &Vars::ESP::whitelistColorEnabled);
        float wlColor[4] = {
            Vars::ESP::whitelistColorR,
            Vars::ESP::whitelistColorG,
            Vars::ESP::whitelistColorB,
            Vars::ESP::whitelistColorA
        };
        if (ImGui::ColorEdit4("Whitelist ESP Color", wlColor)) {
            Vars::ESP::whitelistColorR = wlColor[0];
            Vars::ESP::whitelistColorG = wlColor[1];
            Vars::ESP::whitelistColorB = wlColor[2];
            Vars::ESP::whitelistColorA = wlColor[3];
        }

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::TextDisabled("Tip: Use Copy Player Position, then paste it in Local Player tab.");

        if (!playersActionStatus.empty()) {
            ImGui::Spacing();
            ImGui::TextDisabled("%s", playersActionStatus.c_str());
        }

        ImGui::EndChild();
    }

    void RenderExplorerTab() {
        ImGui::Text("Explorer");
        ImGui::Separator();
        ImGui::Spacing();

        constexpr float treeWidth = 300.0f;
        constexpr float bytecodeWidth = 360.0f;

        ImGui::BeginChild("##ExplorerTree", ImVec2(treeWidth, 0), true);
        ImGui::Text("Game Tree");
        ImGui::Separator();

        if (Globals::dataModel.Addr == 0) {
            ImGui::TextDisabled("DataModel is not available");
        } else {
            RenderExplorerInstanceNode(Globals::dataModel, 0);
        }
        ImGui::EndChild();

        ImGui::SameLine();

        ImGui::BeginChild("##ExplorerBytecode", ImVec2(bytecodeWidth, 0), true);
        ImGui::Text("Bytecode");
        ImGui::Separator();

        ImGui::InputInt("Resource ID", &explorerResourceId);
        if (explorerResourceId < 1) explorerResourceId = 1;

        if (ImGui::Button("Load Lua Resource", ImVec2(160.0f, 0.0f))) {
            std::string code = Bytecode::GetLuaCode(Coms->GetPID(), explorerResourceId);
            if (code.empty()) {
                explorerBytecodeStatus = "Failed to load resource";
            } else {
                SetTextBuffer(explorerBytecodeInput, sizeof(explorerBytecodeInput), code);
                explorerLastBlob.clear();
                explorerBytecodeStatus = "Loaded resource id " + std::to_string(explorerResourceId);
            }
        }

        ImGui::Spacing();
        ImGui::Text("Input / Script Source");
        ImGui::InputTextMultiline("##ExplorerBytecodeInput", explorerBytecodeInput, IM_ARRAYSIZE(explorerBytecodeInput), ImVec2(-FLT_MIN, 180.0f));

        if (ImGui::Button("Compress", ImVec2(100.0f, 0.0f))) {
            explorerLastBlob = Bytecode::compress(explorerBytecodeInput);
            explorerBytecodeStatus = explorerLastBlob.empty()
                ? "Compress failed"
                : ("Compressed bytes: " + std::to_string(explorerLastBlob.size()));
        }
        ImGui::SameLine();
        if (ImGui::Button("Sign", ImVec2(100.0f, 0.0f))) {
            explorerLastBlob = Bytecode::SignBytecode(explorerBytecodeInput);
            explorerBytecodeStatus = explorerLastBlob.empty()
                ? "Sign failed"
                : ("Signed blob bytes: " + std::to_string(explorerLastBlob.size()));
        }
        ImGui::SameLine();
        if (ImGui::Button("Decompress", ImVec2(100.0f, 0.0f))) {
            const std::string sourceBlob = !explorerLastBlob.empty()
                ? explorerLastBlob
                : std::string(explorerBytecodeInput);

            if (sourceBlob.empty()) {
                explorerBytecodeStatus = "No data to decompress";
            } else {
                std::string out = Bytecode::decompress(sourceBlob);
                if (out.empty()) {
                    explorerBytecodeStatus = "Decompress failed";
                } else {
                    SetTextBuffer(explorerBytecodeInput, sizeof(explorerBytecodeInput), out);
                    explorerBytecodeStatus = "Decompressed successfully";
                }
            }
        }

        if (!explorerLastBlob.empty()) {
            const std::string preview = HexPreview(explorerLastBlob);
            ImGui::TextWrapped("Blob Preview: %s", preview.c_str());
        }
        if (!explorerBytecodeStatus.empty()) {
            ImGui::TextDisabled("%s", explorerBytecodeStatus.c_str());
        }
        ImGui::EndChild();

        ImGui::SameLine();

        ImGui::BeginChild("##ExplorerRight", ImVec2(0, 0), true);
        ImGui::Text("Decompiler");
        ImGui::Separator();

        ImGui::InputTextWithHint("Script Address", "0x12345678", explorerScriptAddress, IM_ARRAYSIZE(explorerScriptAddress));
        const char* scriptTypes[] = { "LocalScript", "ModuleScript" };
        ImGui::Combo("Script Type", &explorerScriptType, scriptTypes, 2);

        if (ImGui::Button("Decompile Script", ImVec2(150.0f, 0.0f))) {
            uintptr_t scriptAddress = 0;
            if (!TryParseAddress(explorerScriptAddress, scriptAddress)) {
                explorerDecompilerStatus = "Invalid script address";
                SetTextBuffer(explorerDecompilerOutput, sizeof(explorerDecompilerOutput), "");
            } else {
                decompiler::script_type scriptType = explorerScriptType == 1
                    ? decompiler::ModuleScript
                    : decompiler::LocalScript;

                std::string error;
                const std::string source = explorerDecompiler.DecompileScript(
                    static_cast<std::uint64_t>(scriptAddress),
                    scriptType,
                    &error
                );

                if (source.empty()) {
                    explorerDecompilerStatus = error.empty() ? "Decompile failed" : error;
                    SetTextBuffer(explorerDecompilerOutput, sizeof(explorerDecompilerOutput), "");
                } else {
                    explorerDecompilerStatus = "Decompiled source size: " + std::to_string(source.size()) + " bytes";
                    SetTextBuffer(explorerDecompilerOutput, sizeof(explorerDecompilerOutput), source);
                }
            }
        }

        if (!explorerDecompilerStatus.empty()) {
            ImGui::TextDisabled("%s", explorerDecompilerStatus.c_str());
            if (explorerDecompilerStatus.find("binary Luau chunk") != std::string::npos) {
                ImGui::TextDisabled("Hint: This means decode succeeded, but a real Luau decompiler stage is still required for source reconstruction.");
            }
        }

        ImGui::Spacing();
        if (watermarkFont) ImGui::PushFont(watermarkFont);
        ImGui::InputTextMultiline(
            "##ExplorerDecompilerOutput",
            explorerDecompilerOutput,
            IM_ARRAYSIZE(explorerDecompilerOutput),
            ImVec2(-FLT_MIN, -FLT_MIN),
            ImGuiInputTextFlags_ReadOnly
        );
        if (watermarkFont) ImGui::PopFont();

        ImGui::EndChild();
    }

    void RenderSettingsTab() {
        static bool configUiInitialized = false;
        static char configName[128] = "default";
        static char renameConfigName[128] = "";

        if (!configUiInitialized) {
            ConfigSystem::RefreshList();
            configUiInitialized = true;
        }

        ImGui::Text("Watermark & Menu Customization");
        ImGui::Separator();
        ImGui::Spacing();

        ImGui::Checkbox("Enable Top Watermark", &Vars::Watermark::enabled);
        ImGui::Checkbox("Show Current Player Count", &Vars::Watermark::showPlayerCount);
        ImGui::Checkbox("Show Local Account Name", &Vars::Watermark::showUsername);
        
        ImGui::Spacing();
        ImGui::Text("Watermark Colors");
        const char* modes[] = { "Static Custom Color", "Rainbow Wave Mode" };
        ImGui::Combo("Color Mode", &Vars::Watermark::colorMode, modes, 2);

        if (Vars::Watermark::colorMode == 0) {
            float wcol[4] = { Vars::Watermark::colorR, Vars::Watermark::colorG, Vars::Watermark::colorB, Vars::Watermark::colorA };
            if (ImGui::ColorEdit4("Watermark Color Tint", wcol)) {
                Vars::Watermark::colorR = wcol[0]; Vars::Watermark::colorG = wcol[1]; Vars::Watermark::colorB = wcol[2]; Vars::Watermark::colorA = wcol[3];
            }
        } else {
            ImGui::SliderFloat("Rainbow Speed Scale", &Vars::Watermark::rainbowSpeed, 0.1f, 5.0f, "%.1f x");
        }

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Spacing();

        ImGui::Text("Security & Stream Features");
        ImGui::Checkbox("Anti Screen Share (Streamproof)", &Vars::UI::antiScreenShare);

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Spacing();

        ImGui::Text("Rendering");
        ImGui::Checkbox("Enable VSync", &Vars::UI::vsyncEnabled);

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Spacing();

        ImGui::Text("Config System");
        ImGui::InputText("Config Name", configName, IM_ARRAYSIZE(configName));
        ImGui::InputText("Rename To", renameConfigName, IM_ARRAYSIZE(renameConfigName));

        if (ImGui::Button("Save Config", ImVec2(140.0f, 0.0f))) {
            ConfigSystem::SaveConfig(configName);
        }
        ImGui::SameLine();
        if (ImGui::Button("Load Config", ImVec2(140.0f, 0.0f))) {
            ConfigSystem::LoadConfig(configName);
        }
        ImGui::SameLine();
        if (ImGui::Button("Refresh List", ImVec2(140.0f, 0.0f))) {
            ConfigSystem::RefreshList();
        }

        if (ImGui::Button("Delete Config", ImVec2(140.0f, 0.0f))) {
            if (ConfigSystem::DeleteConfig(configName)) {
                renameConfigName[0] = '\0';
            }
        }
        ImGui::SameLine();
        if (ImGui::Button("Rename Config", ImVec2(140.0f, 0.0f))) {
            if (ConfigSystem::RenameConfig(configName, renameConfigName)) {
                strncpy_s(configName, renameConfigName, _TRUNCATE);
                renameConfigName[0] = '\0';
            }
        }

        const auto& configs = ConfigSystem::GetConfigs();
        if (ImGui::BeginListBox("Saved Configs", ImVec2(-FLT_MIN, 120.0f))) {
            for (int i = 0; i < static_cast<int>(configs.size()); ++i) {
                const bool isSelected = (ConfigSystem::selectedIndex == i);
                if (ImGui::Selectable(configs[i].c_str(), isSelected)) {
                    ConfigSystem::selectedIndex = i;
                    strncpy_s(configName, configs[i].c_str(), _TRUNCATE);
                    renameConfigName[0] = '\0';
                }
            }
            ImGui::EndListBox();
        }

        if (!ConfigSystem::lastStatus.empty()) {
            ImGui::TextDisabled("%s", ConfigSystem::lastStatus.c_str());
        }

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Spacing();

        ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.70f, 0.18f, 0.18f, 0.95f));
        ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.80f, 0.22f, 0.22f, 1.0f));
        ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(0.58f, 0.14f, 0.14f, 1.0f));
        if (ImGui::Button("Unload Cheat", ImVec2(180.0f, 0.0f))) {
            Vars::UI::unloadRequested = true;
            Vars::menuOpen = false;
        }
        ImGui::PopStyleColor(3);
    }

    void RenderLightingTab() {
        ImGui::Text("Lighting Customization");
        ImGui::Separator();
        ImGui::Spacing();

        if (Globals::lighting.Addr == 0) {
            ImGui::TextColored(ImVec4(1.0f, 0.4f, 0.4f, 1.0f), "Lighting service not found.");
            return;
        }

        ImGui::Checkbox("Override Clock Time", &Vars::Lighting::clockTimeEnabled);
        ImGui::SliderFloat("Clock Time", &Vars::Lighting::clockTime, 0.0f, 24.0f, "%.1f");

        ImGui::Spacing();
        ImGui::Checkbox("Override Brightness", &Vars::Lighting::brightnessEnabled);
        ImGui::SliderFloat("Brightness", &Vars::Lighting::brightness, 0.0f, 10.0f, "%.2f");

        ImGui::Spacing();
        ImGui::Checkbox("Override Fog", &Vars::Lighting::fogEnabled);
        ImGui::SliderFloat("Fog Start", &Vars::Lighting::fogStart, 0.0f, 10000.0f, "%.0f");
        ImGui::SliderFloat("Fog End", &Vars::Lighting::fogEnd, 0.0f, 100000.0f, "%.0f");

        ImGui::Spacing();
        ImGui::Checkbox("Override Global Shadows", &Vars::Lighting::shadowsEnabled);
        ImGui::Checkbox("Global Shadows Enabled", &Vars::Lighting::globalShadows);
    }
};