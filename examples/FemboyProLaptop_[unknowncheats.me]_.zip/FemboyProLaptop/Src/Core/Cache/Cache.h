#pragma once
#include "../../Game/SDK/SDK.h"
#include "../Globals/Globals.h"
#include <vector>
#include <string>
#include <algorithm>
#include <chrono>
#include <thread>
#include <mutex>

namespace PlayerCache {

    struct CachedPlayer {
        uintptr_t playerAddr;
        uintptr_t characterAddr;
        uintptr_t humanoidAddr;
        uintptr_t rootPartAddr;

        std::string username;
        std::string name;
        std::string displayName;
        RBX::Vec3 position;
        float health;
        float maxHealth;
        float distance;

        std::chrono::steady_clock::time_point lastSeenAt;
        bool isValid;
    };

    inline std::vector<CachedPlayer> players;
    inline std::mutex playersMutex;
    inline RBX::Vec3 localPlayerPos;
    inline std::chrono::steady_clock::time_point lastCacheUpdate = std::chrono::steady_clock::now();

    inline std::string FormatPlayerLabel(const std::string& username, const std::string& displayName) {
        if (username.empty()) {
            return displayName.empty() ? std::string("Unknown") : displayName;
        }

        if (displayName.empty() || displayName == username) {
            return username;
        }

        return username + " (@" + displayName + ")";
    }

    inline std::string ReadPlayerDisplayName(uintptr_t playerAddr) {
        if (playerAddr == 0) return "";

        try {
            RBX::RbxInstance player(playerAddr);
            auto character = player.GetModelRef();
            if (character.Addr == 0) return "";

            auto humanoid = character.FindChild("Humanoid");
            if (humanoid.Addr == 0) return "";

            std::string displayName = Coms->ReadGameString(humanoid.Addr + 0xb8);

            if (displayName.empty() || displayName.length() > 256) return "";
            return displayName;
        }
        catch (...) {
            return "";
        }
    }

    inline void UpdatePlayers() {
        const auto now = std::chrono::steady_clock::now();
        if (std::chrono::duration_cast<std::chrono::milliseconds>(now - lastCacheUpdate).count() < 35) {
            return;
        }
        lastCacheUpdate = now;

        auto playerList = Globals::players.GetChildList();

        std::lock_guard<std::mutex> lock(playersMutex);

        if (playerList.empty()) {
            const auto staleCutoff = now - std::chrono::milliseconds(3000);
            players.erase(std::remove_if(players.begin(), players.end(), [&](const CachedPlayer& cached) {
                return cached.lastSeenAt < staleCutoff;
            }), players.end());
            return;
        }

        auto localChar = Globals::localPlayer.GetModelRef();
        if (localChar.Addr == 0) return;

        auto localRoot = localChar.FindChild("HumanoidRootPart");
        if (localRoot.Addr == 0) return;

        localPlayerPos = localRoot.GetPos();

        players.reserve(playerList.size() + 64);

        for (auto& cached : players) {
            cached.isValid = false;
        }

        for (auto& plr : playerList) {
            if (plr.Addr == 0 || plr.Addr == Globals::localPlayer.Addr) continue;

            CachedPlayer* existingPlayer = nullptr;
            for (auto& cached : players) {
                if (cached.playerAddr == plr.Addr) {
                    existingPlayer = &cached;
                    break;
                }
            }

            std::string username = plr.GetName();
            if (username.empty() && existingPlayer != nullptr) {
                username = existingPlayer->username;
            }
            if (username.empty()) {
                username = "Unknown";
            }

            const std::string displayName = ReadPlayerDisplayName(plr.Addr);
            const std::string formattedName = FormatPlayerLabel(username, displayName);

            if (existingPlayer == nullptr) {
                CachedPlayer newPlayer{};
                newPlayer.playerAddr = plr.Addr;
                newPlayer.username = username;
                newPlayer.displayName = displayName;
                newPlayer.name = formattedName;
                newPlayer.lastSeenAt = now;
                newPlayer.isValid = true;
                players.push_back(newPlayer);
                existingPlayer = &players.back();
            }

            existingPlayer->lastSeenAt = now;
            existingPlayer->isValid = true;
            existingPlayer->username = username;
            existingPlayer->displayName = displayName;
            existingPlayer->name = formattedName;

            auto character = plr.GetModelRef();
            if (character.Addr != 0) {
                existingPlayer->characterAddr = character.Addr;

                auto humanoid = character.FindChildByClass("Humanoid");
                if (humanoid.Addr != 0) {
                    existingPlayer->humanoidAddr = humanoid.Addr;

                    const float healthNow = Coms->ReadMemory<float>(humanoid.Addr + Offsets::Humanoid::Health);
                    const float maxHealthNow = Coms->ReadMemory<float>(humanoid.Addr + Offsets::Humanoid::MaxHealth);
                    existingPlayer->health = (healthNow >= 0.0f && healthNow < 1000000.0f) ? healthNow : 0.0f;
                    existingPlayer->maxHealth = (maxHealthNow > 0.0f && maxHealthNow < 1000000.0f) ? maxHealthNow : 100.0f;
                }

                auto rootPart = character.FindChild("HumanoidRootPart");
                if (rootPart.Addr != 0) {
                    existingPlayer->rootPartAddr = rootPart.Addr;
                    existingPlayer->position = rootPart.GetPos();
                    existingPlayer->distance = rootPart.CalcDistance(localPlayerPos);
                }
            }
        }

        const auto staleCutoff = now - std::chrono::milliseconds(3000);
        players.erase(
            std::remove_if(players.begin(), players.end(),
                [&](const CachedPlayer& p) { return !p.isValid && p.lastSeenAt < staleCutoff; }),
            players.end()
        );
    }
}
