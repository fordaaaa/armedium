#pragma once
#include "../../../Game/W2S/W2S.h"
#include "../../../Core/Cache/Cache.h"
#include "../../../Core/Vars/Vars.h"
#include "../../../Core/Features/players/Players.h"
#include "../../../Render/ImGui/imgui.h"
#include <string>
#include <algorithm>
#include <cmath>
#include <vector>
#include <functional>
#include <thread>
#include <chrono>

namespace Visuals {

    inline bool IsBodyPart(const std::string& className) {
        return className == "Part"
            || className == "MeshPart"
            || className == "UnionOperation"
            || className == "WedgePart"
            || className == "CornerWedgePart"
            || className == "TrussPart"
            || className == "VehicleSeat"
            || className == "Seat";
    }

    inline void AddPartBoundPoints(RBX::RbxInstance& part, RBX::Vec3* points, int& count, int maxCount) {
        if (part.Addr == 0 || count + 8 > maxCount) return;

        RBX::Vec3 pos = part.GetPos();
        RBX::Vec3 size = part.GetSize();
        if (size.X <= 0.0f || size.Y <= 0.0f || size.Z <= 0.0f) return;

        const float PAD_MULT = 0.8f;
        size.X *= PAD_MULT;
        size.Y *= PAD_MULT;
        size.Z *= PAD_MULT;

        float hx = size.X * 0.5f;
        float hy = size.Y * 0.5f;
        float hz = size.Z * 0.5f;

        points[count++] = { pos.X - hx, pos.Y - hy, pos.Z - hz };
        points[count++] = { pos.X + hx, pos.Y - hy, pos.Z - hz };
        points[count++] = { pos.X - hx, pos.Y + hy, pos.Z - hz };
        points[count++] = { pos.X + hx, pos.Y + hy, pos.Z - hz };
        points[count++] = { pos.X - hx, pos.Y - hy, pos.Z + hz };
        points[count++] = { pos.X + hx, pos.Y - hy, pos.Z + hz };
        points[count++] = { pos.X - hx, pos.Y + hy, pos.Z + hz };
        points[count++] = { pos.X + hx, pos.Y + hy, pos.Z + hz };
    }

    inline void DrawOutlinedText(ImDrawList* drawList, ImFont* font, const ImVec2& pos, const std::string& text, ImU32 textColor) {
        if (!drawList) return;

        constexpr float kEspFontSize = 12.0f;
        const std::string label = text.empty() ? "Unknown" : text;

        ImFont* fontToUse = (font != nullptr) ? font : ImGui::GetIO().FontDefault;

        if (!fontToUse) return;

        drawList->AddText(fontToUse, kEspFontSize, ImVec2(pos.x - 1, pos.y), IM_COL32(0, 0, 0, 255), label.c_str());
        drawList->AddText(fontToUse, kEspFontSize, ImVec2(pos.x + 1, pos.y), IM_COL32(0, 0, 0, 255), label.c_str());
        drawList->AddText(fontToUse, kEspFontSize, ImVec2(pos.x, pos.y - 1), IM_COL32(0, 0, 0, 255), label.c_str());
        drawList->AddText(fontToUse, kEspFontSize, ImVec2(pos.x, pos.y + 1), IM_COL32(0, 0, 0, 255), label.c_str());
        drawList->AddText(fontToUse, kEspFontSize, pos, textColor, label.c_str());
    }

    inline void RenderESP(ImDrawList* drawList, const RBX::Mat4& viewMatrix, ImFont* espFont = nullptr) {
        if (!Vars::ESP::enabled) return;
        if (!drawList) return;

        const bool drawBoxes = Vars::ESP::boxes;
        const bool drawHealth = Vars::ESP::healthBar;
        const bool drawNames = Vars::ESP::names;
        static int espFrameCounter = 0;
        const bool drawSkeleton = Vars::ESP::skeleton && ((espFrameCounter++ & 1) == 0);

        if (!drawBoxes && !drawHealth && !drawNames && !drawSkeleton) return;

        ImFont* safeFont = espFont ? espFont : ImGui::GetIO().FontDefault;

        std::this_thread::sleep_for(std::chrono::milliseconds(2));

        size_t processedPlayers = 0;
        const size_t maxPlayersToProcess = 24;

        std::lock_guard<std::mutex> cacheLock(PlayerCache::playersMutex);

        for (auto& plr : PlayerCache::players) {
            if (processedPlayers++ >= maxPlayersToProcess) break;
            if (!plr.isValid) continue;

            const bool isWhitelisted = PlayersFeature::IsWhitelisted(plr.playerAddr);
            const bool useWhitelistColor = Vars::ESP::whitelistColorEnabled && isWhitelisted;
            const ImU32 customEspColor = IM_COL32(
                static_cast<int>(Vars::ESP::whitelistColorR * 255.0f),
                static_cast<int>(Vars::ESP::whitelistColorG * 255.0f),
                static_cast<int>(Vars::ESP::whitelistColorB * 255.0f),
                static_cast<int>(Vars::ESP::whitelistColorA * 255.0f)
            );
            const ImU32 primaryEspColor = useWhitelistColor ? customEspColor : IM_COL32(255, 255, 255, 255);

            auto character = RBX::RbxInstance(plr.characterAddr);
            auto head = character.FindChild("Head");
            if (head.Addr == 0) continue;

            RBX::Vec3 boundPoints[200];
            int boundPointCount = 0;

            for (auto& child : character.GetChildList()) {
                if (IsBodyPart(child.GetClass())) {
                    AddPartBoundPoints(child, boundPoints, boundPointCount, 200);
                }
            }

            if (boundPointCount == 0) {
                AddPartBoundPoints(head, boundPoints, boundPointCount, 200);
            }

            float minX = 999999.0f, minY = 999999.0f;
            float maxX = -999999.0f, maxY = -999999.0f;
            int validPoints = 0;

            for (int i = 0; i < boundPointCount; i++) {
                RBX::Vec2 screenPos = W2S::WorldToScreen(boundPoints[i], viewMatrix);
                if (screenPos.X == 0.0f && screenPos.Y == 0.0f) continue;

                minX = (minX < screenPos.X) ? minX : screenPos.X;
                minY = (minY < screenPos.Y) ? minY : screenPos.Y;
                maxX = (maxX > screenPos.X) ? maxX : screenPos.X;
                maxY = (maxY > screenPos.Y) ? maxY : screenPos.Y;
                validPoints++;
            }

            if (validPoints < 3 || minX == 999999.0f) continue;

            float boxWidth = maxX - minX;
            float boxHeight = maxY - minY;

            ImVec2 screenSize = ImGui::GetIO().DisplaySize;
            const float MAX_BOX_WIDTH = screenSize.x * 1.5f;
            const float MAX_BOX_HEIGHT = screenSize.y * 1.5f;

            if (boxWidth > MAX_BOX_WIDTH || boxHeight > MAX_BOX_HEIGHT) continue;

            if (Vars::ESP::maxDistance > 0.0f && plr.distance > Vars::ESP::maxDistance) continue;

            if (drawBoxes) {
                if (Vars::ESP::boxStyle == 1) {
                    drawList->AddRectFilled(ImVec2(minX, minY), ImVec2(maxX, maxY), IM_COL32(0, 0, 0, 150));
                    drawList->AddRect(ImVec2(minX, minY), ImVec2(maxX, maxY), useWhitelistColor ? customEspColor : IM_COL32(255, 255, 255, 200), 0.0f, 0, 1.5f);
                }
                else if (Vars::ESP::boxStyle == 2) {
                    float w = boxWidth, h = boxHeight;
                    float len = ((w < h) ? w : h) * 0.15f;

                    drawList->AddLine(ImVec2(minX, minY), ImVec2(minX + len, minY), primaryEspColor, 1.5f);
                    drawList->AddLine(ImVec2(minX, minY), ImVec2(minX, minY + len), primaryEspColor, 1.5f);
                    drawList->AddLine(ImVec2(maxX, minY), ImVec2(maxX - len, minY), primaryEspColor, 1.5f);
                    drawList->AddLine(ImVec2(maxX, minY), ImVec2(maxX, minY + len), primaryEspColor, 1.5f);
                    drawList->AddLine(ImVec2(minX, maxY), ImVec2(minX + len, maxY), primaryEspColor, 1.5f);
                    drawList->AddLine(ImVec2(minX, maxY), ImVec2(minX, maxY - len), primaryEspColor, 1.5f);
                    drawList->AddLine(ImVec2(maxX, maxY), ImVec2(maxX - len, maxY), primaryEspColor, 1.5f);
                    drawList->AddLine(ImVec2(maxX, maxY), ImVec2(maxX, maxY - len), primaryEspColor, 1.5f);
                }
                else {
                    drawList->AddRect(ImVec2(minX, minY), ImVec2(maxX, maxY), IM_COL32(0, 0, 0, 255), 0.0f, 0, 3.0f);
                    drawList->AddRect(ImVec2(minX, minY), ImVec2(maxX, maxY), primaryEspColor, 0.0f, 0, 1.0f);
                    drawList->AddRect(ImVec2(minX + 1, minY + 1), ImVec2(maxX - 1, maxY - 1), IM_COL32(0, 0, 0, 255), 0.0f, 0, 1.0f);
                }
            }

            if (drawHealth && plr.maxHealth > 0) {
                float healthPercent = static_cast<float>(plr.health) / static_cast<float>(plr.maxHealth);
                ImU32 healthColor = IM_COL32(255 * (1 - healthPercent), 255 * healthPercent, 0, 255);
                float barHeight = (maxY - minY) * healthPercent;

                drawList->AddRectFilled(
                    ImVec2(minX - 6, minY),
                    ImVec2(minX - 2, maxY),
                    IM_COL32(0, 0, 0, 200)
                );

                drawList->AddRectFilled(
                    ImVec2(minX - 5, maxY - barHeight),
                    ImVec2(minX - 3, maxY),
                    healthColor
                );
            }

            if (drawSkeleton) {
                bool isR15 = (character.FindChild("UpperTorso").Addr != 0) || (character.FindChild("LowerTorso").Addr != 0);

                std::vector<std::vector<const char*>> chains;
                if (isR15) {
                    chains = {
                        { "Head", "UpperTorso", "LowerTorso" },
                        { "UpperTorso", "LeftUpperArm", "LeftLowerArm", "LeftHand" },
                        { "UpperTorso", "RightUpperArm", "RightLowerArm", "RightHand" },
                        { "LowerTorso", "LeftUpperLeg", "LeftLowerLeg", "LeftFoot" },
                        { "LowerTorso", "RightUpperLeg", "RightLowerLeg", "RightFoot" }
                    };
                }
                else {
                    chains = {
                        { "Head", "Torso" },
                        { "Torso", "Left Arm" },
                        { "Torso", "Right Arm" },
                        { "Torso", "Left Leg" },
                        { "Torso", "Right Leg" }
                    };
                }

                auto getJointScreenPos = [&](const char* partName) -> std::pair<bool, ImVec2> {
                    RBX::RbxInstance part = character.FindChild(partName);
                    if (part.Addr == 0) {
                        if (std::strcmp(partName, "Torso") == 0) {
                            part = character.FindChild("HumanoidRootPart");
                            if (part.Addr == 0) part = character.FindChild("LowerTorso");
                        }
                        else if (std::strcmp(partName, "Left Arm") == 0) {
                            part = character.FindChild("LeftUpperArm");
                            if (part.Addr == 0) part = character.FindChild("LeftLowerArm");
                        }
                        else if (std::strcmp(partName, "Right Arm") == 0) {
                            part = character.FindChild("RightUpperArm");
                            if (part.Addr == 0) part = character.FindChild("RightLowerArm");
                        }
                        else if (std::strcmp(partName, "Left Leg") == 0) {
                            part = character.FindChild("LeftUpperLeg");
                            if (part.Addr == 0) part = character.FindChild("LeftLowerLeg");
                        }
                        else if (std::strcmp(partName, "Right Leg") == 0) {
                            part = character.FindChild("RightUpperLeg");
                            if (part.Addr == 0) part = character.FindChild("RightLowerLeg");
                        }
                        if (part.Addr == 0) return { false, ImVec2(0, 0) };
                    }

                    RBX::Vec3 worldPos = part.GetPos();
                    RBX::Vec2 scr = W2S::WorldToScreen(worldPos, viewMatrix);
                    if (scr.X == 0.0f && scr.Y == 0.0f) return { false, ImVec2(0, 0) };

                    return { true, ImVec2(scr.X, scr.Y) };
                    };

                for (const auto& chain : chains) {
                    ImVec2 prevScreen = ImVec2(0.0f, 0.0f);
                    bool havePrev = false;

                    for (const char* name : chain) {
                        auto res = getJointScreenPos(name);
                        if (!res.first) {
                            havePrev = false;
                            continue;
                        }

                        ImVec2 sp = res.second;
                        if (havePrev) {
                            float alpha = Vars::ESP::skeletonColorA;
                            if (Vars::ESP::skeletonFadeStart > 0.0f) {
                                float d = plr.distance;
                                float s = Vars::ESP::skeletonFadeStart;
                                float e = Vars::ESP::skeletonFadeEnd;
                                if (d >= e) alpha = 0.0f;
                                else if (d > s) alpha *= (1.0f - ((d - s) / (e - s)));
                            }
                            ImU32 col = IM_COL32(
                                static_cast<int>(Vars::ESP::skeletonColorR * 255.0f),
                                static_cast<int>(Vars::ESP::skeletonColorG * 255.0f),
                                static_cast<int>(Vars::ESP::skeletonColorB * 255.0f),
                                static_cast<int>(alpha * 255.0f)
                            );
                            drawList->AddLine(prevScreen, sp, col, Vars::ESP::skeletonThickness);
                        }
                        prevScreen = sp;
                        havePrev = true;
                    }
                }
            }


            if (drawNames && safeFont) {
                std::string label;

                if (!plr.displayName.empty() && plr.displayName != plr.username) {
                    label = plr.username + " (@" + plr.displayName + ")";
                }
                else {
                    label = plr.username;
                }

                ImVec2 textSize = ImGui::CalcTextSize(label.c_str());
                float textX = (minX + maxX) / 2.0f - textSize.x / 2.0f;
                float textY = minY - textSize.y - 2;

                DrawOutlinedText(drawList, safeFont, ImVec2(textX, textY), label, primaryEspColor);
            }

            if (Vars::ESP::distance && safeFont) {
                std::string distText = std::to_string(static_cast<int>(plr.distance)) + "m";
                ImVec2 textSize = ImGui::CalcTextSize(distText.c_str());
                float textX = (minX + maxX) / 2.0f - textSize.x / 2.0f;
                float textY = maxY + 2;
                DrawOutlinedText(drawList, safeFont, ImVec2(textX, textY), distText, primaryEspColor);
            }

            if (Vars::ESP::occludedArrows) {
                float cx = ImGui::GetIO().DisplaySize.x * 0.5f;
                float cy = ImGui::GetIO().DisplaySize.y * 0.5f;
                RBX::Vec3 headPos = head.GetPos();
                RBX::Vec2 headScreen = W2S::WorldToScreen(headPos, viewMatrix);

                bool onScreen = !(headScreen.X == 0.0f && headScreen.Y == 0.0f)
                    && headScreen.X >= 0
                    && headScreen.Y >= 0
                    && headScreen.X <= ImGui::GetIO().DisplaySize.x
                    && headScreen.Y <= ImGui::GetIO().DisplaySize.y;

                if (!onScreen) {
                    float dx = headScreen.X - cx;
                    float dy = headScreen.Y - cy;
                    float ang = atan2f(dy, dx);
                    float radius = ((cx < cy) ? cx : cy) - 20.0f;
                    float ax = cx + cosf(ang) * radius;
                    float ay = cy + sinf(ang) * radius;

                    ImVec2 p1 = ImVec2(ax + cosf(ang) * 12.0f, ay + sinf(ang) * 12.0f);
                    ImVec2 p2 = ImVec2(ax + cosf(ang + 2.5f) * 8.0f, ay + sinf(ang + 2.5f) * 8.0f);
                    ImVec2 p3 = ImVec2(ax + cosf(ang - 2.5f) * 8.0f, ay + sinf(ang - 2.5f) * 8.0f);

                    drawList->AddTriangleFilled(p1, p2, p3, IM_COL32(255, 255, 255, 220));
                    drawList->AddTriangle(p1, p2, p3, IM_COL32(0, 0, 0, 200), 1.0f);
                }
            }
        }
    }
}