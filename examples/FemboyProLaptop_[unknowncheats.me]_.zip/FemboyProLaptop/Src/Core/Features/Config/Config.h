#pragma once
#include <windows.h>
#include <filesystem>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <algorithm>
#include "../../../Core/Vars/Vars.h"

namespace ConfigSystem {
    inline std::vector<std::string> configList{};
    inline int selectedIndex = -1;
    inline std::string lastStatus{};

    inline std::filesystem::path GetExeDirectory() {
        char buffer[MAX_PATH] = {};
        GetModuleFileNameA(nullptr, buffer, MAX_PATH);
        return std::filesystem::path(buffer).parent_path();
    }

    inline std::filesystem::path GetConfigDirectory() {
        return GetExeDirectory() / "config";
    }

    inline std::filesystem::path GetLastConfigPath() {
        return GetConfigDirectory() / "last.txt";
    }

    inline std::filesystem::path GetConfigPath(const std::string& name) {
        return GetConfigDirectory() / (name + ".cfg");
    }

    inline bool EnsureConfigDirectory() {
        std::error_code ec;
        std::filesystem::create_directories(GetConfigDirectory(), ec);
        return !ec;
    }

    inline std::string Trim(const std::string& value) {
        const auto start = value.find_first_not_of(" \t\r\n");
        if (start == std::string::npos) return "";
        const auto end = value.find_last_not_of(" \t\r\n");
        return value.substr(start, end - start + 1);
    }

    inline bool ConfigExists(const std::string& name) {
        return !name.empty() && std::filesystem::exists(GetConfigPath(name));
    }

    inline void UpdateSelectedIndex(const std::string& name) {
        selectedIndex = -1;
        for (int i = 0; i < static_cast<int>(configList.size()); ++i) {
            if (configList[i] == name) {
                selectedIndex = i;
                break;
            }
        }
    }

    inline bool SaveLastConfigName(const std::string& name) {
        if (!EnsureConfigDirectory()) {
            return false;
        }

        std::ofstream out(GetLastConfigPath(), std::ios::trunc);
        if (!out.is_open()) {
            return false;
        }

        out << name;
        return true;
    }

    inline void ClearLastConfigNameIfMatches(const std::string& name) {
        std::ifstream in(GetLastConfigPath());
        if (!in.is_open()) {
            return;
        }

        std::string storedName;
        std::getline(in, storedName);
        in.close();

        if (Trim(storedName) != name) {
            return;
        }

        std::error_code ec;
        std::filesystem::remove(GetLastConfigPath(), ec);
    }

    inline std::string GetLastConfigName() {
        std::ifstream in(GetLastConfigPath());
        if (!in.is_open()) {
            return "";
        }

        std::string storedName;
        std::getline(in, storedName);
        return Trim(storedName);
    }

    inline void RefreshList() {
        configList.clear();
        selectedIndex = -1;

        if (!EnsureConfigDirectory()) {
            lastStatus = "Failed to create config folder";
            return;
        }

        for (const auto& entry : std::filesystem::directory_iterator(GetConfigDirectory())) {
            if (!entry.is_regular_file()) continue;
            if (entry.path().extension() != ".cfg") continue;
            configList.push_back(entry.path().stem().string());
        }

        std::sort(configList.begin(), configList.end());

        const std::string lastConfig = GetLastConfigName();
        if (!lastConfig.empty()) {
            UpdateSelectedIndex(lastConfig);
        }
    }

    inline void WriteBool(std::ofstream& out, const char* key, bool value) {
        out << key << '=' << (value ? 1 : 0) << '\n';
    }

    inline void WriteInt(std::ofstream& out, const char* key, int value) {
        out << key << '=' << value << '\n';
    }

    inline void WriteFloat(std::ofstream& out, const char* key, float value) {
        out << key << '=' << value << '\n';
    }

    inline void WriteString(std::ofstream& out, const char* key, const std::string& value) {
        out << key << '=' << value << '\n';
    }

    inline bool SaveConfig(const std::string& rawName) {
        const std::string name = Trim(rawName);
        if (name.empty()) {
            lastStatus = "Enter a config name";
            return false;
        }
        if (!EnsureConfigDirectory()) {
            lastStatus = "Failed to create config folder";
            return false;
        }

        std::ofstream out(GetConfigPath(name), std::ios::trunc);
        if (!out.is_open()) {
            lastStatus = "Failed to save config";
            return false;
        }

        WriteBool(out, "Aimbot.enabled", Vars::Aimbot::enabled);
        WriteBool(out, "Aimbot.showFOV", Vars::Aimbot::showFOV);
        WriteFloat(out, "Aimbot.fovRadius", Vars::Aimbot::fovRadius);
        WriteFloat(out, "Aimbot.smoothing", Vars::Aimbot::smoothing);
        WriteFloat(out, "Aimbot.predictionFactor", Vars::Aimbot::predictionFactor);
        WriteFloat(out, "Aimbot.maxAimDistance", Vars::Aimbot::maxAimDistance);
        WriteFloat(out, "Aimbot.lerpSpeed", Vars::Aimbot::lerpSpeed);
        WriteFloat(out, "Aimbot.deadzonePixels", Vars::Aimbot::deadzonePixels);
        WriteBool(out, "Aimbot.stickyTarget", Vars::Aimbot::stickyTarget);
        WriteInt(out, "Aimbot.aimTarget", Vars::Aimbot::aimTarget);
        WriteInt(out, "Aimbot.aimMethod", Vars::Aimbot::aimMethod);
        WriteInt(out, "Aimbot.aimbotKey", Vars::Aimbot::aimbotKey);
        WriteBool(out, "Aimbot.aimbotUseFov", Vars::Aimbot::aimbotUseFov);
        WriteBool(out, "Aimbot.aimbotTeamCheck", Vars::Aimbot::aimbotTeamCheck);
        WriteBool(out, "Aimbot.aimbotKnockCheck", Vars::Aimbot::aimbotKnockCheck);
        WriteBool(out, "Aimbot.aimbotHealthCheck", Vars::Aimbot::aimbotHealthCheck);
        WriteBool(out, "Aimbot.aimbotTriggerBot", Vars::Aimbot::aimbotTriggerBot);
        WriteBool(out, "SilentAim.enabled", Vars::SilentAim::silentAimEnabled);
        WriteInt(out, "SilentAim.key", Vars::SilentAim::silentAimKey);
        WriteBool(out, "SilentAim.sticky", Vars::SilentAim::silentStickyAim);
        WriteBool(out, "SilentAim.drawFov", Vars::SilentAim::silentDrawFov);
        WriteFloat(out, "SilentAim.fovRadius", Vars::SilentAim::silentFovRadius);
        WriteBool(out, "SilentAim.useAimbotTarget", Vars::SilentAim::silentUseAimbotTarget);
        WriteBool(out, "SilentAim.useFov", Vars::SilentAim::silentUseFov);
        WriteBool(out, "SilentAim.teamCheck", Vars::SilentAim::silentTeamCheck);
        WriteBool(out, "SilentAim.knockCheck", Vars::SilentAim::silentKnockCheck);
        WriteBool(out, "SilentAim.healthCheck", Vars::SilentAim::silentHealthCheck);
        WriteBool(out, "SilentAim.triggerBot", Vars::SilentAim::silentTriggerBot);
        WriteInt(out, "SilentAim.targetPart", Vars::SilentAim::silentTargetPart);

        WriteBool(out, "ESP.enabled", Vars::ESP::enabled);
        WriteBool(out, "ESP.boxes", Vars::ESP::boxes);
        WriteBool(out, "ESP.names", Vars::ESP::names);
        WriteBool(out, "ESP.distance", Vars::ESP::distance);
        WriteBool(out, "ESP.healthBar", Vars::ESP::healthBar);
        WriteBool(out, "ESP.skeleton", Vars::ESP::skeleton);
        WriteBool(out, "ESP.occludedArrows", Vars::ESP::occludedArrows);
        WriteInt(out, "ESP.boxStyle", Vars::ESP::boxStyle);
        WriteFloat(out, "ESP.maxDistance", Vars::ESP::maxDistance);
        WriteFloat(out, "ESP.skeletonColorR", Vars::ESP::skeletonColorR);
        WriteFloat(out, "ESP.skeletonColorG", Vars::ESP::skeletonColorG);
        WriteFloat(out, "ESP.skeletonColorB", Vars::ESP::skeletonColorB);
        WriteFloat(out, "ESP.skeletonColorA", Vars::ESP::skeletonColorA);
        WriteFloat(out, "ESP.skeletonThickness", Vars::ESP::skeletonThickness);

        WriteBool(out, "Local.speedEnabled", Vars::Local::speedEnabled);
        WriteFloat(out, "Local.walkSpeed", Vars::Local::walkSpeed);
        WriteBool(out, "Local.jumpEnabled", Vars::Local::jumpEnabled);
        WriteFloat(out, "Local.jumpPower", Vars::Local::jumpPower);
        WriteBool(out, "Local.gravityEnabled", Vars::Local::gravityEnabled);
        WriteFloat(out, "Local.gravityValue", Vars::Local::gravityValue);
        WriteBool(out, "Local.flyEnabled", Vars::Local::flyEnabled);
        WriteFloat(out, "Local.flySpeed", Vars::Local::flySpeed);
        WriteInt(out, "Local.flyMode", Vars::Local::flyMode);
        WriteInt(out, "Local.flyActivationMode", Vars::Local::flyActivationMode);
        WriteInt(out, "Local.flyKey", Vars::Local::flyKey);
        WriteBool(out, "Local.noclipEnabled", Vars::Local::noclipEnabled);
        WriteInt(out, "Local.noclipKey", Vars::Local::noclipKey);
        WriteInt(out, "Local.walkSpeedKey", Vars::Local::walkSpeedKey);
        WriteInt(out, "Local.jumpPowerKey", Vars::Local::jumpPowerKey);
        WriteInt(out, "Local.gravityKey", Vars::Local::gravityKey);

		WriteBool(out, "UI.antiScreenShare", Vars::UI::antiScreenShare);

        WriteBool(out, "Lighting.clockTimeEnabled", Vars::Lighting::clockTimeEnabled);
        WriteFloat(out, "Lighting.clockTime", Vars::Lighting::clockTime);
        WriteBool(out, "Lighting.brightnessEnabled", Vars::Lighting::brightnessEnabled);
        WriteFloat(out, "Lighting.brightness", Vars::Lighting::brightness);
        WriteBool(out, "Lighting.fogEnabled", Vars::Lighting::fogEnabled);
        WriteFloat(out, "Lighting.fogStart", Vars::Lighting::fogStart);
        WriteFloat(out, "Lighting.fogEnd", Vars::Lighting::fogEnd);
        WriteBool(out, "Lighting.shadowsEnabled", Vars::Lighting::shadowsEnabled);
        WriteBool(out, "Lighting.globalShadows", Vars::Lighting::globalShadows);

        WriteBool(out, "Watermark.enabled", Vars::Watermark::enabled);
        WriteBool(out, "Watermark.showServer", Vars::Watermark::showServer);
        WriteBool(out, "Watermark.showPlayerCount", Vars::Watermark::showPlayerCount);
        WriteBool(out, "Watermark.showUsername", Vars::Watermark::showUsername);
        WriteBool(out, "Watermark.showDisplayName", Vars::Watermark::showDisplayName);
        WriteInt(out, "Watermark.colorMode", Vars::Watermark::colorMode);
        WriteFloat(out, "Watermark.colorR", Vars::Watermark::colorR);
        WriteFloat(out, "Watermark.colorG", Vars::Watermark::colorG);
        WriteFloat(out, "Watermark.colorB", Vars::Watermark::colorB);
        WriteFloat(out, "Watermark.colorA", Vars::Watermark::colorA);
        WriteFloat(out, "Watermark.rainbowSpeed", Vars::Watermark::rainbowSpeed);
        WriteBool(out, "Watermark.useManualServer", Vars::Watermark::useManualServer);
        WriteString(out, "Watermark.manualServer", Vars::Watermark::manualServer);

        out.close();
        RefreshList();
        UpdateSelectedIndex(name);
        SaveLastConfigName(name);
        lastStatus = "Saved config: " + name;
        return true;
    }

    inline void ApplyValue(const std::string& key, const std::string& value) {
        const std::string trimmed = Trim(value);
        const auto toBool = [&]() { return trimmed == "1" || trimmed == "true" || trimmed == "True"; };
        const auto toInt = [&]() { return std::stoi(trimmed); };
        const auto toFloat = [&]() { return std::stof(trimmed); };

        if (key == "Aimbot.enabled") Vars::Aimbot::enabled = toBool();
        else if (key == "Aimbot.showFOV") Vars::Aimbot::showFOV = toBool();
        else if (key == "Aimbot.fovRadius") Vars::Aimbot::fovRadius = toFloat();
        else if (key == "Aimbot.smoothing") Vars::Aimbot::smoothing = toFloat();
        else if (key == "Aimbot.predictionFactor") Vars::Aimbot::predictionFactor = toFloat();
        else if (key == "Aimbot.maxAimDistance") Vars::Aimbot::maxAimDistance = toFloat();
        else if (key == "Aimbot.lerpSpeed") Vars::Aimbot::lerpSpeed = toFloat();
        else if (key == "Aimbot.deadzonePixels") Vars::Aimbot::deadzonePixels = toFloat();
        else if (key == "Aimbot.stickyTarget") Vars::Aimbot::stickyTarget = toBool();
        else if (key == "Aimbot.aimTarget") Vars::Aimbot::aimTarget = toInt();
        else if (key == "Aimbot.aimMethod") Vars::Aimbot::aimMethod = toInt();
        else if (key == "Aimbot.aimbotKey") Vars::Aimbot::aimbotKey = toInt();
        else if (key == "Aimbot.aimbotUseFov") Vars::Aimbot::aimbotUseFov = toBool();
        else if (key == "Aimbot.aimbotTeamCheck") Vars::Aimbot::aimbotTeamCheck = toBool();
        else if (key == "Aimbot.aimbotKnockCheck") Vars::Aimbot::aimbotKnockCheck = toBool();
        else if (key == "Aimbot.aimbotHealthCheck") Vars::Aimbot::aimbotHealthCheck = toBool();
        else if (key == "Aimbot.aimbotTriggerBot") Vars::Aimbot::aimbotTriggerBot = toBool();
        else if (key == "SilentAim.enabled") Vars::SilentAim::silentAimEnabled = toBool();
        else if (key == "SilentAim.key") Vars::SilentAim::silentAimKey = toInt();
        else if (key == "SilentAim.sticky") Vars::SilentAim::silentStickyAim = toBool();
        else if (key == "SilentAim.drawFov") Vars::SilentAim::silentDrawFov = toBool();
        else if (key == "SilentAim.fovRadius") Vars::SilentAim::silentFovRadius = toFloat();
        else if (key == "SilentAim.useAimbotTarget") Vars::SilentAim::silentUseAimbotTarget = toBool();
        else if (key == "SilentAim.useFov") Vars::SilentAim::silentUseFov = toBool();
        else if (key == "SilentAim.teamCheck") Vars::SilentAim::silentTeamCheck = toBool();
        else if (key == "SilentAim.knockCheck") Vars::SilentAim::silentKnockCheck = toBool();
        else if (key == "SilentAim.healthCheck") Vars::SilentAim::silentHealthCheck = toBool();
        else if (key == "SilentAim.triggerBot") Vars::SilentAim::silentTriggerBot = toBool();
        else if (key == "SilentAim.targetPart") Vars::SilentAim::silentTargetPart = toInt();
        else if (key == "ESP.enabled") Vars::ESP::enabled = toBool();
        else if (key == "ESP.boxes") Vars::ESP::boxes = toBool();
        else if (key == "ESP.names") Vars::ESP::names = toBool();
        else if (key == "ESP.distance") Vars::ESP::distance = toBool();
        else if (key == "ESP.healthBar") Vars::ESP::healthBar = toBool();
        else if (key == "ESP.skeleton") Vars::ESP::skeleton = toBool();
        else if (key == "ESP.occludedArrows") Vars::ESP::occludedArrows = toBool();
        else if (key == "ESP.boxStyle") Vars::ESP::boxStyle = toInt();
        else if (key == "ESP.maxDistance") Vars::ESP::maxDistance = toFloat();
        else if (key == "ESP.skeletonColorR") Vars::ESP::skeletonColorR = toFloat();
        else if (key == "ESP.skeletonColorG") Vars::ESP::skeletonColorG = toFloat();
        else if (key == "ESP.skeletonColorB") Vars::ESP::skeletonColorB = toFloat();
        else if (key == "ESP.skeletonColorA") Vars::ESP::skeletonColorA = toFloat();
        else if (key == "ESP.skeletonThickness") Vars::ESP::skeletonThickness = toFloat();
        else if (key == "Local.speedEnabled") Vars::Local::speedEnabled = toBool();
        else if (key == "Local.walkSpeed") Vars::Local::walkSpeed = toFloat();
        else if (key == "Local.jumpEnabled") Vars::Local::jumpEnabled = toBool();
        else if (key == "Local.jumpPower") Vars::Local::jumpPower = toFloat();
        else if (key == "Local.gravityEnabled") Vars::Local::gravityEnabled = toBool();
        else if (key == "Local.gravityValue") Vars::Local::gravityValue = toFloat();
        else if (key == "Local.flyEnabled") Vars::Local::flyEnabled = toBool();
        else if (key == "Local.flySpeed") Vars::Local::flySpeed = toFloat();
        else if (key == "Local.flyMode") Vars::Local::flyMode = toInt();
        else if (key == "Local.flyActivationMode") Vars::Local::flyActivationMode = toInt();
        else if (key == "Local.flyKey") Vars::Local::flyKey = toInt();
        else if (key == "Local.noclipEnabled") Vars::Local::noclipEnabled = toBool();
        else if (key == "Local.noclipKey") Vars::Local::noclipKey = toInt();
        else if (key == "Local.walkSpeedKey") Vars::Local::walkSpeedKey = toInt();
        else if (key == "Local.jumpPowerKey") Vars::Local::jumpPowerKey = toInt();
        else if (key == "Local.gravityKey") Vars::Local::gravityKey = toInt();
        else if (key == "Lighting.clockTimeEnabled") Vars::Lighting::clockTimeEnabled = toBool();
        else if (key == "Lighting.clockTime") Vars::Lighting::clockTime = toFloat();
        else if (key == "Lighting.brightnessEnabled") Vars::Lighting::brightnessEnabled = toBool();
        else if (key == "Lighting.brightness") Vars::Lighting::brightness = toFloat();
        else if (key == "Lighting.fogEnabled") Vars::Lighting::fogEnabled = toBool();
        else if (key == "Lighting.fogStart") Vars::Lighting::fogStart = toFloat();
        else if (key == "Lighting.fogEnd") Vars::Lighting::fogEnd = toFloat();
        else if (key == "Lighting.shadowsEnabled") Vars::Lighting::shadowsEnabled = toBool();
        else if (key == "Lighting.globalShadows") Vars::Lighting::globalShadows = toBool();
		else if (key == "UI.antiScreenShare") Vars::UI::antiScreenShare = toBool();
        else if (key == "Watermark.enabled") Vars::Watermark::enabled = toBool();
        else if (key == "Watermark.showServer") Vars::Watermark::showServer = toBool();
        else if (key == "Watermark.showPlayerCount") Vars::Watermark::showPlayerCount = toBool();
        else if (key == "Watermark.showUsername") Vars::Watermark::showUsername = toBool();
        else if (key == "Watermark.showDisplayName") Vars::Watermark::showDisplayName = toBool();
        else if (key == "Watermark.colorMode") Vars::Watermark::colorMode = toInt();
        else if (key == "Watermark.colorR") Vars::Watermark::colorR = toFloat();
        else if (key == "Watermark.colorG") Vars::Watermark::colorG = toFloat();
        else if (key == "Watermark.colorB") Vars::Watermark::colorB = toFloat();
        else if (key == "Watermark.colorA") Vars::Watermark::colorA = toFloat();
        else if (key == "Watermark.rainbowSpeed") Vars::Watermark::rainbowSpeed = toFloat();
        else if (key == "Watermark.useManualServer") Vars::Watermark::useManualServer = toBool();
        else if (key == "Watermark.manualServer") Vars::Watermark::manualServer = value;
    }

    inline bool LoadConfig(const std::string& rawName) {
        const std::string name = Trim(rawName);
        if (name.empty()) {
            lastStatus = "Enter a config name";
            return false;
        }

        std::ifstream in(GetConfigPath(name));
        if (!in.is_open()) {
            lastStatus = "Config not found: " + name;
            return false;
        }

        std::string line;
        while (std::getline(in, line)) {
            if (line.empty()) continue;
            const auto pos = line.find('=');
            if (pos == std::string::npos) continue;
            const std::string key = Trim(line.substr(0, pos));
            const std::string value = line.substr(pos + 1);
            try {
                ApplyValue(key, value);
            } catch (...) {
            }
        }

        UpdateSelectedIndex(name);
        SaveLastConfigName(name);
        lastStatus = "Loaded config: " + name;
        return true;
    }

    inline bool DeleteConfig(const std::string& rawName) {
        const std::string name = Trim(rawName);
        if (name.empty()) {
            lastStatus = "Enter a config name";
            return false;
        }

        std::error_code ec;
        const bool removed = std::filesystem::remove(GetConfigPath(name), ec);
        if (ec || !removed) {
            lastStatus = "Failed to delete config: " + name;
            return false;
        }

        ClearLastConfigNameIfMatches(name);
        RefreshList();
        lastStatus = "Deleted config: " + name;
        return true;
    }

    inline bool RenameConfig(const std::string& rawOldName, const std::string& rawNewName) {
        const std::string oldName = Trim(rawOldName);
        const std::string newName = Trim(rawNewName);

        if (oldName.empty() || newName.empty()) {
            lastStatus = "Enter both config names";
            return false;
        }

        if (oldName == newName) {
            lastStatus = "Config name is unchanged";
            return false;
        }

        if (!ConfigExists(oldName)) {
            lastStatus = "Config not found: " + oldName;
            return false;
        }

        if (ConfigExists(newName)) {
            lastStatus = "Config already exists: " + newName;
            return false;
        }

        std::error_code ec;
        std::filesystem::rename(GetConfigPath(oldName), GetConfigPath(newName), ec);
        if (ec) {
            lastStatus = "Failed to rename config";
            return false;
        }

        if (GetLastConfigName() == oldName) {
            SaveLastConfigName(newName);
        }

        RefreshList();
        UpdateSelectedIndex(newName);
        lastStatus = "Renamed config: " + oldName + " -> " + newName;
        return true;
    }

    inline bool AutoLoadLastConfig() {
        const std::string lastConfig = GetLastConfigName();
        if (lastConfig.empty()) {
            return false;
        }

        if (!ConfigExists(lastConfig)) {
            ClearLastConfigNameIfMatches(lastConfig);
            lastStatus = "Last config missing: " + lastConfig;
            return false;
        }

        if (!LoadConfig(lastConfig)) {
            return false;
        }

        lastStatus = "Auto-loaded config: " + lastConfig;
        return true;
    }

    inline const std::vector<std::string>& GetConfigs() {
        return configList;
    }
}
