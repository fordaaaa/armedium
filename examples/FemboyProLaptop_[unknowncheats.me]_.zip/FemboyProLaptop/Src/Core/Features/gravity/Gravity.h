﻿#pragma once
#include "../../../Core/Vars/Vars.h"
#include "../../../Core/Globals/Globals.h"
#include "../../../Game/Offsets/Offsets.h"
#include "../../../Memory/Communication.h"

namespace Gravity {
    inline constexpr float kDefaultGravity = 196.2f;

    inline bool hadOverride = false;
    inline float originalGravity = kDefaultGravity;

    inline uintptr_t GetWorkspaceAddress() {
        if (Globals::workspace.Addr != 0) return Globals::workspace.Addr;

        if (Globals::dataModel.Addr != 0) {
            const uintptr_t fromDataModel = Coms->ReadMemory<uintptr_t>(Globals::dataModel.Addr + Offsets::DataModel::Workspace);
            if (fromDataModel != 0) return fromDataModel;
        }

        return 0;
    }

    inline uintptr_t GetWorldAddress() {
        const uintptr_t workspace = GetWorkspaceAddress();
        if (workspace == 0) return 0;

        return Coms->ReadMemory<uintptr_t>(workspace + Offsets::Workspace::World);
    }

    inline float ReadWorldGravity() {
        const uintptr_t world = GetWorldAddress();
        if (world == 0) return 0.0f;

        return Coms->ReadMemory<float>(world + Offsets::World::Gravity);
    }

    inline void SetWorldGravity(float value) {
        const uintptr_t world = GetWorldAddress();
        if (world == 0) return;

        for (int i = 0; i < 8; i++) {
            Coms->WriteMemory<float>(world + Offsets::World::Gravity, value);
        }
    }

    inline float GetConfiguredGravity() {
        return Vars::Local::gravityEnabled ? Vars::Local::gravityValue : kDefaultGravity;
    }

    inline float GetRestoreGravity() {
        if (hadOverride) return originalGravity;

        const float currentGravity = ReadWorldGravity();
        if (currentGravity != 0.0f) return currentGravity;

        return originalGravity;
    }

    inline void RestoreIfOverridden() {
        if (!hadOverride) return;
        SetWorldGravity(originalGravity);
        hadOverride = false;
    }

    inline void Tick() {
        if (!Vars::Local::gravityEnabled) {
            RestoreIfOverridden();
            return;
        }

        if (!hadOverride) {
            const float currentGravity = ReadWorldGravity();
            if (currentGravity != 0.0f) {
                originalGravity = currentGravity;
                hadOverride = true;
            }
        }

        SetWorldGravity(Vars::Local::gravityValue);
    }
}