#pragma once
#include "../../../Game/W2S/W2S.h"
#include "../../../Core/Cache/Cache.h"
#include "../../../Core/Vars/Vars.h"
#include "../../../Core/Features/players/Players.h"
#include "../../../Game/SDK/SDK.h"
#include <windows.h>
#include <cmath>
#include <algorithm>
#include <chrono>
#include <thread>
#include <cstdint>

namespace Aimbot {

    inline uintptr_t lockedPlayerAddr = 0;
    inline uintptr_t silentLockedPlayerAddr = 0;
    inline std::chrono::steady_clock::time_point lastAimTick = std::chrono::steady_clock::now();

    inline void MoveMouse(float x, float y) 
    {
        INPUT input = { 0 };
        input.type = INPUT_MOUSE;
        input.mi.dwFlags = MOUSEEVENTF_MOVE;
        input.mi.dx = static_cast<LONG>(x);
        input.mi.dy = static_cast<LONG>(y);
        SendInput(1, &input, sizeof(INPUT));
    }

    inline bool IsKeyHeld(int vk) {
        if (vk == 1) return (GetAsyncKeyState(VK_LBUTTON) & 0x8000) != 0;
        if (vk == 2) return (GetAsyncKeyState(VK_RBUTTON) & 0x8000) != 0;
        if (vk == 4) return (GetAsyncKeyState(VK_MBUTTON) & 0x8000) != 0;
        if (vk == 5) return (GetAsyncKeyState(VK_XBUTTON1) & 0x8000) != 0;
        if (vk == 6) return (GetAsyncKeyState(VK_XBUTTON2) & 0x8000) != 0;
        if (vk == 16) return (GetAsyncKeyState(VK_SHIFT) & 0x8000) != 0;
        if (vk == 17) return (GetAsyncKeyState(VK_CONTROL) & 0x8000) != 0;
        if (vk == 18) return (GetAsyncKeyState(VK_MENU) & 0x8000) != 0;
        return vk > 0 && (GetAsyncKeyState(vk) & 0x8000) != 0;
    }

    inline float GetDistance2D(RBX::Vec2 a, RBX::Vec2 b) {
        float dx = a.X - b.X;
        float dy = a.Y - b.Y;
        return sqrtf(dx * dx + dy * dy);
    }

    inline float ClampFloat(float value, float minValue, float maxValue) {
        if (value < minValue) return minValue;
        if (value > maxValue) return maxValue;
        return value;
    }

    inline bool IsTargetWithinCrosshair(const RBX::Vec2& aimCenter, const RBX::Vec2& targetScreenPos, float deadzonePixels, float screenW, float screenH) {
        if (targetScreenPos.X <= 0.0f || targetScreenPos.Y <= 0.0f || targetScreenPos.X >= screenW || targetScreenPos.Y >= screenH) {
            return false;
        }

        const float targetDist = GetDistance2D(aimCenter, targetScreenPos);
        return targetDist <= (std::max)(1.0f, deadzonePixels);
    }

    inline RBX::Vec3 GetTargetAimPoint(RBX::RbxInstance targetPart, const RBX::Vec3& basePos, float distanceToTarget) {
        if (targetPart.Addr == 0) return basePos;

        RBX::Vec3 velocity = { 0.0f, 0.0f, 0.0f };
        const auto primitive = targetPart.GetPrimitivePtr();
        if (primitive != 0) {
            velocity = Coms->ReadMemory<RBX::Vec3>(primitive + Offsets::Primitive::AssemblyLinearVelocity);
        }

        const float distanceScale = distanceToTarget > 0.0f ? ClampFloat(distanceToTarget / 300.0f, 0.0f, 2.0f) : 0.0f;
        const float predictionTime = ClampFloat(Vars::Aimbot::predictionFactor * (0.35f + distanceScale), 0.0f, 0.30f);

        return {
            basePos.X + velocity.X * predictionTime,
            basePos.Y + velocity.Y * predictionTime,
            basePos.Z + velocity.Z * predictionTime
        };
    }

    inline RBX::RbxInstance ResolveTargetPart(const PlayerCache::CachedPlayer& plr, bool useSilentSelection) {
        auto character = RBX::RbxInstance(plr.characterAddr);
        if (!useSilentSelection) {
            return Vars::Aimbot::aimTarget == 0 ? character.FindChild("Head") : RBX::RbxInstance(plr.rootPartAddr);
        }

        if (Vars::SilentAim::silentUseAimbotTarget) {
            return Vars::Aimbot::aimTarget == 0 ? character.FindChild("Head") : RBX::RbxInstance(plr.rootPartAddr);
        }

        return Vars::SilentAim::silentTargetPart == 0 ? character.FindChild("Head") : RBX::RbxInstance(plr.rootPartAddr);
    }

    inline bool IsPlayerEligibleForSelection(const PlayerCache::CachedPlayer& plr, bool useSilentSelection) {
        if (!plr.isValid) return false;
        if (Vars::Aimbot::ignoreWhitelisted && PlayersFeature::IsWhitelisted(plr.playerAddr)) return false;
        if (Vars::Aimbot::maxAimDistance > 0.0f && plr.distance > Vars::Aimbot::maxAimDistance) return false;

        if (useSilentSelection) {
            if (Vars::SilentAim::silentHealthCheck && plr.health <= 0.1f) return false;
            if (Vars::SilentAim::silentKnockCheck) {
                const float knockThreshold = (plr.maxHealth > 0.0f) ? (plr.maxHealth * 0.1f) : 5.0f;
                if (plr.health <= knockThreshold) return false;
            }
            if (Vars::SilentAim::silentTeamCheck && Globals::localPlayer.Addr != 0) {
                const auto localTeam = Coms->ReadMemory<int32_t>(Globals::localPlayer.Addr + Offsets::Player::Team);
                const auto targetTeam = Coms->ReadMemory<int32_t>(plr.playerAddr + Offsets::Player::Team);
                if (targetTeam != 0 && localTeam == targetTeam) return false;
            }
            return true;
        }

        if (Vars::Aimbot::aimbotHealthCheck && plr.health <= 0.1f) return false;
        if (Vars::Aimbot::aimbotKnockCheck) {
            const float knockThreshold = (plr.maxHealth > 0.0f) ? (plr.maxHealth * 0.1f) : 5.0f;
            if (plr.health <= knockThreshold) return false;
        }
        if (Vars::Aimbot::aimbotTeamCheck && Globals::localPlayer.Addr != 0) {
            const auto localTeam = Coms->ReadMemory<int32_t>(Globals::localPlayer.Addr + Offsets::Player::Team);
            const auto targetTeam = Coms->ReadMemory<int32_t>(plr.playerAddr + Offsets::Player::Team);
            if (targetTeam != 0 && localTeam == targetTeam) return false;
        }
        return true;
    }

    inline void RunAimbot(const RBX::Mat4& viewMatrix) {
        if (!Vars::Aimbot::enabled && !Vars::SilentAim::silentAimEnabled) {
            lockedPlayerAddr = 0;
            silentLockedPlayerAddr = 0;
            return;
        }

        const bool aimbotActive = Vars::Aimbot::enabled && IsKeyHeld(Vars::Aimbot::aimbotKey);
        const bool silentActive = Vars::SilentAim::silentAimEnabled && (Vars::SilentAim::silentAimKey <= 0 || IsKeyHeld(Vars::SilentAim::silentAimKey));
        if (!aimbotActive && !silentActive) {
            lockedPlayerAddr = 0;
            silentLockedPlayerAddr = 0;
            return;
        }

        const bool useSilentSelection = silentActive;

        const auto now = std::chrono::steady_clock::now();
        float dt = std::chrono::duration<float>(now - lastAimTick).count();
        lastAimTick = now;
        dt = ClampFloat(dt, 1.0f / 300.0f, 1.0f / 20.0f);

        float screenW = static_cast<float>(GetSystemMetrics(SM_CXSCREEN));
        float screenH = static_cast<float>(GetSystemMetrics(SM_CYSCREEN));
        
        POINT mousePos;
        GetCursorPos(&mousePos);
        RBX::Vec2 aimCenter = { static_cast<float>(mousePos.x), static_cast<float>(mousePos.y) };

        if (useSilentSelection) {
            if (!Vars::SilentAim::silentStickyAim) {
                silentLockedPlayerAddr = 0;
            }

            if (silentLockedPlayerAddr != 0) {
                bool lockStillValid = false;
                for (const auto& plr : PlayerCache::players) {
                    if (!IsPlayerEligibleForSelection(plr, true)) continue;
                    if (plr.playerAddr != silentLockedPlayerAddr) continue;
                    lockStillValid = true;
                    break;
                }
                if (!lockStillValid) {
                    silentLockedPlayerAddr = 0;
                }
            }

            if (silentLockedPlayerAddr == 0) {
                float closestDist = 999999.0f;
                uintptr_t closestPlayerAddr = 0;
                const float selectionFov = Vars::SilentAim::silentFovRadius;
                const bool useFov = Vars::SilentAim::silentUseFov;

                for (auto& plr : PlayerCache::players) {
                    if (!IsPlayerEligibleForSelection(plr, true)) continue;

                    auto targetPart = ResolveTargetPart(plr, true);
                    if (targetPart.Addr == 0) continue;

                    const RBX::Vec3 targetPos = targetPart.GetPos();
                    const RBX::Vec3 predictedPos = GetTargetAimPoint(targetPart, targetPos, plr.distance);
                    const RBX::Vec2 screenPos = W2S::WorldToScreen(predictedPos, viewMatrix);

                    if (screenPos.X == 0 && screenPos.Y == 0) continue;
                    if (screenPos.X < 0 || screenPos.Y < 0 || screenPos.X > screenW || screenPos.Y > screenH) continue;

                    const float dist = GetDistance2D(aimCenter, screenPos);
                    const float distancePriority = plr.distance;
                    const float score = (useFov && dist < selectionFov) ? (distancePriority * 0.75f + dist) : (useFov ? 999999.0f : distancePriority * 0.75f + dist);

                    if (score < closestDist) {
                        closestDist = score;
                        closestPlayerAddr = plr.playerAddr;
                    }
                }

                if (closestPlayerAddr != 0) {
                    silentLockedPlayerAddr = closestPlayerAddr;
                }
            }

            if (silentLockedPlayerAddr != 0) {
                bool foundLockedPlayer = false;
                RBX::Vec2 targetScreenPos = { 0, 0 };

                for (auto& plr : PlayerCache::players) {
                    if (!IsPlayerEligibleForSelection(plr, true)) continue;
                    if (plr.playerAddr != silentLockedPlayerAddr) continue;

                    auto targetPart = ResolveTargetPart(plr, true);
                    if (targetPart.Addr == 0) break;

                    const RBX::Vec3 targetPos = targetPart.GetPos();
                    const RBX::Vec3 predictedPos = GetTargetAimPoint(targetPart, targetPos, plr.distance);
                    const RBX::Vec2 screenPos = W2S::WorldToScreen(predictedPos, viewMatrix);

                    if (screenPos.X == 0 && screenPos.Y == 0) break;
                    if (screenPos.X < 0 || screenPos.Y < 0 || screenPos.X > screenW || screenPos.Y > screenH) break;

                    targetScreenPos = screenPos;
                    foundLockedPlayer = true;
                    break;
                }

                if (foundLockedPlayer) {
                    const bool targetUnderCrosshair = IsTargetWithinCrosshair(aimCenter, targetScreenPos, Vars::Aimbot::deadzonePixels, screenW, screenH);
                    if (targetUnderCrosshair) {
                        static auto lastSilentTrigger = std::chrono::steady_clock::now();
                        if (Vars::SilentAim::silentTriggerBot) {
                            const auto nowTrigger = std::chrono::steady_clock::now();
                            if (std::chrono::duration_cast<std::chrono::milliseconds>(nowTrigger - lastSilentTrigger).count() >= 120) {
                                mouse_event(MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0);
                                mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, 0);
                                lastSilentTrigger = nowTrigger;
                            }
                        }
                    }
                }
            }
        }

        if (aimbotActive) {
            if (!Vars::Aimbot::stickyTarget) {
                lockedPlayerAddr = 0;
            }

            if (lockedPlayerAddr != 0) {
                bool lockStillValid = false;
                for (const auto& plr : PlayerCache::players) {
                    if (!IsPlayerEligibleForSelection(plr, false)) continue;
                    if (plr.playerAddr != lockedPlayerAddr) continue;
                    lockStillValid = true;
                    break;
                }
                if (!lockStillValid) {
                    lockedPlayerAddr = 0;
                }
            }

            if (lockedPlayerAddr == 0) {
                float closestDist = 999999.0f;
                uintptr_t closestPlayerAddr = 0;

                const float selectionFov = Vars::Aimbot::fovRadius;
                const bool useFov = Vars::Aimbot::aimbotUseFov;

                for (auto& plr : PlayerCache::players) {
                    if (!IsPlayerEligibleForSelection(plr, false)) continue;

                    auto targetPart = ResolveTargetPart(plr, false);
                    if (targetPart.Addr == 0) continue;

                    const RBX::Vec3 targetPos = targetPart.GetPos();
                    const RBX::Vec3 predictedPos = GetTargetAimPoint(targetPart, targetPos, plr.distance);
                    const RBX::Vec2 screenPos = W2S::WorldToScreen(predictedPos, viewMatrix);

                    if (screenPos.X == 0 && screenPos.Y == 0) continue;
                    if (screenPos.X < 0 || screenPos.Y < 0 || screenPos.X > screenW || screenPos.Y > screenH) continue;

                    const float dist = GetDistance2D(aimCenter, screenPos);
                    const float distancePriority = plr.distance;
                    const float score = (useFov && dist < selectionFov) ? (distancePriority * 0.75f + dist) : (useFov ? 999999.0f : distancePriority * 0.75f + dist);

                    if (score < closestDist) {
                        closestDist = score;
                        closestPlayerAddr = plr.playerAddr;
                    }
                }

                if (closestPlayerAddr != 0) {
                    lockedPlayerAddr = closestPlayerAddr;
                }
            }

            if (lockedPlayerAddr != 0) {
                bool foundLockedPlayer = false;
                RBX::Vec2 targetScreenPos = { 0, 0 };

                for (auto& plr : PlayerCache::players) {
                    if (!IsPlayerEligibleForSelection(plr, false)) continue;
                    if (plr.playerAddr != lockedPlayerAddr) continue;

                    auto targetPart = ResolveTargetPart(plr, false);
                    if (targetPart.Addr == 0) break;

                    const RBX::Vec3 targetPos = targetPart.GetPos();
                    const RBX::Vec3 predictedPos = GetTargetAimPoint(targetPart, targetPos, plr.distance);
                    const RBX::Vec2 screenPos = W2S::WorldToScreen(predictedPos, viewMatrix);

                    if (screenPos.X == 0 && screenPos.Y == 0) break;
                    if (screenPos.X < 0 || screenPos.Y < 0 || screenPos.X > screenW || screenPos.Y > screenH) break;

                    targetScreenPos = screenPos;
                    foundLockedPlayer = true;
                    break;
                }

                if (!foundLockedPlayer) {
                    lockedPlayerAddr = 0;
                    return;
                }

                float dx = targetScreenPos.X - mousePos.x;
                float dy = targetScreenPos.Y - mousePos.y;

                const bool targetUnderCrosshair = IsTargetWithinCrosshair(aimCenter, targetScreenPos, Vars::Aimbot::deadzonePixels, screenW, screenH);
                if (targetUnderCrosshair) {
                    static auto lastTrigger = std::chrono::steady_clock::now();
                    if (Vars::Aimbot::aimbotTriggerBot) {
                        const auto nowTrigger = std::chrono::steady_clock::now();
                        if (std::chrono::duration_cast<std::chrono::milliseconds>(nowTrigger - lastTrigger).count() >= 120) {
                            mouse_event(MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0);
                            mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, 0);
                            lastTrigger = nowTrigger;
                        }
                    }
                    return;
                }

                const float alpha = ClampFloat(Vars::Aimbot::lerpSpeed * dt * 60.0f, 0.03f, 1.0f);
                float moveX = dx * alpha;
                float moveY = dy * alpha;

                const float maxPixelsPerSecond = (std::max)(120.0f, Vars::Aimbot::smoothing * 180.0f);
                const float maxStep = maxPixelsPerSecond * dt;
                const float moveLen = sqrtf(moveX * moveX + moveY * moveY);
                if (moveLen > maxStep && moveLen > 0.0f) {
                    const float scale = maxStep / moveLen;
                    moveX *= scale;
                    moveY *= scale;
                }

                if (std::abs(moveX) < 0.01f && std::abs(moveY) < 0.01f) {
                    return;
                }

                MoveMouse(moveX, moveY);
            }
        }

        std::this_thread::sleep_for(std::chrono::milliseconds(2));
    }
}
