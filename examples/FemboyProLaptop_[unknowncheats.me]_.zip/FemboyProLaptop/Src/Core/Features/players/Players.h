#pragma once
#include "../../../Core/Cache/Cache.h"
#include "../../../Core/Globals/Globals.h"
#include "../../../Game/Offsets/Offsets.h"
#include "../../../Game/SDK/SDK.h"
#include <thread>
#include <chrono>
#include <unordered_set>
#include <mutex>
#include <string>
#include <sstream>
#include <iomanip>
#include <cctype>
#include <cmath>
#include <cstdlib>

namespace PlayersFeature {
    inline std::unordered_set<uintptr_t> whitelistedPlayers{};
    inline std::mutex whitelistMutex{};

    inline bool followEnabled = false;
    inline uintptr_t followTargetAddr = 0;
    inline float followDistance = 6.0f;

    inline bool IsWhitelisted(uintptr_t playerAddr) {
        std::lock_guard<std::mutex> lock(whitelistMutex);
        return whitelistedPlayers.find(playerAddr) != whitelistedPlayers.end();
    }

    inline bool SetWhitelist(uintptr_t playerAddr, bool enabled) {
        if (playerAddr == 0) {
            return false;
        }

        std::lock_guard<std::mutex> lock(whitelistMutex);
        if (enabled) {
            whitelistedPlayers.insert(playerAddr);
            return true;
        }

        whitelistedPlayers.erase(playerAddr);
        return false;
    }

    inline bool ToggleWhitelist(uintptr_t playerAddr) {
        if (playerAddr == 0) {
            return false;
        }

        std::lock_guard<std::mutex> lock(whitelistMutex);
        auto it = whitelistedPlayers.find(playerAddr);
        if (it != whitelistedPlayers.end()) {
            whitelistedPlayers.erase(it);
            return false;
        }

        whitelistedPlayers.insert(playerAddr);
        return true;
    }

    inline void SetFollowTarget(uintptr_t playerAddr) {
        followTargetAddr = playerAddr;
        followEnabled = (playerAddr != 0);
    }

    inline void SetFollowEnabled(bool enabled) {
        followEnabled = enabled;
        if (!enabled) {
            followTargetAddr = 0;
        }
    }

    inline bool IsFollowEnabled() {
        return followEnabled && followTargetAddr != 0;
    }

    inline uintptr_t GetFollowTarget() {
        return followTargetAddr;
    }

    inline float GetFollowDistance() {
        return followDistance;
    }

    inline void SetFollowDistance(float value) {
        if (value < 2.0f) value = 2.0f;
        if (value > 30.0f) value = 30.0f;
        followDistance = value;
    }

    inline RBX::RbxInstance GetCurrentCamera() {
        if (Globals::camera.Addr != 0) {
            return Globals::camera;
        }

        if (Globals::workspace.Addr == 0) {
            return RBX::RbxInstance(0);
        }

        const uintptr_t currentCameraAddr = Coms->ReadMemory<uintptr_t>(Globals::workspace.Addr + Offsets::Workspace::CurrentCamera);
        if (currentCameraAddr == 0) {
            return RBX::RbxInstance(0);
        }

        Globals::camera = RBX::RbxInstance(currentCameraAddr);
        return Globals::camera;
    }

    inline RBX::RbxInstance ResolveHumanoid(uintptr_t playerAddr) {
        if (playerAddr == 0) {
            return RBX::RbxInstance(0);
        }

        RBX::RbxInstance player(playerAddr);
        auto character = player.GetModelRef();
        if (character.Addr == 0) {
            return RBX::RbxInstance(0);
        }

        return character.FindChildByClass("Humanoid");
    }

    inline RBX::RbxInstance ResolveRootPart(uintptr_t playerAddr) {
        if (playerAddr == 0) {
            return RBX::RbxInstance(0);
        }

        RBX::RbxInstance player(playerAddr);
        auto character = player.GetModelRef();
        if (character.Addr == 0) {
            return RBX::RbxInstance(0);
        }

        return character.FindChild("HumanoidRootPart");
    }

    inline bool SpectatePlayer(uintptr_t playerAddr) {
        auto camera = GetCurrentCamera();
        if (camera.Addr == 0) {
            return false;
        }

        auto targetHumanoid = ResolveHumanoid(playerAddr);
        if (targetHumanoid.Addr == 0) {
            return false;
        }

        Coms->WriteMemory<uintptr_t>(camera.Addr + Offsets::Camera::CameraSubject, targetHumanoid.Addr);
        return true;
    }

    inline bool SpectateLocalPlayer() {
        if (Globals::localPlayer.Addr == 0) {
            return false;
        }
        return SpectatePlayer(Globals::localPlayer.Addr);
    }

    inline bool TeleportToPlayer(uintptr_t playerAddr) {
        if (Globals::localPlayer.Addr == 0) {
            return false;
        }

        auto targetRoot = ResolveRootPart(playerAddr);
        if (targetRoot.Addr == 0) {
            return false;
        }

        auto localRoot = ResolveRootPart(Globals::localPlayer.Addr);
        if (localRoot.Addr == 0) {
            return false;
        }

        const uintptr_t localPrim = localRoot.GetPrimitivePtr();
        const uintptr_t targetPrim = targetRoot.GetPrimitivePtr();
        if (localPrim == 0) {
            return false;
        }
        if (targetPrim == 0) {
            return false;
        }

        RBX::Vec3 targetPos = targetRoot.GetPos();
        targetPos.Y += 3.0f;
        const auto targetRot = Coms->ReadMemory<RBX::CFrame>(targetPrim + Offsets::Primitive::Rotation);
        const RBX::Vec3 zeroVel = { 0.0f, 0.0f, 0.0f };

        // Burst writes over multiple ticks to improve replication and reduce immediate snap-back.
        for (int i = 0; i < 18; ++i) {
            Coms->WriteMemory<RBX::Vec3>(localPrim + Offsets::Primitive::Position, targetPos);
            Coms->WriteMemory<RBX::CFrame>(localPrim + Offsets::Primitive::Rotation, targetRot);
            Coms->WriteMemory<RBX::Vec3>(localPrim + Offsets::Primitive::AssemblyLinearVelocity, zeroVel);
            Coms->WriteMemory<RBX::Vec3>(localPrim + Offsets::Primitive::AssemblyAngularVelocity, zeroVel);
            std::this_thread::sleep_for(std::chrono::milliseconds(1));
        }

        return true;
    }

    inline bool BuildPlayerPositionString(uintptr_t playerAddr, std::string& outText) {
        outText.clear();

        auto targetRoot = ResolveRootPart(playerAddr);
        if (targetRoot.Addr == 0) {
            return false;
        }

        const uintptr_t targetPrim = targetRoot.GetPrimitivePtr();
        if (targetPrim == 0) {
            return false;
        }

        const RBX::Vec3 pos = targetRoot.GetPos();
        const RBX::CFrame cf = Coms->ReadMemory<RBX::CFrame>(targetPrim + Offsets::Primitive::Rotation);

        std::ostringstream oss;
        oss << std::fixed << std::setprecision(3);
        oss << "Vector3(" << pos.X << ", " << pos.Y << ", " << pos.Z << ")";
        oss << " | CFrame(";
        for (int i = 0; i < 12; ++i) {
            if (i > 0) oss << ", ";
            oss << cf.data[i];
        }
        oss << ")";

        outText = oss.str();
        return true;
    }

    inline bool ParsePositionString(const std::string& input, RBX::Vec3& outPos) {
        auto extractFirstThreeFloats = [](const std::string& text, float out[3]) -> bool {
            int found = 0;
            const char* base = text.c_str();
            const char* cursor = base;

            while (*cursor != '\0' && found < 3) {
                const char ch = *cursor;
                const bool numericStart = std::isdigit(static_cast<unsigned char>(ch)) || ch == '-' || ch == '+' || ch == '.';
                if (!numericStart) {
                    ++cursor;
                    continue;
                }

                // Avoid parsing the trailing "3" in words like "Vector3".
                if (cursor > base && std::isalpha(static_cast<unsigned char>(*(cursor - 1)))) {
                    ++cursor;
                    continue;
                }

                char* endPtr = nullptr;
                const float value = std::strtof(cursor, &endPtr);
                if (endPtr != cursor) {
                    out[found++] = value;
                    cursor = endPtr;
                    continue;
                }

                ++cursor;
            }

            return found == 3;
        };

        float values[3] = { 0.0f, 0.0f, 0.0f };
        if (!extractFirstThreeFloats(input, values)) {
            return false;
        }

        const float x = values[0];
        const float y = values[1];
        const float z = values[2];

        if (!std::isfinite(x) || !std::isfinite(y) || !std::isfinite(z)) {
            return false;
        }

        outPos = { x, y, z };
        return true;
    }

    inline bool TeleportLocalToPosition(const RBX::Vec3& destination) {
        if (Globals::localPlayer.Addr == 0 && Globals::players.Addr != 0) {
            const uintptr_t localPlayerAddr = Coms->ReadMemory<uintptr_t>(Globals::players.Addr + Offsets::Player::LocalPlayer);
            if (localPlayerAddr != 0) {
                Globals::localPlayer = RBX::RbxInstance(localPlayerAddr);
            }
        }

        if (Globals::localPlayer.Addr == 0) {
            return false;
        }

        auto localRoot = ResolveRootPart(Globals::localPlayer.Addr);
        if (localRoot.Addr == 0) {
            return false;
        }

        const uintptr_t localPrim = localRoot.GetPrimitivePtr();
        if (localPrim == 0) {
            return false;
        }

        RBX::Vec3 targetPos = destination;
        const RBX::Vec3 zeroVel = { 0.0f, 0.0f, 0.0f };

        for (int i = 0; i < 14; ++i) {
            Coms->WriteMemory<RBX::Vec3>(localPrim + Offsets::Primitive::Position, targetPos);
            Coms->WriteMemory<RBX::Vec3>(localPrim + Offsets::Primitive::AssemblyLinearVelocity, zeroVel);
            Coms->WriteMemory<RBX::Vec3>(localPrim + Offsets::Primitive::AssemblyAngularVelocity, zeroVel);
            std::this_thread::sleep_for(std::chrono::milliseconds(1));
        }

        return true;
    }

    inline bool TeleportLocalToPositionString(const std::string& text) {
        RBX::Vec3 parsed{};
        if (!ParsePositionString(text, parsed)) {
            return false;
        }
        return TeleportLocalToPosition(parsed);
    }

    inline void TickFollow() {
        if (!IsFollowEnabled()) {
            return;
        }

        if (Globals::localPlayer.Addr == 0) {
            return;
        }

        auto targetRoot = ResolveRootPart(followTargetAddr);
        if (targetRoot.Addr == 0) {
            return;
        }

        auto localRoot = ResolveRootPart(Globals::localPlayer.Addr);
        if (localRoot.Addr == 0) {
            return;
        }

        const uintptr_t localPrim = localRoot.GetPrimitivePtr();
        if (localPrim == 0) {
            return;
        }

        RBX::Vec3 targetPos = targetRoot.GetPos();
        RBX::CFrame targetCf = targetRoot.GetCFrame();
        RBX::Vec3 look = targetCf.GetLookVector();

        RBX::Vec3 desiredPos = {
            targetPos.X - (look.X * followDistance),
            targetPos.Y + 2.0f,
            targetPos.Z - (look.Z * followDistance)
        };

        const RBX::Vec3 zeroVel = { 0.0f, 0.0f, 0.0f };
        Coms->WriteMemory<RBX::Vec3>(localPrim + Offsets::Primitive::Position, desiredPos);
        Coms->WriteMemory<RBX::Vec3>(localPrim + Offsets::Primitive::AssemblyLinearVelocity, zeroVel);
        Coms->WriteMemory<RBX::Vec3>(localPrim + Offsets::Primitive::AssemblyAngularVelocity, zeroVel);
    }
}
