#pragma once
#include <windows.h>
#include <cmath>
#include <vector>
#include "../../../Game/SDK/SDK.h"
#include "../../../Core/Vars/Vars.h"
#include "../../../Core/Globals/Globals.h"
#include "../gravity/Gravity.h"
#include "../../../Memory/Communication.h"

namespace Fly {
    struct Matrix3 {
        float m[9]{};
    };

    inline RBX::Vec3 Mul(const Matrix3& mat, const RBX::Vec3& v) {
        RBX::Vec3 out{};
        out.X = mat.m[0] * v.X + mat.m[1] * v.Y + mat.m[2] * v.Z;
        out.Y = mat.m[3] * v.X + mat.m[4] * v.Y + mat.m[5] * v.Z;
        out.Z = mat.m[6] * v.X + mat.m[7] * v.Y + mat.m[8] * v.Z;
        return out;
    }

    inline RBX::Vec3 Add(const RBX::Vec3& a, const RBX::Vec3& b) {
        return { a.X + b.X, a.Y + b.Y, a.Z + b.Z };
    }

    inline RBX::Vec3 Scale(const RBX::Vec3& a, float s) {
        return { a.X * s, a.Y * s, a.Z * s };
    }

    inline RBX::Vec3 Lerp(const RBX::Vec3& from, const RBX::Vec3& to, float alpha) {
        return {
            from.X + (to.X - from.X) * alpha,
            from.Y + (to.Y - from.Y) * alpha,
            from.Z + (to.Z - from.Z) * alpha
        };
    }

    inline RBX::Vec3 Normalize(const RBX::Vec3& v) {
        const float len = std::sqrt((v.X * v.X) + (v.Y * v.Y) + (v.Z * v.Z));
        if (len <= 0.0001f) return { 0.0f, 0.0f, 0.0f };
        return { v.X / len, v.Y / len, v.Z / len };
    }

    inline bool IsPartClass(const std::string& className) {
        return className == "Part" || className == "MeshPart" || className == "UnionOperation" || className == "BasePart";
    }

    inline void ForceCharacterNoCollision(RBX::RbxInstance character) {
        if (character.Addr == 0) return;

        const uint8_t collideMask = static_cast<uint8_t>(Offsets::PrimitiveFlags::CanCollide);
        std::vector<RBX::RbxInstance> stack;
        stack.push_back(character);

        while (!stack.empty()) {
            RBX::RbxInstance node = stack.back();
            stack.pop_back();

            auto children = node.GetChildList();
            for (auto child : children) {
                stack.push_back(child);

                if (!IsPartClass(child.GetClass())) {
                    continue;
                }

                const uintptr_t partPrimitive = child.GetPrimitivePtr();
                if (partPrimitive == 0) {
                    continue;
                }

                const uint8_t flags = Coms->ReadMemory<uint8_t>(partPrimitive + Offsets::Primitive::Flags);
                const uint8_t desired = static_cast<uint8_t>(flags & ~collideMask);
                if (desired != flags) {
                    Coms->WriteMemory<uint8_t>(partPrimitive + Offsets::Primitive::Flags, desired);
                }
            }
        }
    }

    inline bool IsFlyActive() {
        static bool toggled = false;
        static bool keyWasDown = false;

        const int key = Vars::Local::flyKey;
        const bool keyDown = (GetAsyncKeyState(key) & 0x8000) != 0;

        if (Vars::Local::flyActivationMode == 0) {
            return keyDown;
        }

        if (keyDown && !keyWasDown) {
            toggled = !toggled;
        }
        keyWasDown = keyDown;
        return toggled;
    }

    inline void Tick(RBX::RbxInstance character, bool noclipEnabled) {
        static bool wasActive = false;
        static RBX::Vec3 smoothedVelocity{ 0.0f, 0.0f, 0.0f };
        constexpr int kWriteBurst = 64;

        if (!Vars::Local::flyEnabled) {
            if (wasActive) {
                Gravity::SetWorldGravity(Gravity::GetRestoreGravity());
                smoothedVelocity = { 0.0f, 0.0f, 0.0f };
                wasActive = false;
            }
            return;
        }

        if (character.Addr == 0) return;

        auto rootPart = character.FindChild("HumanoidRootPart");
        if (rootPart.Addr == 0) return;

        const uintptr_t primitive = rootPart.GetPrimitivePtr();
        if (primitive == 0) return;

        const bool active = IsFlyActive();
        if (!active) {
            if (wasActive) {
                Coms->WriteMemory<RBX::Vec3>(primitive + Offsets::Primitive::AssemblyLinearVelocity, { 0.0f, 0.0f, 0.0f });
                Gravity::SetWorldGravity(Gravity::GetRestoreGravity());
                smoothedVelocity = { 0.0f, 0.0f, 0.0f };
                wasActive = false;
            }
            return;
        }

        if (noclipEnabled) {
            ForceCharacterNoCollision(character);
        }

        Gravity::SetWorldGravity(0.0f);
        wasActive = true;

        if (Globals::workspace.Addr != 0) {
            const uintptr_t currentCamera = Coms->ReadMemory<uintptr_t>(Globals::workspace.Addr + Offsets::Workspace::CurrentCamera);
            if (currentCamera != 0) {
                Globals::camera = RBX::RbxInstance(currentCamera);
            }
        }

        if (Globals::camera.Addr == 0) return;

        Matrix3 camRot = Coms->ReadMemory<Matrix3>(Globals::camera.Addr + Offsets::Camera::Rotation);
        RBX::Vec3 inputDir{ 0.0f, 0.0f, 0.0f };
        bool isMoving = false;

        if (GetAsyncKeyState('W') & 0x8000) {
            inputDir.Z -= 1.0f;
            isMoving = true;
        }
        if (GetAsyncKeyState('S') & 0x8000) {
            inputDir.Z += 1.0f;
            isMoving = true;
        }
        if (GetAsyncKeyState('A') & 0x8000) {
            inputDir.X -= 1.0f;
            isMoving = true;
        }
        if (GetAsyncKeyState('D') & 0x8000) {
            inputDir.X += 1.0f;
            isMoving = true;
        }
        if (GetAsyncKeyState(VK_SPACE) & 0x8000) {
            inputDir.Y += 1.0f;
            isMoving = true;
        }
        if (GetAsyncKeyState(VK_LCONTROL) & 0x8000) {
            inputDir.Y -= 1.0f;
            isMoving = true;
        }

        const RBX::Vec3 currentPos = Coms->ReadMemory<RBX::Vec3>(primitive + Offsets::Primitive::Position);
        const Matrix3 currentRot = Coms->ReadMemory<Matrix3>(primitive + Offsets::Primitive::Rotation);

        if (!isMoving) {
            if (Vars::Local::flyMode == 0) {
                smoothedVelocity = Lerp(smoothedVelocity, { 0.0f, 0.0f, 0.0f }, 0.45f);
                for (int i = 0; i < kWriteBurst; i++) {
                    Coms->WriteMemory<RBX::Vec3>(primitive + Offsets::Primitive::AssemblyLinearVelocity, smoothedVelocity);
                }
            } else {
                for (int i = 0; i < kWriteBurst; i++) {
                    Coms->WriteMemory<RBX::Vec3>(primitive + Offsets::Primitive::Position, currentPos);
                    Coms->WriteMemory<RBX::Vec3>(primitive + Offsets::Primitive::AssemblyLinearVelocity, { 0.0f, 0.0f, 0.0f });
                    if (Vars::Local::flyMode == 2) {
                        Coms->WriteMemory<Matrix3>(primitive + Offsets::Primitive::Rotation, currentRot);
                    }
                }
            }
            return;
        }

        const RBX::Vec3 worldDir = Mul(camRot, Normalize(inputDir));
        const float speed = Vars::Local::flySpeed;

        if (Vars::Local::flyMode == 0) {
            const RBX::Vec3 targetVelocity = Scale(worldDir, speed);
            const float velocityAlpha = noclipEnabled ? 0.55f : 0.35f;
            smoothedVelocity = Lerp(smoothedVelocity, targetVelocity, velocityAlpha);

            for (int i = 0; i < kWriteBurst; i++) {
                Coms->WriteMemory<RBX::Vec3>(primitive + Offsets::Primitive::AssemblyLinearVelocity, smoothedVelocity);
                if (noclipEnabled) {
                    Coms->WriteMemory<RBX::Vec3>(primitive + Offsets::Primitive::AssemblyAngularVelocity, { 0.0f, 0.0f, 0.0f });
                }
            }
            return;
        }

        const RBX::Vec3 nextPos = Add(currentPos, Scale(worldDir, speed / 165.0f));
        for (int i = 0; i < kWriteBurst; i++) {
            Coms->WriteMemory<RBX::Vec3>(primitive + Offsets::Primitive::Position, nextPos);
            Coms->WriteMemory<RBX::Vec3>(primitive + Offsets::Primitive::AssemblyLinearVelocity, { 0.0f, 0.0f, 0.0f });
            if (Vars::Local::flyMode == 2) {
                Coms->WriteMemory<Matrix3>(primitive + Offsets::Primitive::Rotation, currentRot);
            }
        }
    }
}
