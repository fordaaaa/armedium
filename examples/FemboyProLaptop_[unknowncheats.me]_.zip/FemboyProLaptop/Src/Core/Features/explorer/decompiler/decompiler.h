#pragma once
#include <cstdint>
#include <vector>
#include <string>
#include <sstream>
#include <iomanip>
#include <set>
#include <algorithm>
#include <cstring>
#include <windows.h>
#include "../../../../Game/Offsets/Offsets.h"
#include "../../../../Memory/Communication.h"
#include "../bytecode/bytecode.h"

namespace decompiler
{
    enum script_type
    {
        LocalScript = 0,
        ModuleScript = 1
    };

    class decompiler_t final
    {
    public:
        std::string DecompileScript(std::uint64_t script, script_type type, std::string* error = nullptr)
        {
            if (error) error->clear();

            if (script == 0) {
                if (error) *error = "Invalid script address";
                return "";
            }

            if (!Coms || !Coms->IsConnected()) {
                if (error) *error = "Process communicator is not connected";
                return "";
            }

            std::string source = decompress_script(script, type);
            if (source.empty()) {
                if (error) *error = "Failed to read or decode script bytecode";
                return "";
            }

            if (is_probably_text(source)) {
                return source;
            }

            std::string parseError;
            std::string pseudo = decompile_luau_chunk(source, &parseError);
            if (pseudo.empty()) {
                if (error) *error = parseError.empty() ? "Failed to reconstruct Luau source from bytecode" : parseError;
                return "";
            }

            return pseudo;
        }

    private:
        struct reader_t {
            const std::uint8_t* data{ nullptr };
            size_t size{ 0 };
            size_t pos{ 0 };

            size_t remaining() const {
                return pos <= size ? (size - pos) : 0;
            }

            bool skip(size_t count) {
                if (pos + count > size) return false;
                pos += count;
                return true;
            }

            bool read_u8(std::uint8_t& out) {
                if (pos + 1 > size) return false;
                out = data[pos++];
                return true;
            }

            bool read_u32(std::uint32_t& out) {
                if (pos + 4 > size) return false;
                out = static_cast<std::uint32_t>(data[pos])
                    | (static_cast<std::uint32_t>(data[pos + 1]) << 8)
                    | (static_cast<std::uint32_t>(data[pos + 2]) << 16)
                    | (static_cast<std::uint32_t>(data[pos + 3]) << 24);
                pos += 4;
                return true;
            }

            bool read_f32(float& out) {
                std::uint32_t bits = 0;
                if (!read_u32(bits)) return false;
                std::memcpy(&out, &bits, sizeof(out));
                return true;
            }

            bool read_f64(double& out) {
                if (pos + 8 > size) return false;
                std::uint64_t bits = static_cast<std::uint64_t>(data[pos])
                    | (static_cast<std::uint64_t>(data[pos + 1]) << 8)
                    | (static_cast<std::uint64_t>(data[pos + 2]) << 16)
                    | (static_cast<std::uint64_t>(data[pos + 3]) << 24)
                    | (static_cast<std::uint64_t>(data[pos + 4]) << 32)
                    | (static_cast<std::uint64_t>(data[pos + 5]) << 40)
                    | (static_cast<std::uint64_t>(data[pos + 6]) << 48)
                    | (static_cast<std::uint64_t>(data[pos + 7]) << 56);
                pos += 8;
                std::memcpy(&out, &bits, sizeof(out));
                return true;
            }

            bool read_var_u32(std::uint32_t& out) {
                out = 0;
                int shift = 0;
                for (int i = 0; i < 5; ++i) {
                    std::uint8_t b = 0;
                    if (!read_u8(b)) return false;
                    out |= static_cast<std::uint32_t>(b & 0x7f) << shift;
                    if ((b & 0x80) == 0) {
                        return true;
                    }
                    shift += 7;
                }
                return false;
            }

            bool read_bytes(std::string& out, size_t len) {
                if (pos + len > size) return false;
                out.assign(reinterpret_cast<const char*>(data + pos), len);
                pos += len;
                return true;
            }
        };

        struct proto_t {
            std::uint8_t maxStack{ 0 };
            std::uint8_t numParams{ 0 };
            std::uint8_t numUpvalues{ 0 };
            std::uint8_t isVarArg{ 0 };
            std::vector<std::uint32_t> code;
            std::vector<std::string> constants;
            std::vector<std::uint32_t> children;
        };

        static bool is_probably_text(const std::string& value)
        {
            if (value.empty()) return false;

            size_t printable = 0;
            for (unsigned char c : value) {
                if (c == '\n' || c == '\r' || c == '\t' || (c >= 32 && c < 127)) {
                    ++printable;
                }
            }

            const double ratio = static_cast<double>(printable) / static_cast<double>(value.size());
            return ratio >= 0.85;
        }

        static const char* opcode_name(std::uint8_t op)
        {
            static const char* names[] = {
                "NOP", "BREAK", "LOADNIL", "LOADB", "LOADN", "LOADK", "MOVE", "GETGLOBAL", "SETGLOBAL",
                "GETUPVAL", "SETUPVAL", "CLOSEUPVALS", "GETIMPORT", "GETTABLE", "SETTABLE", "GETTABLEKS",
                "SETTABLEKS", "GETTABLEN", "SETTABLEN", "NEWCLOSURE", "NAMECALL", "CALL", "RETURN",
                "JUMP", "JUMPBACK", "JUMPIF", "JUMPIFNOT", "JUMPIFEQ", "JUMPIFLE", "JUMPIFLT", "JUMPIFNOTEQ",
                "JUMPIFNOTLE", "JUMPIFNOTLT", "ADD", "SUB", "MUL", "DIV", "MOD", "POW", "ADDK", "SUBK",
                "MULK", "DIVK", "MODK", "POWK", "AND", "OR", "ANDK", "ORK", "CONCAT", "NOT", "MINUS",
                "LENGTH", "NEWTABLE", "DUPTABLE", "SETLIST", "FORNPREP", "FORNLOOP", "FORGLOOP", "FORGPREP",
                "FASTCALL", "COVERAGE", "CAPTURE", "GETVARARGS", "DUPCLOSURE", "PREPVARARGS", "LOADKX",
                "JUMPX", "FASTCALL1", "FASTCALL2", "FASTCALL2K", "FORGPREP_INEXT", "JUMPXEQKNIL",
                "JUMPXEQKB", "JUMPXEQKN", "JUMPXEQKS", "IDIV", "IDIVK"
            };

            constexpr size_t count = sizeof(names) / sizeof(names[0]);
            return op < count ? names[op] : "OP_UNKNOWN";
        }

        static bool opcode_has_aux(std::uint8_t op)
        {
            switch (op) {
            case 5:   // LOADK
            case 7:   // GETGLOBAL
            case 8:   // SETGLOBAL
            case 12:  // GETIMPORT
            case 15:  // GETTABLEKS
            case 16:  // SETTABLEKS
            case 19:  // NEWCLOSURE
            case 20:  // NAMECALL
            case 67:  // LOADKX
            case 69:  // FASTCALL1
            case 70:  // FASTCALL2
            case 71:  // FASTCALL2K
            case 73:  // JUMPXEQKNIL
            case 74:  // JUMPXEQKB
            case 75:  // JUMPXEQKN
            case 76:  // JUMPXEQKS
                return true;
            default:
                return false;
            }
        }

        static bool opcode_is_jump(std::uint8_t op)
        {
            switch (op) {
            case 23: // JUMP
            case 24: // JUMPBACK
            case 25: // JUMPIF
            case 26: // JUMPIFNOT
            case 27: // JUMPIFEQ
            case 28: // JUMPIFLE
            case 29: // JUMPIFLT
            case 30: // JUMPIFNOTEQ
            case 31: // JUMPIFNOTLE
            case 32: // JUMPIFNOTLT
            case 57: // FORNLOOP
            case 58: // FORGLOOP
            case 59: // FORGPREP
            case 68: // JUMPX
            case 72: // FORGPREP_INEXT
            case 73: // JUMPXEQKNIL
            case 74: // JUMPXEQKB
            case 75: // JUMPXEQKN
            case 76: // JUMPXEQKS
                return true;
            default:
                return false;
            }
        }

        static int jump_target_from_d(int pc, std::uint32_t insn)
        {
            const std::int16_t d = static_cast<std::int16_t>((insn >> 16) & 0xffff);
            return pc + 1 + static_cast<int>(d);
        }

        static std::string format_constant(std::uint8_t tag, reader_t& rd, const std::vector<std::string>& strings)
        {
            std::ostringstream oss;
            switch (tag) {
            case 0:
                return "nil";
            case 1: {
                std::uint8_t b = 0;
                if (!rd.read_u8(b)) return "<const-read-error>";
                return b ? "true" : "false";
            }
            case 2: {
                double d = 0.0;
                if (!rd.read_f64(d)) return "<const-read-error>";
                oss << d;
                return oss.str();
            }
            case 3: {
                std::uint32_t idx = 0;
                if (!rd.read_var_u32(idx)) return "<const-read-error>";
                if (idx < strings.size()) {
                    return '"' + strings[idx] + '"';
                }
                oss << "<str@" << idx << ">";
                return oss.str();
            }
            case 4: {
                std::uint32_t importId = 0;
                if (!rd.read_u32(importId)) return "<const-read-error>";
                oss << "<import 0x" << std::hex << importId << std::dec << ">";
                return oss.str();
            }
            case 5: {
                std::uint32_t n = 0;
                if (!rd.read_var_u32(n)) return "<const-read-error>";
                oss << "<table " << n << ">";
                return oss.str();
            }
            case 6: {
                std::uint32_t pid = 0;
                if (!rd.read_var_u32(pid)) return "<const-read-error>";
                oss << "<closure proto=" << pid << ">";
                return oss.str();
            }
            case 7: {
                float x = 0.f, y = 0.f, z = 0.f, w = 0.f;
                if (!rd.read_f32(x) || !rd.read_f32(y) || !rd.read_f32(z)) return "<const-read-error>";
                if (!rd.read_f32(w)) w = 0.0f;
                oss << "vector(" << x << ", " << y << ", " << z << ", " << w << ")";
                return oss.str();
            }
            default:
                oss << "<const tag=" << static_cast<int>(tag) << ">";
                return oss.str();
            }
        }

        static bool probe_chunk_header(const std::string& chunk, size_t& startOffset, size_t& postHeaderSkip, std::string& diag)
        {
            if (chunk.size() < 3) {
                diag = "Chunk too small";
                return false;
            }

            const auto* data = reinterpret_cast<const std::uint8_t*>(chunk.data());
            const size_t maxStart = std::min<size_t>(64, chunk.size() - 3);

            for (size_t s = 0; s <= maxStart; ++s) {
                const std::uint8_t version = data[s];
                if (version < 3 || version > 10) {
                    continue;
                }

                const std::uint8_t typesVersion = data[s + 1];

                for (size_t skip = 0; skip <= 4; ++skip) {
                    if (s + 2 + skip >= chunk.size()) {
                        continue;
                    }

                    bool plausiblePadding = true;
                    for (size_t i = 0; i < skip; ++i) {
                        const std::uint8_t pad = data[s + 2 + i];
                        if (pad > 3) {
                            plausiblePadding = false;
                            break;
                        }
                    }
                    if (!plausiblePadding) {
                        continue;
                    }

                    reader_t test;
                    test.data = data;
                    test.size = chunk.size();
                    test.pos = s + 2 + skip;

                    std::uint32_t strCount = 0;
                    if (!test.read_var_u32(strCount)) {
                        continue;
                    }

                    if (strCount > 1'000'000) {
                        continue;
                    }

                    std::ostringstream oss;
                    oss << "Header probe: offset=" << s
                        << " version=" << static_cast<int>(version)
                        << " typesVersion=" << static_cast<int>(typesVersion)
                        << " skip=" << skip
                        << " stringCount=" << strCount;
                    diag = oss.str();

                    startOffset = s;
                    postHeaderSkip = skip;
                    return true;
                }
            }

            diag = "No plausible Luau chunk header found in first 64 bytes";
            return false;
        }

        static bool parse_chunk(const std::string& chunk, std::vector<std::string>& strings, std::vector<proto_t>& protos, std::string* error, std::string* diagnostics)
        {
            reader_t rd;
            rd.data = reinterpret_cast<const std::uint8_t*>(chunk.data());
            rd.size = chunk.size();
            rd.pos = 0;

            size_t headerStart = 0;
            size_t postHeaderSkip = 0;
            std::string headerDiag;
            if (!probe_chunk_header(chunk, headerStart, postHeaderSkip, headerDiag)) {
                if (diagnostics) *diagnostics = headerDiag;
                if (error) *error = "Failed to locate Luau chunk header";
                return false;
            }

            rd.pos = headerStart;

            std::uint8_t version = 0;
            if (!rd.read_u8(version)) {
                if (error) *error = "Empty chunk";
                return false;
            }

            if (version < 3 || version > 8) {
                if (error) *error = "Unknown Luau bytecode version";
            }

            std::uint8_t typesVersion = 0;
            if (!rd.read_u8(typesVersion)) {
                if (error) *error = "Invalid chunk header";
                return false;
            }

            if (!rd.skip(postHeaderSkip)) {
                if (error) *error = "Invalid chunk header skip";
                return false;
            }

            std::uint32_t stringCount = 0;
            if (!rd.read_var_u32(stringCount)) {
                if (error) *error = "Failed reading string table size";
                return false;
            }

            if (stringCount > 1'000'000) {
                if (error) *error = "Unreasonable string table size";
                return false;
            }

            std::ostringstream diag;
            diag << headerDiag << "\n";
            diag << "Header values: version=" << static_cast<int>(version)
                << " typesVersion=" << static_cast<int>(typesVersion)
                << " stringCount=" << stringCount << "\n";

            strings.reserve(stringCount);
            for (std::uint32_t i = 0; i < stringCount; ++i) {
                std::uint32_t len = 0;
                if (!rd.read_var_u32(len)) {
                    if (error) *error = "Failed reading string length";
                    return false;
                }
                std::string s;
                if (len > rd.remaining()) {
                    if (error) *error = "String length exceeds remaining chunk bytes";
                    return false;
                }
                if (!rd.read_bytes(s, len)) {
                    if (error) *error = "Failed reading string bytes";
                    return false;
                }
                strings.push_back(std::move(s));
            }

            // Luau v6+ may emit one or more zero-count intermediate tables
            // (e.g. type declarations) between the string table and the proto
            // array.  Skip consecutive 0-count varints until we find the real
            // proto count or run out of plausible bytes.
            std::uint32_t protoCount = 0;
            {
                int skipCount = 0;
                for (;;) {
                    if (!rd.read_var_u32(protoCount)) {
                        if (error) *error = "Failed reading proto count";
                        if (diagnostics) *diagnostics = diag.str();
                        return false;
                    }
                    if (protoCount > 0 || rd.remaining() < 4 || skipCount >= 8) {
                        break;
                    }
                    diag << "Skipped 0-count intermediate field at pos=" << (rd.pos - 1)
                         << " remaining=" << rd.remaining()
                         << " (skip #" << (skipCount + 1) << ")\n";
                    ++skipCount;
                }
                if (skipCount > 0 && protoCount > 0) {
                    diag << "Found protoCount=" << protoCount
                         << " after skipping " << skipCount
                         << " intermediate field(s)\n";
                }
            }

            diag << "Proto section: protoCount=" << protoCount << "\n";

            if (protoCount > 100'000) {
                if (error) *error = "Unreasonable proto count";
                return false;
            }

            protos.reserve(protoCount);
            for (std::uint32_t p = 0; p < protoCount; ++p) {
                proto_t proto;
                if (!rd.read_u8(proto.maxStack) || !rd.read_u8(proto.numParams) || !rd.read_u8(proto.numUpvalues) || !rd.read_u8(proto.isVarArg)) {
                    diag << "Truncated while reading proto header at index " << p << "\n";
                    break;
                }

                std::uint32_t codeSize = 0;
                if (!rd.read_var_u32(codeSize)) {
                    diag << "Truncated while reading instruction count at proto " << p << "\n";
                    break;
                }

                if (codeSize > 10'000'000) {
                    diag << "Unreasonable instruction count at proto " << p << "\n";
                    break;
                }

                proto.code.reserve(codeSize);
                for (std::uint32_t i = 0; i < codeSize; ++i) {
                    std::uint32_t insn = 0;
                    if (!rd.read_u32(insn)) {
                        diag << "Truncated while reading instruction stream at proto " << p << "\n";
                        break;
                    }
                    proto.code.push_back(insn);
                }

                std::uint32_t constCount = 0;
                if (!rd.read_var_u32(constCount)) {
                    diag << "Truncated while reading constant count at proto " << p << "\n";
                    protos.push_back(std::move(proto));
                    break;
                }

                if (constCount > 10'000'000) {
                    diag << "Unreasonable constant count at proto " << p << "\n";
                    protos.push_back(std::move(proto));
                    break;
                }

                proto.constants.reserve(constCount);
                for (std::uint32_t i = 0; i < constCount; ++i) {
                    std::uint8_t tag = 0;
                    if (!rd.read_u8(tag)) {
                        diag << "Truncated while reading constant tag at proto " << p << "\n";
                        break;
                    }
                    proto.constants.push_back(format_constant(tag, rd, strings));
                }

                std::uint32_t childCount = 0;
                if (!rd.read_var_u32(childCount)) {
                    diag << "Truncated while reading child proto count at proto " << p << "\n";
                    protos.push_back(std::move(proto));
                    break;
                }

                if (childCount > 1'000'000) {
                    diag << "Unreasonable child proto count at proto " << p << "\n";
                    protos.push_back(std::move(proto));
                    break;
                }

                proto.children.reserve(childCount);
                for (std::uint32_t i = 0; i < childCount; ++i) {
                    std::uint32_t child = 0;
                    if (!rd.read_var_u32(child)) {
                        diag << "Truncated while reading child proto id at proto " << p << "\n";
                        break;
                    }
                    proto.children.push_back(child);
                }

                // Line info and optional debug sections vary by bytecode version.
                // We intentionally stop parsing here to keep this parser resilient.
                protos.push_back(std::move(proto));
            }

            diag << "Parse summary: parsedProtos=" << protos.size()
                << " remainingBytes=" << rd.remaining() << "\n";
            if (diagnostics) *diagnostics = diag.str();

            return true;
        }

        static std::string decompile_proto(const proto_t& proto, std::size_t index)
        {
            std::ostringstream oss;
            oss << "function proto_" << index << "(";
            for (int i = 0; i < proto.numParams; ++i) {
                if (i) oss << ", ";
                oss << "arg" << i;
            }
            if (proto.isVarArg) {
                if (proto.numParams) oss << ", ";
                oss << "...";
            }
            oss << ")\n";

            oss << "    -- maxstack=" << static_cast<int>(proto.maxStack)
                << " upvalues=" << static_cast<int>(proto.numUpvalues)
                << " constants=" << proto.constants.size() << "\n";

            if (!proto.constants.empty()) {
                oss << "    -- constants:\n";
                for (size_t i = 0; i < proto.constants.size(); ++i) {
                    oss << "    --   K" << i << " = " << proto.constants[i] << "\n";
                }
            }

            std::set<int> labels;
            for (int pc = 0; pc < static_cast<int>(proto.code.size());) {
                const std::uint32_t insn = proto.code[pc];
                const std::uint8_t op = static_cast<std::uint8_t>(insn & 0xff);
                if (opcode_is_jump(op)) {
                    const int target = jump_target_from_d(pc, insn);
                    if (target >= 0 && target < static_cast<int>(proto.code.size())) {
                        labels.insert(target);
                    }
                }
                pc += opcode_has_aux(op) ? 2 : 1;
            }

            for (int pc = 0; pc < static_cast<int>(proto.code.size());) {
                if (labels.count(pc)) {
                    oss << "L" << pc << ":\n";
                }

                const std::uint32_t insn = proto.code[pc];
                const std::uint8_t op = static_cast<std::uint8_t>(insn & 0xff);
                const std::uint8_t a = static_cast<std::uint8_t>((insn >> 8) & 0xff);
                const std::uint8_t b = static_cast<std::uint8_t>((insn >> 16) & 0xff);
                const std::uint8_t c = static_cast<std::uint8_t>((insn >> 24) & 0xff);
                const std::int16_t d = static_cast<std::int16_t>((insn >> 16) & 0xffff);

                oss << "    -- [" << std::setw(4) << std::setfill('0') << pc << "] " << opcode_name(op)
                    << " A=" << static_cast<int>(a)
                    << " B=" << static_cast<int>(b)
                    << " C=" << static_cast<int>(c)
                    << " D=" << d;

                if (opcode_has_aux(op) && pc + 1 < static_cast<int>(proto.code.size())) {
                    const std::uint32_t aux = proto.code[pc + 1];
                    oss << " AUX=0x" << std::hex << aux << std::dec;
                }

                if (opcode_is_jump(op)) {
                    const int target = jump_target_from_d(pc, insn);
                    oss << " -> L" << target;
                }

                oss << "\n";
                pc += opcode_has_aux(op) ? 2 : 1;
            }

            oss << "end\n";
            return oss.str();
        }

        static std::string decompile_luau_chunk(const std::string& chunk, std::string* error)
        {
            std::vector<std::string> strings;
            std::vector<proto_t> protos;
            std::string diagnostics;

            if (!parse_chunk(chunk, strings, protos, error, &diagnostics)) {
                if (error && !diagnostics.empty()) {
                    *error += "\n" + diagnostics;
                }
                return "";
            }

            if (protos.empty()) {
                if (error) {
                    *error = "No function prototypes found in Luau chunk";
                    if (!diagnostics.empty()) {
                        *error += "\n" + diagnostics;
                    }
                }
                return "";
            }

            std::ostringstream oss;
            oss << "-- Decompiled from Luau bytecode\n";
            oss << "-- strings=" << strings.size() << " protos=" << protos.size() << "\n\n";
            if (!diagnostics.empty()) {
                std::istringstream in(diagnostics);
                std::string line;
                while (std::getline(in, line)) {
                    if (!line.empty()) {
                        oss << "-- parser: " << line << "\n";
                    }
                }
                oss << "\n";
            }

            for (size_t i = 0; i < protos.size(); ++i) {
                oss << decompile_proto(protos[i], i) << "\n";
            }

            return oss.str();
        }

        std::string decompress_script(std::uint64_t script, script_type type)
        {
            const uintptr_t scriptAddress = static_cast<uintptr_t>(script);
            const uintptr_t scriptBytecodeOffset = (type == ModuleScript)
                ? Offsets::ModuleScript::ByteCode
                : Offsets::LocalScript::ByteCode;

            const uintptr_t bytecodeContainer = Coms->ReadMemory<uintptr_t>(scriptAddress + scriptBytecodeOffset);
            if (bytecodeContainer == 0) {
                return "";
            }

            const uintptr_t bytecodePtr = Coms->ReadMemory<uintptr_t>(bytecodeContainer + Offsets::ByteCode::Pointer);
            if (bytecodePtr == 0) {
                return "";
            }

            const size_t bytecodeSize = static_cast<size_t>(Coms->ReadMemory<uintptr_t>(bytecodeContainer + Offsets::ByteCode::Size));
            if (bytecodeSize == 0 || bytecodeSize > (8u * 1024u * 1024u)) {
                return "";
            }

            std::string raw(bytecodeSize, '\0');
            Coms->ReadBuffer(bytecodePtr, raw.data(), bytecodeSize);

            if (raw.empty()) {
                return "";
            }

            std::string decoded = Bytecode::decompress(raw);
            if (!decoded.empty()) {
                return decoded;
            }

            return "";
        }
    };
}