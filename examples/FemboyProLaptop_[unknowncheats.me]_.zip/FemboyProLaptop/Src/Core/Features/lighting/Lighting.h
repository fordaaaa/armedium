#pragma once
#include "../../../Core/Vars/Vars.h"
#include "../../../Core/Globals/Globals.h"
#include "clocktime/ClockTime.h"
#include "brightness/Brightness.h"
#include "fog/Fog.h"
#include "shadows/Shadows.h"

namespace LightingFeature {
    struct RestoreState {
        bool captured = false;
        float originalClockTime = 12.0f;
        float originalBrightness = 2.0f;
        Fog::OriginalValues originalFog{};
        bool originalGlobalShadows = true;
    };

    inline RestoreState restoreState{};

    inline bool IsLightingEnabled() {
        return ClockTime::IsEnabled()
            || Brightness::IsEnabled()
            || Fog::IsEnabled()
            || Shadows::IsEnabled();
    }

    inline void CaptureDefaults() {
        if (restoreState.captured || Globals::lighting.Addr == 0) return;

        restoreState.originalClockTime = ClockTime::CaptureOriginal();
        restoreState.originalBrightness = Brightness::CaptureOriginal();
        restoreState.originalFog = Fog::CaptureOriginal();
        restoreState.originalGlobalShadows = Shadows::CaptureOriginal();
        restoreState.captured = true;
    }

    inline void Tick() {
        if (Globals::lighting.Addr == 0) return;
        if (!IsLightingEnabled()) return;

        CaptureDefaults();

        ClockTime::Tick();
        Brightness::Tick();
        Fog::Tick();
        Shadows::Tick();
    }

    inline void RestoreDefaults() {
        if (!restoreState.captured || Globals::lighting.Addr == 0) return;

        ClockTime::Restore(restoreState.originalClockTime);
        Brightness::Restore(restoreState.originalBrightness);
        Fog::Restore(restoreState.originalFog);
        Shadows::Restore(restoreState.originalGlobalShadows);
    }
}
