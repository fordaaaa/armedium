#pragma once
#include "../../../../Core/Vars/Vars.h"
#include "../../../../Core/Globals/Globals.h"
#include "../../../../Game/Offsets/Offsets.h"
#include "../../../../Memory/Communication.h"

namespace LightingFeature::ClockTime {
    inline float CaptureOriginal() {
        if (Globals::lighting.Addr == 0) return 12.0f;
        return Coms->ReadMemory<float>(Globals::lighting.Addr + Offsets::Lighting::ClockTime);
    }

    inline bool IsEnabled() {
        return Vars::Lighting::clockTimeEnabled;
    }

    inline void Tick() {
        if (!IsEnabled() || Globals::lighting.Addr == 0) return;
        Coms->WriteMemory<float>(Globals::lighting.Addr + Offsets::Lighting::ClockTime, Vars::Lighting::clockTime);
    }

    inline void Restore(float value) {
        if (Globals::lighting.Addr == 0) return;
        Coms->WriteMemory<float>(Globals::lighting.Addr + Offsets::Lighting::ClockTime, value);
        Vars::Lighting::clockTimeEnabled = false;
    }
}
