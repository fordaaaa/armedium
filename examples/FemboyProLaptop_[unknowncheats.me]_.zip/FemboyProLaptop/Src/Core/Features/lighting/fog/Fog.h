#pragma once
#include "../../../../Core/Vars/Vars.h"
#include "../../../../Core/Globals/Globals.h"
#include "../../../../Game/Offsets/Offsets.h"
#include "../../../../Memory/Communication.h"

namespace LightingFeature::Fog {
    struct OriginalValues {
        float fogStart = 0.0f;
        float fogEnd = 100000.0f;
    };

    inline OriginalValues CaptureOriginal() {
        OriginalValues values{};
        if (Globals::lighting.Addr == 0) return values;
        values.fogStart = Coms->ReadMemory<float>(Globals::lighting.Addr + Offsets::Lighting::FogStart);
        values.fogEnd = Coms->ReadMemory<float>(Globals::lighting.Addr + Offsets::Lighting::FogEnd);
        return values;
    }

    inline bool IsEnabled() {
        return Vars::Lighting::fogEnabled;
    }

    inline void Tick() {
        if (!IsEnabled() || Globals::lighting.Addr == 0) return;
        Coms->WriteMemory<float>(Globals::lighting.Addr + Offsets::Lighting::FogStart, Vars::Lighting::fogStart);
        Coms->WriteMemory<float>(Globals::lighting.Addr + Offsets::Lighting::FogEnd, Vars::Lighting::fogEnd);
    }

    inline void Restore(const OriginalValues& values) {
        if (Globals::lighting.Addr == 0) return;
        Coms->WriteMemory<float>(Globals::lighting.Addr + Offsets::Lighting::FogStart, values.fogStart);
        Coms->WriteMemory<float>(Globals::lighting.Addr + Offsets::Lighting::FogEnd, values.fogEnd);
        Vars::Lighting::fogEnabled = false;
    }
}
