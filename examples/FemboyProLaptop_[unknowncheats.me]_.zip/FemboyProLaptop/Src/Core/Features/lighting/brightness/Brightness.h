#pragma once
#include "../../../../Core/Vars/Vars.h"
#include "../../../../Core/Globals/Globals.h"
#include "../../../../Game/Offsets/Offsets.h"
#include "../../../../Memory/Communication.h"

namespace LightingFeature::Brightness {
    inline float CaptureOriginal() {
        if (Globals::lighting.Addr == 0) return 2.0f;
        return Coms->ReadMemory<float>(Globals::lighting.Addr + Offsets::Lighting::Brightness);
    }

    inline bool IsEnabled() {
        return Vars::Lighting::brightnessEnabled;
    }

    inline void Tick() {
        if (!IsEnabled() || Globals::lighting.Addr == 0) return;
        Coms->WriteMemory<float>(Globals::lighting.Addr + Offsets::Lighting::Brightness, Vars::Lighting::brightness);
    }

    inline void Restore(float value) {
        if (Globals::lighting.Addr == 0) return;
        Coms->WriteMemory<float>(Globals::lighting.Addr + Offsets::Lighting::Brightness, value);
        Vars::Lighting::brightnessEnabled = false;
    }
}
