#pragma once
#include "../../../../Core/Vars/Vars.h"
#include "../../../../Core/Globals/Globals.h"
#include "../../../../Game/Offsets/Offsets.h"
#include "../../../../Memory/Communication.h"

namespace LightingFeature::Shadows {
    inline bool CaptureOriginal() {
        if (Globals::lighting.Addr == 0) return true;
        return Coms->ReadMemory<bool>(Globals::lighting.Addr + Offsets::Lighting::GlobalShadows);
    }

    inline bool IsEnabled() {
        return Vars::Lighting::shadowsEnabled;
    }

    inline void Tick() {
        if (!IsEnabled() || Globals::lighting.Addr == 0) return;
        Coms->WriteMemory<bool>(Globals::lighting.Addr + Offsets::Lighting::GlobalShadows, Vars::Lighting::globalShadows);
    }

    inline void Restore(bool value) {
        if (Globals::lighting.Addr == 0) return;
        Coms->WriteMemory<bool>(Globals::lighting.Addr + Offsets::Lighting::GlobalShadows, value);
        Vars::Lighting::shadowsEnabled = false;
    }
}
