#pragma once
#include <string>
#include <array>

namespace Vars {
    inline bool menuOpen = false;
    inline int selectedTab = 0;

    namespace Aimbot {
        inline bool enabled = false;
        inline bool showFOV = false;
        inline float fovRadius = 100.0f;
        inline float smoothing = 5.0f;
        inline float predictionFactor = 0.12f;
        inline float maxAimDistance = 0.0f;
        inline float lerpSpeed = 0.18f;
        inline float deadzonePixels = 2.5f;
        inline bool stickyTarget = true;
        inline int aimTarget = 0;
        inline int aimMethod = 0;
        inline int aimbotKey = 2;
        inline bool ignoreWhitelisted = true;
        inline bool aimbotUseFov = true;
        inline bool aimbotTeamCheck = false;
        inline bool aimbotKnockCheck = false;
        inline bool aimbotHealthCheck = true;
        inline bool aimbotTriggerBot = false;
    }

    namespace SilentAim {
        inline bool silentAimEnabled = false;
        inline int silentAimKey = 0;
        inline bool silentStickyAim = true;
        inline bool silentDrawFov = false;
        inline float silentFovRadius = 120.0f;
        inline bool silentUseAimbotTarget = true;
        inline bool silentUseFov = true;
        inline bool silentTeamCheck = false;
        inline bool silentKnockCheck = false;
        inline bool silentHealthCheck = true;
        inline bool silentTriggerBot = false;
        inline int silentTargetPart = 0;
    }

    inline bool& aimbotDrawFov = Aimbot::showFOV;
    inline bool& silentDrawFov = SilentAim::silentDrawFov;

    namespace ESP {
        inline bool enabled = false;
        inline bool boxes = false;
        inline bool names = false;
        inline bool distance = false;
        inline bool healthBar = false;
        inline bool skeleton = false;
        inline bool occludedArrows = false;
        inline int boxStyle = 0;
        inline float maxDistance = 0.0f;
        inline float skeletonColorR = 1.0f;
        inline float skeletonColorG = 1.0f;
        inline float skeletonColorB = 1.0f;
        inline float skeletonColorA = 1.0f;
        inline float skeletonThickness = 1.5f;
        inline bool skeletonUseSmoothing = false;
        inline float skeletonSmoothing = 8.0f;
        inline bool skeletonHighFidelity = false; 
        inline float skeletonFadeStart = 0.0f;
        inline float skeletonFadeEnd = 100.0f;
        inline bool whitelistColorEnabled = true;
        inline float whitelistColorR = 1.0f;
        inline float whitelistColorG = 0.45f;
        inline float whitelistColorB = 0.75f;
        inline float whitelistColorA = 1.0f;
    }

    namespace Local {
        inline bool speedEnabled = false;
        inline float walkSpeed = 16.0f;
        inline bool jumpEnabled = false;
        inline float jumpPower = 50.0f;
        inline bool gravityEnabled = false;
        inline float gravityValue = 196.2f;
        inline bool flyEnabled = false;
        inline float flySpeed = 80.0f;
        inline int flyMode = 0; // 0=velocity,1=position,2=position+rotation
        inline int flyActivationMode = 0; // 0=hold,1=toggle
        inline int flyKey = 'F';
        inline bool noclipEnabled = false;
        inline int noclipKey = 'N';
        inline int walkSpeedKey = 0;
        inline int jumpPowerKey = 0;
        inline int gravityKey = 0;
    }

    namespace Lighting {
        inline bool clockTimeEnabled = false;
        inline float clockTime = 12.0f;
        inline bool brightnessEnabled = false;
        inline float brightness = 2.0f;
        inline bool fogEnabled = false;
        inline float fogStart = 0.0f;
        inline float fogEnd = 100000.0f;
        inline bool shadowsEnabled = false;
        inline bool globalShadows = true;
    }

    namespace UI {
        inline bool watermarkEnabled = true;
        inline bool showFps = true;
        inline bool showVersion = true;
        inline float accentHue = 0.88f;
        inline int currentFPS = 0;
        inline bool unloadRequested = false;
        inline bool antiScreenShare = true; // recommended to keep this enabled
        inline bool vsyncEnabled = true;
    }

    namespace Watermark {
        inline bool enabled = true;
        inline bool showServer = true;
        inline bool showPlayerCount = true;
        inline bool showUsername = true;
        inline bool showDisplayName = true;
        inline int colorMode = 0;
        inline float colorR = 1.0f;
        inline float colorG = 1.0f;
        inline float colorB = 1.0f;
        inline float colorA = 1.0f;
        inline float rainbowSpeed = 0.2f;
        inline bool useManualServer = false;
        inline std::string manualServer = ""; 
    }
}