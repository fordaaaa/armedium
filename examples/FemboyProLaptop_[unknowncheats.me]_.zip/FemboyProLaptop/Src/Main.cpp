#define WIN32_LEAN_AND_MEAN
#include "Memory/Communication.h"
#include "Game/Offsets/Offsets.h"
#include "Game/SDK/SDK.h"
#include "Render/Render.h"
#include "Core/Globals/Globals.h"
#include "Core/Cache/Cache.h"
#include "Core/Features/Visuals/Visuals.h"
#include "Core/Features/Aimbot/Aimbot.h"
#include "Core/Features/Config/Config.h"
#include "Core/Features/lighting/Lighting.h"
#include "Core/Features/gravity/Gravity.h"
#include "Core/Features/fly/Fly.h"
#include "Core/Features/players/Players.h"
#include <iostream>
#include <thread>
#include <chrono>
#include <windows.h>
#include <atomic>
#include <cmath>
#include <array>
#include <vector>

bool IsGameRunning(const wchar_t* windowTitle)
{
    HWND hwnd = FindWindowW(NULL, windowTitle);
    return hwnd != NULL;
}

std::atomic<bool> running(true);
std::atomic<bool> shutdownRequested(false);
constexpr int kTargetFps = 3500;
constexpr auto kFrameBudget = std::chrono::microseconds(1000000 / kTargetFps);

BOOL WINAPI ConsoleControlHandler(DWORD controlType)
{
    switch (controlType) {
        case CTRL_C_EVENT:
        case CTRL_BREAK_EVENT:
        case CTRL_CLOSE_EVENT:
        case CTRL_LOGOFF_EVENT:
        case CTRL_SHUTDOWN_EVENT:
            shutdownRequested = true;
            running = false;
            return TRUE;
        default:
            return FALSE;
    }
}

namespace {
    uintptr_t ResolveVisualEngineAddress(uintptr_t baseAddr) {
        const std::array<uintptr_t, 5> candidateOffsets = {
            Offsets::VisualEngine::Pointer,
            Offsets::FakeDataModel::Pointer,
            Offsets::DataModel::ToRenderView1,
            Offsets::DataModel::ToRenderView2,
            Offsets::DataModel::ToRenderView3
        };

        for (size_t i = 0; i < candidateOffsets.size(); ++i) {
            const auto candidateAddr = baseAddr + candidateOffsets[i];
            const auto candidateValue = Coms->ReadMemory<uintptr_t>(candidateAddr);

            std::cout << "[*] Candidate " << i << " at 0x" << std::hex << candidateAddr
                      << " -> 0x" << candidateValue << std::dec << "\n";

            if (candidateValue == 0) {
                continue;
            }

            const auto fakeDataModel = Coms->ReadMemory<uintptr_t>(candidateValue + Offsets::VisualEngine::FakeDataModel);
            if (fakeDataModel == 0) {
                continue;
            }

            const auto dataModelPtr = Coms->ReadMemory<uintptr_t>(fakeDataModel + Offsets::FakeDataModel::RealDataModel);
            if (dataModelPtr != 0) {
                std::cout << "[+] Resolved VisualEngine via candidate " << i
                          << " (offset 0x" << std::hex << candidateOffsets[i] << std::dec << ")\n";
                return candidateValue;
            }
        }

        return 0;
    }

    struct LocalRestoreState {
        bool walkCaptured = false;
        float originalWalkSpeed = 16.0f;
        uintptr_t walkHumanoid = 0;

        bool jumpCaptured = false;
        float originalJumpPower = 50.0f;
        uintptr_t jumpHumanoid = 0;
    } gLocalRestore;

    bool gNoclipKeyWasDown = false;
    bool gLastNoclipState = false;
    auto gLastNoclipApply = std::chrono::steady_clock::now();
    bool gWalkSpeedKeyWasDown = false;
    bool gJumpPowerKeyWasDown = false;
    bool gGravityKeyWasDown = false;

    inline bool IsReasonableStat(float value) {
        return value > 0.0f && value < 10000.0f;
    }

    inline bool WasHotkeyPressed(int vk, bool& wasDown) {
        if (vk <= 0) return false;
        const bool isDown = (GetAsyncKeyState(vk) & 0x8000) != 0;
        const bool pressed = isDown && !wasDown;
        wasDown = isDown;
        return pressed;
    }

    bool IsPartClass(const std::string& className) {
        return className == "Part" || className == "MeshPart" || className == "UnionOperation" || className == "BasePart";
    }

    void ApplyCharacterNoclip(RBX::RbxInstance character, bool noclipEnabled) {
        const uint8_t collideMask = static_cast<uint8_t>(Offsets::PrimitiveFlags::CanCollide);

        std::vector<RBX::RbxInstance> stack;
        stack.push_back(character);

        while (!stack.empty()) {
            RBX::RbxInstance node = stack.back();
            stack.pop_back();

            auto children = node.GetChildList();
            for (auto child : children) {
                stack.push_back(child);

                if (!IsPartClass(child.GetClass())) {
                    continue;
                }

                const auto primitive = child.GetPrimitivePtr();
                if (primitive == 0) {
                    continue;
                }

                uint8_t flags = Coms->ReadMemory<uint8_t>(primitive + Offsets::Primitive::Flags);
                const uint8_t desired = noclipEnabled ? static_cast<uint8_t>(flags & ~collideMask)
                                                      : static_cast<uint8_t>(flags | collideMask);
                if (desired != flags) {
                    Coms->WriteMemory<uint8_t>(primitive + Offsets::Primitive::Flags, desired);
                }
            }
        }
    }

    void CaptureLocalDefaults(const RBX::RbxInstance& humanoid) {
        if (humanoid.Addr == 0) return;

        if (Vars::Local::speedEnabled && (!gLocalRestore.walkCaptured || gLocalRestore.walkHumanoid != humanoid.Addr)) {
            const float currentWalk = Coms->ReadMemory<float>(humanoid.Addr + Offsets::Humanoid::Walkspeed);
            if (IsReasonableStat(currentWalk)) {
                gLocalRestore.originalWalkSpeed = currentWalk;
            }
            gLocalRestore.walkHumanoid = humanoid.Addr;
            gLocalRestore.walkCaptured = true;
        }

        if (Vars::Local::jumpEnabled && (!gLocalRestore.jumpCaptured || gLocalRestore.jumpHumanoid != humanoid.Addr)) {
            const float currentJump = Coms->ReadMemory<float>(humanoid.Addr + Offsets::Humanoid::JumpPower);
            if (IsReasonableStat(currentJump)) {
                gLocalRestore.originalJumpPower = currentJump;
            }
            gLocalRestore.jumpHumanoid = humanoid.Addr;
            gLocalRestore.jumpCaptured = true;
        }
    }

    void RestoreLocalDefaultsOnExit() {
        Vars::Local::speedEnabled = false;
        Vars::Local::jumpEnabled = false;
        Vars::Local::flyEnabled = false;
        Vars::Local::gravityEnabled = false;
        Vars::Local::noclipEnabled = false;

        constexpr int kRestoreRetries = 80;
        for (int attempt = 0; attempt < kRestoreRetries; ++attempt) {
            uintptr_t humanoidAddr = 0;

            if (Globals::players.Addr != 0) {
                auto localPlayerAddr = Coms->ReadMemory<uintptr_t>(Globals::players.Addr + Offsets::Player::LocalPlayer);
                if (localPlayerAddr != 0) {
                    Globals::localPlayer = RBX::RbxInstance(localPlayerAddr);
                }
            }

            if (Globals::localPlayer.Addr != 0) {
                auto character = Globals::localPlayer.GetModelRef();
                if (character.Addr != 0) {
                    auto humanoid = character.FindChildByClass("Humanoid");
                    if (humanoid.Addr != 0) {
                        humanoidAddr = humanoid.Addr;
                    }
                }
            }

            if (humanoidAddr == 0) {
                if (gLocalRestore.walkHumanoid != 0) {
                    humanoidAddr = gLocalRestore.walkHumanoid;
                } else {
                    humanoidAddr = gLocalRestore.jumpHumanoid;
                }
            }

            if (humanoidAddr != 0) {
                if (gLocalRestore.walkCaptured) {
                    Coms->WriteMemory<float>(humanoidAddr + Offsets::Humanoid::Walkspeed, gLocalRestore.originalWalkSpeed);
                    Coms->WriteMemory<float>(humanoidAddr + Offsets::Humanoid::WalkspeedCheck, gLocalRestore.originalWalkSpeed);
                }

                if (gLocalRestore.jumpCaptured) {
                    Coms->WriteMemory<float>(humanoidAddr + Offsets::Humanoid::JumpPower, gLocalRestore.originalJumpPower);
                }

                bool walkOk = !gLocalRestore.walkCaptured;
                bool jumpOk = !gLocalRestore.jumpCaptured;

                if (gLocalRestore.walkCaptured) {
                    const float walkNow = Coms->ReadMemory<float>(humanoidAddr + Offsets::Humanoid::Walkspeed);
                    walkOk = std::fabs(walkNow - gLocalRestore.originalWalkSpeed) <= 0.05f;
                }
                if (gLocalRestore.jumpCaptured) {
                    const float jumpNow = Coms->ReadMemory<float>(humanoidAddr + Offsets::Humanoid::JumpPower);
                    jumpOk = std::fabs(jumpNow - gLocalRestore.originalJumpPower) <= 0.05f;
                }

                if (walkOk && jumpOk) {
                    break;
                }
            }

            Gravity::RestoreIfOverridden();
            std::this_thread::sleep_for(std::chrono::milliseconds(2));
        }

        Vars::Local::speedEnabled = false;
        Vars::Local::jumpEnabled = false;
        Vars::Local::flyEnabled = false;
        Vars::Local::gravityEnabled = false;
        Vars::Local::noclipEnabled = false;
    }
}

void GravityThread() {
    while (running) {
        Gravity::Tick();
        LightingFeature::Tick();
        std::this_thread::sleep_for(std::chrono::milliseconds(5));
    }
}

void LocalPlayerThread() {
    while (running) {
        auto frameStart = std::chrono::steady_clock::now();
        if (Globals::players.Addr != 0) {
            auto localPlayerAddr = Coms->ReadMemory<uintptr_t>(Globals::players.Addr + Offsets::Player::LocalPlayer);
            if (localPlayerAddr != 0) {
                Globals::localPlayer = RBX::RbxInstance(localPlayerAddr);
            }
        }

        if (Globals::localPlayer.Addr == 0) {
            auto elapsed = std::chrono::steady_clock::now() - frameStart;
            if (elapsed < kFrameBudget) {
                std::this_thread::sleep_for(kFrameBudget - elapsed);
            }
            continue;
        }

        auto character = Globals::localPlayer.GetModelRef();
        if (character.Addr == 0) {
            auto elapsed = std::chrono::steady_clock::now() - frameStart;
            if (elapsed < kFrameBudget) {
                std::this_thread::sleep_for(kFrameBudget - elapsed);
            }
            continue;
        }

        auto humanoid = character.FindChildByClass("Humanoid");
        if (humanoid.Addr == 0) {
            auto elapsed = std::chrono::steady_clock::now() - frameStart;
            if (elapsed < kFrameBudget) {
                std::this_thread::sleep_for(kFrameBudget - elapsed);
            }
            continue;
        }

        CaptureLocalDefaults(humanoid);

        if (WasHotkeyPressed(Vars::Local::walkSpeedKey, gWalkSpeedKeyWasDown)) {
            Vars::Local::speedEnabled = !Vars::Local::speedEnabled;
        }

        if (WasHotkeyPressed(Vars::Local::jumpPowerKey, gJumpPowerKeyWasDown)) {
            Vars::Local::jumpEnabled = !Vars::Local::jumpEnabled;
        }

        if (WasHotkeyPressed(Vars::Local::gravityKey, gGravityKeyWasDown)) {
            Vars::Local::gravityEnabled = !Vars::Local::gravityEnabled;
        }

        if (Vars::Local::speedEnabled) {
            RBX::ModifyWalkSpeed(humanoid, Vars::Local::walkSpeed);
        }

        if (Vars::Local::jumpEnabled) {
            RBX::ModifyJumpPower(humanoid, Vars::Local::jumpPower);
        }

        if (WasHotkeyPressed(Vars::Local::noclipKey, gNoclipKeyWasDown)) {
            Vars::Local::noclipEnabled = !Vars::Local::noclipEnabled;
        }

        const auto now = std::chrono::steady_clock::now();
        const bool noclipStateChanged = gLastNoclipState != Vars::Local::noclipEnabled;
        const bool forceNoclipThisFrame = Vars::Local::noclipEnabled && Vars::Local::flyEnabled;
        if (forceNoclipThisFrame || noclipStateChanged || (now - gLastNoclipApply) >= std::chrono::milliseconds(40)) {
            ApplyCharacterNoclip(character, Vars::Local::noclipEnabled);
            gLastNoclipState = Vars::Local::noclipEnabled;
            gLastNoclipApply = now;
        }

        PlayersFeature::TickFollow();
        Fly::Tick(character, Vars::Local::noclipEnabled);

        auto elapsed = std::chrono::steady_clock::now() - frameStart;
        if (elapsed < kFrameBudget) {
            std::this_thread::sleep_for(kFrameBudget - elapsed);
        }
    }
}

int main() {
    SetConsoleCtrlHandler(ConsoleControlHandler, TRUE);
    Vars::UI::unloadRequested = false;
    ConfigSystem::RefreshList();
    ConfigSystem::AutoLoadLastConfig();

    std::cout << "[*] Searching for Roblox...\n";

    while (!Coms->Connect(L"RobloxPlayerBeta.exe")) {
        std::this_thread::sleep_for(std::chrono::seconds(2));
    }

    auto baseAddr = Coms->GetBase();
    std::cout << "[+] Process ID: " << Coms->GetPID() << "\n";
    std::cout << "[+] Base Address: 0x" << std::hex << baseAddr << std::dec << "\n";

    std::this_thread::sleep_for(std::chrono::seconds(1));

    auto visualEngineAddr = baseAddr + Offsets::VisualEngine::Pointer;
    std::cout << "[*] VisualEngine Address: 0x" << std::hex << visualEngineAddr << std::dec << "\n";

    auto visualEngine = ResolveVisualEngineAddress(baseAddr);
    std::cout << "[*] VisualEngine Pointer: 0x" << std::hex << visualEngine << std::dec << "\n";

    if (visualEngine == 0) {
        std::cout << "[!] Error: VisualEngine pointer is 0!\n";
        std::cout << "[!] VisualEngine::Pointer offset might be wrong: 0x" << std::hex << Offsets::VisualEngine::Pointer << std::dec << "\n";
        system("pause");
        return -1;
    }

    auto fakeDataModelAddr = visualEngine + Offsets::VisualEngine::FakeDataModel;
    std::cout << "[*] FakeDataModel Address Offset: 0x" << std::hex << Offsets::VisualEngine::FakeDataModel << std::dec << "\n";

    auto fakeDataModel = Coms->ReadMemory<uintptr_t>(fakeDataModelAddr);
    std::cout << "[*] FakeDataModel Pointer: 0x" << std::hex << fakeDataModel << std::dec << "\n";

    if (fakeDataModel == 0) {
        std::cout << "[!] Error: FakeDataModel pointer is 0!\n";
        std::cout << "[!] VisualEngine::FakeDataModel offset might be wrong: 0x" << std::hex << Offsets::VisualEngine::FakeDataModel << std::dec << "\n";
        system("pause");
        return -1;
    }

    auto dataModelPtr = Coms->ReadMemory<uintptr_t>(fakeDataModel + Offsets::FakeDataModel::RealDataModel);
    RBX::RbxInstance dm(dataModelPtr);
    std::cout << "[*] DataModel Class: " << dm.GetClass() << "\n";
    std::cout << "[*] DataModel Name: " << dm.GetName() << "\n";

    std::cout << "[*] DataModel Pointer: 0x" << std::hex << dataModelPtr << std::dec << "\n";

    if (dataModelPtr == 0) {
        std::cout << "[!] Error: DataModel pointer is 0!\n";
        std::cout << "[!] Try changing the offset from 0x10 to something else (e.g., 0x1d0, 0x8, 0x28)\n";
        system("pause");
        return -1;
    }

    Globals::dataModel = RBX::RbxInstance(dataModelPtr);
    Globals::renderEngine = RBX::RenderEngine(visualEngine);

    std::cout << "\n[*] === DataModel Debug ===\n";
    auto children = Globals::dataModel.GetChildList();
    std::cout << "[*] Children count: " << children.size() << "\n";

    if (children.size() == 0) {
        std::cout << "[!] DataModel has no children! DataModel pointer might be wrong.\n";
    }

    for (size_t i = 0; i < children.size() && i < 20; i++) {
        std::string name = children[i].GetName();
        std::string className = children[i].GetClass();
        std::cout << "    [" << i << "] Name: \"" << name << "\" | Class: \"" << className << "\"\n";
    }

    Globals::workspace = Globals::dataModel.FindChildByClass("Workspace");
    if (Globals::workspace.Addr == 0) {
        std::cout << "\n[!] Error: Could not find Workspace by class name!\n";
        std::cout << "[*] Trying to find by name instead...\n";
        Globals::workspace = Globals::dataModel.FindChild("Workspace");
        if (Globals::workspace.Addr == 0) {
            std::cout << "[!] Also failed to find Workspace by name.\n";
            std::cout << "[!] The DataModel might be invalid or the offset is wrong.\n";
            system("pause");
            return -1;
        }
    }

    Globals::players = Globals::dataModel.FindChildByClass("Players");
    if (Globals::players.Addr == 0) {
        std::cout << "[!] Error: Could not find Players service!\n";
        system("pause");
        return -1;
    }

    Globals::lighting = Globals::dataModel.FindChildByClass("Lighting");
    if (Globals::lighting.Addr == 0) {
        Globals::lighting = Globals::dataModel.FindChild("Lighting");
    }

    Globals::camera = Globals::workspace.FindChildByClass("Camera");

    auto localPlayerAddr = Coms->ReadMemory<uintptr_t>(Globals::players.Addr + Offsets::Player::LocalPlayer);
    if (localPlayerAddr == 0) {
        std::cout << "[!] Error: LocalPlayer pointer is 0!\n";
        system("pause");
        return -1;
    }

    Globals::localPlayer = RBX::RbxInstance(localPlayerAddr);

    std::cout << "\n[+] === Successfully Initialized ===\n";
    std::cout << "[+] DataModel: 0x" << std::hex << dataModelPtr << std::dec << "\n";
    std::cout << "[+] VisualEngine: 0x" << std::hex << visualEngine << std::dec << "\n";
    std::cout << "[+] Workspace: 0x" << std::hex << Globals::workspace.Addr << std::dec << "\n";
    std::cout << "[+] Players: 0x" << std::hex << Globals::players.Addr << std::dec << "\n";
    std::cout << "[+] Lighting: 0x" << std::hex << Globals::lighting.Addr << std::dec << "\n";
    std::cout << "[+] Camera: 0x" << std::hex << Globals::camera.Addr << std::dec << "\n";
    std::cout << "[+] LocalPlayer: 0x" << std::hex << localPlayerAddr << std::dec << "\n\n";

    OverlayWindow overlay;
    if (!overlay.Initialize()) {
        std::cout << "[!] Failed to initialize overlay\n";
        return -1;
    }

    std::cout << "[+] Overlay initialized\n";
    std::cout << "[*] Press INSERT to toggle menu\n\n";

    std::thread localThread(LocalPlayerThread);
    std::thread gravityThread(GravityThread);

    while (Coms->IsConnected() && running)
    {
        auto frameStart = std::chrono::steady_clock::now();

        if (Vars::UI::unloadRequested) {
            running = false;
            break;
        }

        if (!IsGameRunning(L"Roblox"))
        {
            break;
        }

        if (GetAsyncKeyState(VK_INSERT) & 1) {
            Vars::menuOpen = !Vars::menuOpen;
        }

        static auto lastCacheUpdate = std::chrono::steady_clock::now();
        const auto cacheNow = std::chrono::steady_clock::now();
        if (std::chrono::duration_cast<std::chrono::milliseconds>(cacheNow - lastCacheUpdate).count() >= 80) {
            PlayerCache::UpdatePlayers();
            lastCacheUpdate = cacheNow;
        }

        overlay.BeginFrame();
        if (Vars::menuOpen) {
            overlay.RenderMenu();
        }

        ImDrawList* drawList = ImGui::GetBackgroundDrawList();

        static std::string cachedWatermark;
        static ImVec2 cachedWatermarkSize{ 0.0f, 0.0f };
        static auto lastWatermarkRefresh = std::chrono::steady_clock::now();

        const auto watermarkNow = std::chrono::steady_clock::now();
        if (!Vars::Watermark::enabled || cachedWatermark.empty() || std::chrono::duration_cast<std::chrono::milliseconds>(watermarkNow - lastWatermarkRefresh).count() >= 250) {
            cachedWatermark = overlay.BuildWatermarkText();
            if (cachedWatermark.empty()) {
                cachedWatermark = "FemboyProLaptop";
            }
            lastWatermarkRefresh = watermarkNow;
        }

        std::string watermark = cachedWatermark;
        float screenW = static_cast<float>(GetSystemMetrics(SM_CXSCREEN));
        float screenH = static_cast<float>(GetSystemMetrics(SM_CXSCREEN));
        ImFont* watermarkFont = overlay.GetWatermarkFont();
        constexpr float kWatermarkFontSize = 12.0f;

        auto measureWatermark = [&](const std::string& text) -> ImVec2 {
            if (watermarkFont) {
                return watermarkFont->CalcTextSizeA(kWatermarkFontSize, 1000000.0f, 0.0f, text.c_str());
            }
            return ImGui::CalcTextSize(text.c_str());
        };

        const float maxWatermarkWidth = screenW * 0.45f;
        ImVec2 textSize = cachedWatermarkSize;
        if (textSize.x <= 0.0f || textSize.y <= 0.0f) {
            textSize = measureWatermark(watermark);
            cachedWatermarkSize = textSize;
        }
        if (textSize.x > maxWatermarkWidth) {
            std::string trimmed = watermark;
            while (trimmed.size() > 4) {
                trimmed.pop_back();
                std::string candidate = trimmed + "...";
                ImVec2 candidateSize = measureWatermark(candidate);
                if (candidateSize.x <= maxWatermarkWidth) {
                    watermark = candidate;
                    textSize = candidateSize;
                    cachedWatermarkSize = textSize;
                    break;
                }
            }
        }

        const float watermarkX = (screenW - textSize.x - 10.0f < 10.0f) ? 10.0f : (screenW - textSize.x - 10.0f);
        ImVec2 watermarkPos = ImVec2(watermarkX, 10.0f);

        if (watermarkFont) {
            drawList->AddText(watermarkFont, kWatermarkFontSize, ImVec2(watermarkPos.x - 1, watermarkPos.y), IM_COL32(0, 0, 0, 255), watermark.c_str());
            drawList->AddText(watermarkFont, kWatermarkFontSize, ImVec2(watermarkPos.x + 1, watermarkPos.y), IM_COL32(0, 0, 0, 255), watermark.c_str());
            drawList->AddText(watermarkFont, kWatermarkFontSize, ImVec2(watermarkPos.x, watermarkPos.y - 1), IM_COL32(0, 0, 0, 255), watermark.c_str());
            drawList->AddText(watermarkFont, kWatermarkFontSize, ImVec2(watermarkPos.x, watermarkPos.y + 1), IM_COL32(0, 0, 0, 255), watermark.c_str());
            drawList->AddText(watermarkFont, kWatermarkFontSize, watermarkPos, overlay.GetWatermarkColor(), watermark.c_str());
        } else {
            drawList->AddText(ImVec2(watermarkPos.x - 1, watermarkPos.y), IM_COL32(0, 0, 0, 255), watermark.c_str());
            drawList->AddText(ImVec2(watermarkPos.x + 1, watermarkPos.y), IM_COL32(0, 0, 0, 255), watermark.c_str());
            drawList->AddText(ImVec2(watermarkPos.x, watermarkPos.y - 1), IM_COL32(0, 0, 0, 255), watermark.c_str());
            drawList->AddText(ImVec2(watermarkPos.x, watermarkPos.y + 1), IM_COL32(0, 0, 0, 255), watermark.c_str());
            drawList->AddText(watermarkPos, overlay.GetWatermarkColor(), watermark.c_str());
        }

        auto drawFovCircle = [&](bool enabled, float radius, ImU32 outerColor, ImU32 innerColor) {
            if (!enabled || radius <= 0.0f) {
                return;
            }
            POINT p;
            GetCursorPos(&p);
            ImVec2 center = ImVec2(static_cast<float>(p.x), static_cast<float>(p.y));
            drawList->AddCircle(center, radius, outerColor, 64, 2.0f);
            drawList->AddCircle(center, radius, innerColor, 64, 1.0f);
        };

        if (Vars::Aimbot::enabled && Vars::aimbotDrawFov) {
            drawFovCircle(true, Vars::Aimbot::fovRadius, IM_COL32(0, 0, 0, 255), IM_COL32(255, 255, 255, 255));
        }
        if (Vars::SilentAim::silentAimEnabled && Vars::silentDrawFov) {
            drawFovCircle(true, Vars::SilentAim::silentFovRadius, IM_COL32(0, 0, 0, 255), IM_COL32(255, 96, 96, 255));
        }

        auto viewMatrix = Globals::renderEngine.GetViewMat();

        Aimbot::RunAimbot(viewMatrix);
        if (Vars::ESP::enabled) {
            Visuals::RenderESP(drawList, viewMatrix, overlay.GetEspFont());
        }

        overlay.EndFrame();

        if (!Vars::UI::vsyncEnabled) {
            auto elapsed = std::chrono::steady_clock::now() - frameStart;
            if (elapsed < kFrameBudget) {
                std::this_thread::sleep_for(kFrameBudget - elapsed);
            }
        }
    }

    running = false;
    if (localThread.joinable()) {
        localThread.join();
    }
    if (gravityThread.joinable()) {
        gravityThread.join();
    }

    RestoreLocalDefaultsOnExit();
    Gravity::RestoreIfOverridden();
    LightingFeature::RestoreDefaults();
    overlay.Cleanup();

    return 0;
}